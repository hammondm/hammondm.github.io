use Tk;

$b1text = "yes";

$mainw = MainWindow->new;
$b1 = $mainw->Button(
	-textvariable => \$b1text,
	-command => sub {
			if ($b1text eq "yes") {
				$b1text = "no";
			} else {
				$b1text = "yes";
			}
		});
$b1->pack;
$mainw->Button(-text => 'quit', -command => sub { exit })->pack;

MainLoop;

