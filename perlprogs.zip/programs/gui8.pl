use Tk;

$mw = MainWindow->new;
$mw->title("This is a title");
$mw->Label(-text => "This is only a label")->pack;
$mw->Button(-text => "Quit", -command => sub { exit })->pack;

MainLoop;
