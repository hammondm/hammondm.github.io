$num = 5;
if ($num == 0) {
	print "1\n";
} else {
	$res = 1;
	$i = 1;
	while ($i <= $num) {
		$res = $res * $i;
		$i++;
	}
	print "$res\n";
}
