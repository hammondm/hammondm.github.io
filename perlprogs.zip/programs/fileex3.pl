print STDERR "Enter text below and a blank line to end.\n";
while ((length ($line = <STDIN>)) > 1) {
	$lines[$i++] = $line;
}
open MYFILE, ">$ARGV[0]" or die "can't write to file!\n";
$i = 1;
foreach $line (@lines) {
	print MYFILE "$i:\t$line";
	$i++;
}
close MYFILE;

