#!perl

print <<"THEHTML"
Content-type: text/html

<html>
<head>
<title>Responding to a form</title>
</head>
<body>
<strong>Here is the query string</strong>:<br>
$ENV{QUERY_STRING}
</body>
</html>
THEHTML

