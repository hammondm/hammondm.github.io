#!perl

print "Content-type: text/html\n\n";

print "<html><head><title>First CGI!</title></head><body>\n";
print "You've reached my <strong>first</strong> ";
print "CGI program.</body></html>";

