print "Enter a number: ";
$number = <STDIN>;
chomp $number;
print times37($number), "\n";

sub times37 {
	my $num = $_[0];
	return $num * 37;
}

