use Tk;

$mw = MainWindow->new;
$mw->Label(-text => 'Make a selection')->pack;
$mw->Radiobutton(
	-text => 'German',
	-variable => \$lang,
	-value => 'g',
	-command => sub {
		if ($lang eq 'g') {
			$msg = "Sprechen Sie Deutsch?";
		} elsif ($lang eq 'f') {
			$msg = "Parlez vous Fran�ais?";
		} else {
			$msg = "Do you speak English?";
		}
})->pack;
$mw->Radiobutton(
	-text => 'French',
	-variable => \$lang,
	-value => 'f',
	-command => sub {
		if ($lang eq 'g') {
			$msg = "Sprechen Sie Deutsch?";
		} elsif ($lang eq 'f') {
			$msg = "Parlez vous Fran�ais?";
		} else {
			$msg = "Do you speak English?";
		}
})->pack;
$mw->Radiobutton(
	-text => 'English',
	-variable => \$lang,
	-value => 'e',
	-command => sub {
		if ($lang eq 'g') {
			$msg = "Sprechen Sie Deutsch?";
		} elsif ($lang eq 'f') {
			$msg = "Parlez vous Fran�ais?";
		} else {
			$msg = "Do you speak English?";
		}
})->pack;

$mw->Label(-textvariable => \$msg)->pack;

MainLoop;
