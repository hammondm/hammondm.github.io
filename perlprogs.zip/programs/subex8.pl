print "Enter a number: ";
$number = <STDIN>;
chomp $number;

sub times37 {
	my $num = $_[0];
	return $num * 37;
}

print times37 $number, "\n";

