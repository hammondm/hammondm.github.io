%myData = (French => ['France', 'Canada'],
			  English => ['USA', 'Canada', 'England'],
			  'Tohono O\'odham' => ['USA', 'Mexico']);

foreach $key (sort keys %myData) {
	print "$key:\t@{$myData{$key}}\n";
}
