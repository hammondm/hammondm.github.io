print "Hello\n";
print "there!\n";
