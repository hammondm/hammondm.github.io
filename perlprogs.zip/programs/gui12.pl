use Tk;

$color = 'red';
$text = 'This is red';

$mw = MainWindow->new;
$label = $mw->Label(-textvariable => \$text, -background => $color);
$label->pack(-side => 'bottom');
$b1 = $mw->Button(-text => 'red', -command => [\&doColor, 'red']);
$b1->pack(-side => 'left');
$b2 = $mw->Button(-text => 'yellow', -command => [\&doColor, 'yellow']);
$b2->pack(-side => 'left');
$b3 = $mw->Button(-text => 'blue', -command => [\&doColor, 'blue']);
$b3->pack(-side => 'left');

MainLoop;

sub doColor {
	$color = shift;
	$text = "This is $color";
	$label->configure(-background => $color);
}
