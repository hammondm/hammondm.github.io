@myArray = ('Catalan', 'German', 'Quechua', 'English');
$myRef = \@myArray;
for ($i = 0; $i <= $#{$myRef}; $i++) {
	print "$i\t$myRef->[$i]\n";
}

$myHash{Catalan} = 'Spain';
$myHash{German} = 'Germany';
$myHash{Quechua} = 'Peru';
$myHash{English} = 'USA';
$myOtherRef = \%myHash;
foreach $key (sort keys %$myOtherRef) {
	print "$key\t$myOtherRef->{$key}\n";
}
