$hat = "chairs";
$chairs = "hats";
if ($hat lt $chairs) {
	print "Put $hat first.\n";
} else {
	print "Put $chairs first.\n";
}

