print "yes\n" if ("hats" eq "hat" . "s");
print "yes again\n" if ("had" lt "hat");

