#!perl

@words = ("hat", "towel", "cowl", "flour", "flower", "happy", "charity");
@wordssave = @words;
$mycgiurl = "http://www.bananas.org/cgi-bin/expcgi1.pl";

if (exists $ENV{PATH_INFO}) {
	#get results up to this point
	$res = $ENV{PATH_INFO};
	$res =~ s/^\///;
	$ressave = $res;
	while (length $res > 0) {
		$res =~ s/^(\d\d)\d//;
		$already = $1;
		push @nums, $already;
	}
	@nums = sort @nums;
	while ($#nums > -1) {
		$already = pop @nums;
		splice @words, $already, 1;
	}
	#are there still items to run?
	if ($#words > -1) {
		$thisword = &getrandom;
		displayItem($thisword);
	#if there are no more items; end of experiment
	} else {
		#save results to file
		open F, ">>cgi-res.txt" or die "can't open results file!\n";
		my $date = localtime;
		print F "$ressave\t$date\n";
		close F;
		&thankyou;
	}
} else {
	#begin experiment
	$thisword = &getrandom;
	displayItem($thisword);
}

sub getrandom {
	my $ind = rand ($#words + 1);
	return $words[$ind];
}

sub displayItem {
	my $item = shift;
	for ($k = 0; $k <= $#wordssave; $k++) {
		last if ($wordssave[$k] eq $item);
	}
	$k = '0' . $k if (length $k == 1);
	print <<"HTMLEND";
Content-type: text/html

<html>
<head>
<title>Syllabification Experiment</title>
</head>
<body>
How many syllables does this word have?: <strong>$item</strong><br>
<ul>
	<li><a href="$mycgiurl/$ressave${k}1">one</a>
	<li><a href="$mycgiurl/$ressave${k}2">two</a>
	<li><a href="$mycgiurl/$ressave${k}3">three</a>
	<li><a href="$mycgiurl/$ressave${k}4">four</a>
</ul>
</body>
</html>
HTMLEND
}

sub thankyou {
	print <<"THANK";
Content-type: text/html

<html>
<head>
<title>Syllabification Experiment</title>
</head>
<body>
<strong>Thank you!</strong>
</body>
</html>
THANK
}

