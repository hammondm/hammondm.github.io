use Tk;

@items = ("hat", "flour", "charity", "cowl", "flower", "towel", "syllable");
$b1text = 'Continue';
$introflag = 0;
$instruc = <<"MYEND";
This is an experiment testing your ability to count
the number of syllables in a word. For each of the
following items, you should indicate how many syllables
it has by clicking the appropriate button. There are
seven items in total.
MYEND
$date = localtime;
print "\nnew subject: $date\n";

$mw = MainWindow->new;
$mw->configure(-background => 'mistyrose');
$mw->title('Syllable-counting experiment');
$mw->Label(
	-text => 'Syllable-counting experiment',
	-background => 'mistyrose')->pack;
$b1 = $mw->Button(
	-textvariable => \$b1text,
	-command => \&intro)->pack(-side => 'bottom');
$ins = $mw->Label(
	-text => $instruc,
	-background => 'mistyrose')->pack(-side => 'bottom');

MainLoop;

sub intro {
	if ($introflag == 0) {
		$introflag = 1;
		$ins->packForget;
		$b1->packForget;
		$mw->Label(-textvariable => \$wordtext,
			-background => 'coral')->pack;
		$wordtext = shift @items;
		$rb1 = $mw->Radiobutton(
			-text => "one",
			-value => 1,
			-variable => \$response,
			-background => 'mistyrose',
			-activebackground => 'OrangeRed',
			-command => \&doResponse)->pack;
		$rb2 = $mw->Radiobutton(
			-text => "two",
			-value => 2,
			-variable => \$response,
			-background => 'mistyrose',
			-activebackground => 'OrangeRed',
			-command => \&doResponse)->pack;
		$rb3 = $mw->Radiobutton(
			-text => "three",
			-value => 3,
			-variable => \$response,
			-background => 'mistyrose',
			-activebackground => 'OrangeRed',
			-command => \&doResponse)->pack;
	} else {
		exit;
	}
}

sub doResponse {
	print "$wordtext: $response\n";
	if ($#items > -1) {
		$wordtext = shift @items;
		$rb1->deselect;
		$rb2->deselect;
		$rb3->deselect;
	} else {
		$wordtext = 'Thank you!';
		$rb1->packForget;
		$rb2->packForget;
		$rb3->packForget;
		$b1text = 'Dismiss';
		$b1->pack(-side => 'bottom');
	}
}

