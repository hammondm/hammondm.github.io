open F, $ARGV[1] or die "can\'t open file!\n";

while ($line = <F>) {
	if ($line =~ /$ARGV[0]/) {
		print $line;
	}
}

close F;
