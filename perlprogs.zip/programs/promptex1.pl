print "Enter a number: ";
$num = <STDIN>;
print "You entered $num";
