#!perl

read STDIN, $stuff, $ENV{CONTENT_LENGTH};

print <<"THEHTML"
Content-type: text/html

<html>
<head>
<title>Responding to the POST method</title>
</head>
<body>
<strong>Here is the input</strong>:<br>
$stuff
</body>
</html>
THEHTML

