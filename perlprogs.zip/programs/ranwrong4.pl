@lets = 0..9;
print "@lets\n";
while ($#lets > -1) {
	push @newlets, splice @lets, rand $#lets+1, 1;
}
print "@newlets\n";

