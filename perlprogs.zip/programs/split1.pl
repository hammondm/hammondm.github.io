open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	@f = split /[\.\?!]/, $line;
	push @frags, @f;
}

close F;

foreach $frag (@frags) {
	if ($frag =~ /\n$/) {
		chomp $frag;
		print "$frag ";
	} else {
		print "$frag\n\n";
	}
}

