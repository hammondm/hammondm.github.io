package octal;

use Exporter;
@ISA = ("Exporter");
@EXPORT = ("&oct");

sub oct {
	my $arg = shift;
	$arg = ord $arg;
	$arg = sprintf "%o", $arg;
	return $arg;
}

1;

