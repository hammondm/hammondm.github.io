$hat = 3;
print "$hat\n";
print '$hat\n';
