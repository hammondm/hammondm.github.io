open F, $ARGV[0] or die "Uh-oh!\n";

while ($line = <F>) {
	@wordsInLine = split /\W+/, $line;
	push @words, @wordsInLine;
}

close F;

foreach $word (sort mysort @words) {
	print "$word\n";
}

sub mysort {
	if ($a =~ /^[A-Z]/ and $b =~ /^[A-Z]/) {
		return length $a <=> length $b;
	} elsif ($a !~ /^[A-Z]/ and $b !~ /^[A-Z]/) {
		return length $a <=> length $b;
	} elsif ($a =~ /^[A-Z]/) {
		return -1;
	} else {
		return 1;
	}
}

