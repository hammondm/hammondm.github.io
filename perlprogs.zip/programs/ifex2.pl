if (2 + 2 < 5) {
	$result = 2 + 2;
	print "The result is $result.\n";
}
