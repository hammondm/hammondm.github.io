open F, $ARGV[0] or die "Enter a file name\n";

while ($line = <F>) {
	chomp $line;
	@words = split /[ \.\?,!;:]+/, $line;
	foreach $word (@words) {
		$word = lc $word;
		if (exists $conc{$word}) {
			$conc{$word}++;
		} else {
			$conc{$word} = 1;
		}
	}
}

close F;

foreach $word (sort keys %conc) {
	print "$word:\t$conc{$word}\n";
}

