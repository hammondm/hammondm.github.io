open F, $ARGV[1] or die "Oops!\n";

while ($line = <F>) {
	if ($line =~ /$ARGV[0]/) {
		print "before:\t$`\n";
		print "match:\t$&\n";
		print "after:\t$'\n";
	}
}

close F;
