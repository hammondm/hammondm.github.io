$total = 0;
for ($i = 0; $i <= $#ARGV; $i++) {
	$total = $total + $ARGV[$i];
}
print "Total: $total\n";
