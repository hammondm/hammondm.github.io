use Tk;

$mywin = MainWindow->new;
$mybutton = $mywin->Button(-text => "Done", -command => sub { exit });
$mybutton->pack;

MainLoop;
