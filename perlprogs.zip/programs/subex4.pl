$num = $ARGV[0];
if (&div37) {
	print "Divisible by 37!\n";
} else {
	print "Not divisible by 37.\n";
}

sub div37 {
	if ($num % 37 == 0) {
		return 1;
	}
	return 0;
}

