use Tk;

$mywin = MainWindow->new(-background => 'blue');
$mybutton = $mywin->Button(
	-text => "Done",
	-command => sub { exit },
	-background => 'red',
	-activebackground => 'green');
$mybutton->pack;

MainLoop;
