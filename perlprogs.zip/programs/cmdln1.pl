print "$ARGV[0]\n";
