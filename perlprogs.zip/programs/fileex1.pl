open F, $ARGV[0] or die "File couldn't be opened!\n";

while ($line = <F>) {
	print $line;
}

close F;

