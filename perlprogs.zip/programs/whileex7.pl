$i = 10;
while ($i < 10) {
	print "$i\n";
	$i++;
}
