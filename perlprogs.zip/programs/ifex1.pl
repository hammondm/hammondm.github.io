if (2 + 2 > 3) {
	print "The laws of math still hold!";
}
