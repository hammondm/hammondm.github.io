$i = 0;
do {
	print "$i\n";
	$i++;
} while ($i < 10);
