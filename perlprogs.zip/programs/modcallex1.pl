use modex1;

modex1::printit "Joe", "donuts";
modex1::printit "Diane", "cookies";
modex1::printit "Puck", "pizza", "apricots", "asparagus";

