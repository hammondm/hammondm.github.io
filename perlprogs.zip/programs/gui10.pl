use Tk;

$mw = MainWindow->new;
$mw->Label(-text => 'Make a selection')->pack;
$mw->Radiobutton(
	-text => 'German',
	-variable => \$lang,
	-value => 'g',
	-command => \&doLang)->pack;
$mw->Radiobutton(
	-text => 'French',
	-variable => \$lang,
	-value => 'f',
	-command => \&doLang)->pack;
$mw->Radiobutton(
	-text => 'English',
	-variable => \$lang,
	-value => 'e',
	-command => \&doLang)->pack;
$mw->Label(-textvariable => \$msg)->pack;

MainLoop;

sub doLang {
	if ($lang eq 'g') {
		$msg = "Sprechen Sie Deutsch?";
	} elsif ($lang eq 'f') {
		$msg = "Parlez vous Fran�ais?";
	} else {
		$msg = "Do you speak English?";
	}
}

