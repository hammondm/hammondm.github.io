@verb = ("run", "junk", "sing");
print "The three verbs are: @verb.\n";
