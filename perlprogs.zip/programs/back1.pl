open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	if ($line =~ /(\w{3,})\1/) {
		print "$1:\t$line";
	}
}

close F;

