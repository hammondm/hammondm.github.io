open F, $ARGV[0] or die "Oops!\n";

$punc = "[\.\?!]";

while (<F>) {
	@f = split /($punc)/;
	push @frags, @f;
}

close F;

foreach (@frags) {
	$sentence .= $_;
	if (/$punc/) {
		$sentence =~ tr/\n/ /;
		$sentence =~ s/ +/ /g;
		$sentence =~ s/^\W+//;
		push @sentences, $sentence;
		$sentence = "";
	}
}

foreach (@sentences) {
	print;
	print "\n\n";
}

