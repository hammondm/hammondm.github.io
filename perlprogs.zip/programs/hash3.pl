$myhash{lion} = 6;
$myhash{tiger} = "lion";
$myhash{bear} = $myhash{lion} .  " " . $myhash{tiger} . "s";

&enter;

while (length $line > 0) {
	if (exists $myhash{$line}) {
		print "The value of \$myhash{$line} was: $myhash{$line}\n";
		delete $myhash{$line};
	} else {
		print "New key!\nEnter a value: ";
		$val = <STDIN>;
		chomp $val;
		$myhash{$line} = $val;
	}
	&enter;
}

sub enter {
	print "Enter a key: ";
	$line = <STDIN>;
	chomp $line;
}
