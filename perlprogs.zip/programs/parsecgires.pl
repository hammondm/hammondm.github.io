open F, 'expres.txt' or die "oops!\n";

$subject = 0;

while ($line = <F>) {
	chomp $line;
	($date, $string) = split /\t/, $line;
	@items = split /&/, $string;
	$subject++;
	foreach $item (@items) {
		($word, $syllables) = split /=/, $item;
		$results{$word} += $syllables;
	}
}

close F;

foreach $key (sort keys %results) {
	$avg = $results{$key} / $subject;
	print "$key\t$avg\n";
}
