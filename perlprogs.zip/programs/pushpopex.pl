if ($#ARGV != 0) { die "Enter a file on the command-line\n" }
open F, $ARGV[0] or die "File can't be opened\n";
while ($line = <F>) {
	push @lines, $line;
}
close F;
while ($#lines >= 0) {
	print pop @lines;
}

