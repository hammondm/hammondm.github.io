open F, $ARGV[0] or die "Oops!\n";

while (<F>) {
	while (/[A-Z]\w*/g) {
		print "$&\n";
	}
}

close F;

