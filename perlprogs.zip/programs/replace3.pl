open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
 	 $line =~ s/\d+/times3($&)/ge;
 	 print $line;
}

close F;

sub times3 {
	my $in = shift;
	return $in * 3;
}

