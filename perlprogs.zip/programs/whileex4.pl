$then = time;
$diff = 0;
while ($diff < 6) {
	$now = time;
	$diff = $now - $then;
}
print "done!\n";
