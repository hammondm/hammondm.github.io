$file = File->new($ARGV[0]);
$myConc = Concordance->new($file);
$myConc->printIt;

package File;

sub new {
	my $class = shift;
	my $filename = shift;
	my $self = {filename => $filename};
	bless $self, $class;
	return $self;
}

sub getFile {
	my $self = shift;
	return $self->{filename};
}

package Line;

sub new {
	my $class = shift;
	my $text = shift;
	chomp $text;
	my $self = {text => $text};
	bless $self, $class;
	return $self;
}

sub getTokens {
	my $self = shift;
	my $text = $self->{text};
	my @words = split /\b/, $text;
	return @words;
}

package Concordance;

sub new {
	my $class = shift;
	my $file = shift;
	my $self = {};
	bless $self, $class;
	$self->makeIt($file->getFile);
	return $self;
}

sub makeIt {
	my $self = shift;
	my $file = shift;
	open F, $file or die "can't open file";
	while (<F>) {
		my $line = Line->new($_);
		$self->addWords($line);
	}
	close F;
}

sub addWords {
	my $self = shift;
	my $line = shift;
	my @words = $line->getTokens;
	foreach $word (@words) {
		if (exists $self->{$word}) {
			$self->{$word}++;
		} else {
			$self->{$word} = 1;
		}
	}
}

sub printIt {
	my $self = shift;
	foreach $key (sort keys %$self) {
		print "$key\t$self->{$key}\n";
	}
}

