$i = 0;
while ($i < 10) {
	print "$i\n";
	$i = $i + 1;
}
