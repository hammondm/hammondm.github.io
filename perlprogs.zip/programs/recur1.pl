my $data = &fac($ARGV[0]);

print "The factorial of $ARGV[0] is $data\n";

sub fac {
	my $out;
	my $in = shift;
	if ($in < 0) {
		$out = "undefined";
	} elsif ($in == 0) {
		$out = 1;
	} else {
		$out = $in * &fac($in-1);
	}
	return $out;
}

