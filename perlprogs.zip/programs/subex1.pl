@verbs = ('run', 'jump', 'hit');
foreach (@verbs) {
	print;
	&pn;
}

sub pn {
	print "\n";
}
