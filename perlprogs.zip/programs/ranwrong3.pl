@a = 0..9;
print "@a\n";
while ($#a > -1) {
	$b = rand $#a+1;
	$c = splice @a, $b, 1;
	push @d, $c;
}
print "@d\n";

