$hat = 4;
if ($hat == 2 + 3) {
	print "$hat\n";
}
