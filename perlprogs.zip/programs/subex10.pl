sub printit {
	my $name = shift;
	my $food = shift;
	print "Dear $name:\nThank you for the $food!\n\n";
}

printit "Joe", "donuts";
printit "Diane", "cookies";

