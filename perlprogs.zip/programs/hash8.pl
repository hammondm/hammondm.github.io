$myhash{lion} = 6;
$myhash{tiger} = "lion";
$myhash{bear} = $myhash{lion} .  " " . $myhash{tiger} . "s";

while (($key, $value) = each %myhash) {
	print "$key:\t$value\n";
}

