print "Enter a number: ";
$num = <STDIN>;
chomp $num;
print "You entered $num\n";
