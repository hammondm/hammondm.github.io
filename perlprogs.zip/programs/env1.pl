foreach $key (keys %ENV) {
	print "$key\t$ENV{$key}\n";
}

