open F, $ARGV[1] or die "Oops!\n";

$biggest = 0;

while ($line = <F>) {
	$lines++;
	$matches = 0;
	$matches++ while ($line =~ /$ARGV[0]/g);
	$allmatches += $matches;
	$biggest = $matches if ($matches > $biggest);
}

close F;

print "Total number of lines:\t$lines\n";
print "Total matches:\t$allmatches\n";
print "Max per line:\t$biggest\n";

