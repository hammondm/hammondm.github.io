$hat = $ARGV[0];

print "\$hat = $hat\n";

$chair = \$hat;
$couch = $hat;

print "\$\$chair = $$chair\n";
print "\$couch = $couch\n";

$hat = $ARGV[1];

print "The new value of \$hat = $hat\n";
print "\$\$chair = $$chair\n";
print "\$couch = $couch\n";
