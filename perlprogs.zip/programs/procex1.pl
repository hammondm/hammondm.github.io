open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	@words = split /\b/, $line;
	while ($#words > -1) {
		$word = pop @words;
		if (exists $conc{$word}) {
			$conc{$word}++;
		} else {
			$conc{$word} = 1;
		}
	}
}

close F;

foreach $key (sort keys %conc) {
	print "$key\t$conc{$key}\n";
}

