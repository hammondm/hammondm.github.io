$res = (60/3) * 1.5;
if ($res > 100) {
	print "Too big.\n";
} elsif ($res < 2) {
	print "Too small.\n";
} else {
	print "Just right: $res.\n";
}

