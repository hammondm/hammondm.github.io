open F, $ARGV[0] or die "Uh-oh!\n";

while ($line = <F>) {
	@wordsInLine = split /\W+/, $line;
	push @words, @wordsInLine;
}

close F;

foreach $word (sort @words) {
	print "$word\n";
}

