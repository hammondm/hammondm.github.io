open F, $ARGV[0] or die "Oops!\n";

while (<F>) {
	s/[Ff]ruit/vegetable/g;
	tr/aeiou/AEIOU/;
	print;
}

close F;

