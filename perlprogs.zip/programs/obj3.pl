$hat = MyObj->new;
$time = time;
do {
	$timediff = time - $time;
} while ($timediff < 3);
$hat->doSomething;

package MyObj;

sub new {
	my $date = localtime;
	my $self = {myData => $date};
	my $class = shift;
	bless $self, $class;
	return $self;
}

sub doSomething {
	my $self = shift;
	my $date = localtime;
	print "This object was created:\t$self->{myData}\n";
	print "The time now is:\t$date\n";
}

