open F, $ARGV[0] or die "Uh-oh!\n";

while ($line = <F>) {
	@wordsInLine = split /\W+/, $line;
	push @words, @wordsInLine;
}

close F;

print "sorted with default sorting routine:\n";

foreach $word (sort @words) {
	print "$word\n";
}

print "sorted with specified sorting routine:\n";

foreach $word (sort {$a cmp $b} @words) {
	print "$word\n";
}

print "sorted with subroutine:\n";

foreach $word (sort boring @words) {
	print "$word\n";
}

sub boring {
	return $a cmp $b;
}

