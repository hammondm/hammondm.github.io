open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	print "$1:\t$line" if ($line =~ /(\w{3,})\1/)
}

close F;

