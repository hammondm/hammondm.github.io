
@letters = 'a'..$ARGV[0];
@numbers = 1..$ARGV[1];
&let;

sub let {
	for ($i = 0; $i <= $#letters; $i++) {
		print "$letters[$i]";
		&num;
		&pn;
	}
}

sub num {
	for ($j = 0; $j <= $#numbers; $j++) {
		print "\t$numbers[$j]";
	}
}

sub pn {
	print "\n";
}

