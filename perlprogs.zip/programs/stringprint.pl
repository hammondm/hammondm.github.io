print "hat\n";
print 'chair\n';
