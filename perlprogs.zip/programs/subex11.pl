sub printit {
	my ($name, $food) = @_;
	print "Dear $name:\nThank you for the $food!\n\n";
}

printit "Joe", "donuts";
printit "Diane", "cookies";

