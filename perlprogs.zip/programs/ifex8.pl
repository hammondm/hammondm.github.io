$hat = "chair";
$chair = 7;
if ($hat gt "chair" and $chair <= 7) {
	print "Yippee!\n";
}
