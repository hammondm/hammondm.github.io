foreach $verb ('run', 'jump', 'hit') {
	print "$verb\n";
}
