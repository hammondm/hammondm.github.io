$hat = "chair";
$chair = "hat";
print $hat;
print "\n";
print $chair;
print "\n";
