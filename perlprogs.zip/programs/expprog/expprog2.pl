&initialize;
&readmaterials;
&randomizemats;
&presentmats;

#does initialization; replace "cls" with "clear" for unix
sub initialize {
	system cls;
	$materials = $ARGV[0];
	$results = $ARGV[1];
}

#reads materials from file into array
sub readmaterials {
	my $line;
	open MATS, $materials or die "Can't open materials file!\n";
	my $i = 0;
	while ($line = <MATS>) {
		chomp $line;
		push @mats, $line;
		push @indices, $i;
		$i++;
	}
	close MATS;
}

#randomizes materials, saving initial indices
sub randomizemats {
	my ($r, $item, $index);
	srand;
	while ($#mats > -1) {
		$r = rand $#mats+1;
		$item = splice @mats, $r, 1;
		$index = splice @indices, $r, 1;
		push @newmats, $item;
		push @newindices, $index;
	}
}

#present materials, saving results
sub presentmats {
	my $response;
	print "For each of the following sentences, indicate\
whether you find it acceptable or not.\n";
	open RES, ">>$results" or die "Can't save results!\n";
	for (my $i = 0; $i <= $#newmats; $i++) {
		print "$newmats[$i] (y/n): ";
		$response = <STDIN>;
		print RES "$newindices[$i]\t$newmats[$i]\t$response";
	}
	close RES;
}

