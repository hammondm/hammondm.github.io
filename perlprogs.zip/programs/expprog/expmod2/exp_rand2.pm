package exp_rand2;

use Exporter;
@ISA = ("Exporter");
@EXPORT = ("&randomizemats");

#randomizes materials, saving initial indices
sub randomizemats {
	my ($r, $item, $index);
	my @mats = @_;
	my @newmats;
	srand;
	while ($#{$mats[0]} > -1) {
		$r = rand $#{$mats[0]}+1;
		$item = splice @{$mats[0]}, $r, 1;
		$index = splice @{$mats[1]}, $r, 1;
		push @{$newmats[0]}, $item;
		push @{$newmats[1]}, $index;
	}
	return @newmats;
}

1;

