package MyObj;

sub new {
	my $self = {};
	my $class = shift;
	bless $self, $class;
	return $self;
}

sub doSomething {
	print "Success!\n";
}

