$hat = 4;
if ($hat == 2 + 2) {
	print "$hat\n";
}
