import java.awt.*;
import java.awt.event.*;

public class MouseGraph extends Frame implements MouseListener {
	Label l;
	int x,y;
	public MouseGraph() {
		setSize(300,300);
		x = 150;
		y = 150;
		setLayout(new FlowLayout());
		addWindowListener(new Closer());
		addMouseListener(this);
		l = new Label("Click in the window.");
		l.setAlignment(Label.CENTER);
		add(l);
		show();
	}
	public void paint(Graphics g) {
		g.fillOval(x-5,y-5,10,10);
	}
	public void mouseClicked(MouseEvent e) {
		x = e.getX();
		y = e.getY();
		l.setText("x: " + x + ", y: " + y);
		repaint();
	}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public static void main(String argv[]) {
		new MouseGraph();
	}
}
