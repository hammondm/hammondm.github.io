public class FixIt1 {
	public static String deleteCharAt(String s, int i) {
		String suffix = s.substring(i+1);
		String prefix = s.substring(0,i);
		s = prefix + suffix;
		return s;
	}
	public static StringBuffer deleteCharAt(StringBuffer sb, int i) {
		return new StringBuffer(deleteCharAt(sb.toString(),i));
	}
	public static void main(String argv[]) {
		String str = argv[0];
		int n = Integer.parseInt(argv[1]);
		str = FixIt1.deleteCharAt(str,n);
		System.out.println(str);
	}
}

