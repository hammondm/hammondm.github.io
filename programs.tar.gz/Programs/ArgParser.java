public class ArgParser {
	String pat;
	String filename;
	String edge;
	public ArgParser(String[] a) {
		pat = a[0];
		filename = a[1];
		stripCheck();
	}
	void stripCheck() {
		if ((pat.indexOf("^") == 0) &&
				(pat.indexOf("$") == pat.length() - 1)) {
			pat = pat.substring(1,pat.length() - 1);
			edge = "if";
		} else if (pat.indexOf("^") == 0) {
			pat = pat.substring(1,pat.length());
			edge = "in";
		} else if (pat.indexOf("$") == pat.length() - 1) {
			pat = pat.substring(0,pat.length() - 1);
			edge = "nf";
		} else {
			edge = "nn";
		}
	}
	public String getPat() {
		return pat;
	}
	public String getFilename() {
		return filename;
	}
	public String getEdge() {
		return edge;
	}
}

