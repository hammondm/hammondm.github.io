public class ItemSet {
	private String sentence;
	private String question;
	private String code;
	public void putS(String s) {
		sentence = s;
	}
	public void putQ(String q) {
		question = q;
	}
	public void putC(String c) {
		code = c;
	}
	public String getS() {
		return sentence;
	}
	public String getQ() {
		return question;
	}
	public String getC() {
		return code;
	}
}
