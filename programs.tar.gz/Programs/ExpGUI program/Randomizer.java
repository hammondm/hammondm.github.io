import java.util.*;

public class Randomizer {
	Vector input, output;
	public Randomizer(Vector v) {
		input = v;
		output = new Vector();
		randomize();
	}
	private void randomize() {
		Random r = new Random();
		Enumeration e = input.elements();
		Object let;
		int max,current;
		while (e.hasMoreElements()) {
			let = e.nextElement();
			max = output.size();
			current = r.nextInt(max + 1);
			output.insertElementAt(let,current);
		}
	}
	public Vector getVec() {
		return output;
	}
}

