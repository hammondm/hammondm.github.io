import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class YesNoExp extends ExpGUI implements ActionListener {
	private Button yes,no,thankyou;
	private Label instructions,item;
	private Panel south;
	private Vector items;
	private Enumeration en;
	public void runExp() {
		instructions = new Label("Is this sentence grammatical?");
		instructions.setAlignment(Label.CENTER);
		instructions.setFont(new Font("Serif",Font.PLAIN,18));
		add("North",instructions);
		item = new Label("The example sentence goes here" +
			" and it can be quite long.");
		item.setAlignment(Label.CENTER);
		item.setFont(new Font("Serif",Font.PLAIN,24));
		add("Center",item);
		south = new Panel();
		yes = new Button("Yes");
		yes.setSize(100,100);
		yes.addActionListener(this);
		south.add(yes);
		no = new Button("No");
		no.setSize(100,100);
		no.addActionListener(this);
		south.add(no);
		add("South",south);
		thankyou = new Button("Thank you!");
		thankyou.addActionListener(this);
		pack();
		items = randomize(m.getItems());
		en = items.elements();
		item.setText((String) en.nextElement());
		show();
	}
	public void actionPerformed(ActionEvent e) {
		String result;
		if (en.hasMoreElements()) {
			result = code + "\t" + item.getText()
				+ "\t" + e.getActionCommand();
			results.addElement(result);
			item.setText((String) en.nextElement());
		} else if (yes.isVisible()) {
			result = code + "\t" + item.getText()
				+ "\t" + e.getActionCommand();
			results.addElement(result);
			item.setText("");
			yes.setVisible(false);
			no.setVisible(false);
			instructions.setText("Experiment completed.");
			south.add(thankyou);
			validate();
		} else {
			saveResults();
			System.exit(0);
		}
	}
	public static void main(String argv[]) {
		new YesNoExp();
	}
}

