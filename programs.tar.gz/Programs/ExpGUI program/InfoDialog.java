import java.awt.*;
import java.awt.event.*;

public class InfoDialog extends Dialog implements ActionListener {
	Button submit;
	Label label;
	TextField code;
	ExpGUI exp;
	public InfoDialog(ExpGUI e, String s, boolean b) {
		super(e,s,b);
		exp = e;
		setLayout(new FlowLayout());
		label = new Label("Subject code:");
		add(label);
		code = new TextField("",10);
		add(code);
		submit = new Button("Submit");
		submit.addActionListener(this);
		add(submit);
		pack();
		show();
	}
	public void actionPerformed(ActionEvent e) {
		exp.setCode(code.getText());
		dispose();
	}
}

