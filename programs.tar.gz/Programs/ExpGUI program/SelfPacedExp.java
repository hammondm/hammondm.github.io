import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class SelfPacedExp extends ExpGUI
		implements ActionListener, KeyListener {
	private Button yes,no,thankyou;
	private Label instructions,item;
	private Panel south;
	private Vector items;
	private Enumeration en;
	private ItemSet currentItemSet;
	private String currentS, currentQ, currentC;
	private StringTokenizer currentTokenizer;
	private boolean begunFlag;
	private final String INSTRUC1 = "Click the spacebar to advance.";
	private final String INSTRUC2 = "Answer the question.";
	private final String INSTRUC3 = "Thank you!";
	private long thisTime,lastTime,timeDiff,theRT;
	public void runExp() {
		begunFlag = false;
		instructions = new Label(INSTRUC1);
		instructions.setAlignment(Label.CENTER);
		instructions.setFont(new Font("Serif",Font.PLAIN,18));
		add("North",instructions);
		item = new Label("This can be a very long question " +
			"so there needs to be lots of room.");
		item.setAlignment(Label.CENTER);
		item.setFont(new Font("Serif",Font.PLAIN,24));
		add("Center",item);
		south = new Panel();
		yes = new Button("Yes");
		yes.setSize(100,100);
		yes.addActionListener(this);
		south.add(yes);
		no = new Button("No");
		no.setSize(100,100);
		no.addActionListener(this);
		south.add(no);
		add("South",south);
		thankyou = new Button("Thank you!");
		thankyou.addActionListener(this);
		pack();
		items = randomize(sortItems(m.getItems()));
		en = items.elements();
		item.setText("Press a key to begin.");
		yes.setEnabled(false);
		no.setEnabled(false);
		requestFocus();
		addKeyListener(this);
		show();
	}
	private Vector sortItems(Vector v) {
		Enumeration e = v.elements();
		ItemSet is;
		Vector outVec = new Vector();
		while (e.hasMoreElements()) {
			is = new ItemSet();
			is.putS((String) e.nextElement());
			is.putQ((String) e.nextElement());
			is.putC((String) e.nextElement());
			outVec.addElement(is);
		}
		return outVec;
	}
	public void keyTyped(KeyEvent e) {
		//if beginning of exp, advance to first sentence
		if (!begunFlag) {
			currentItemSet = (ItemSet) en.nextElement();
			currentS = currentItemSet.getS();
			currentQ = currentItemSet.getQ();
			currentC = currentItemSet.getC();
			currentTokenizer = new StringTokenizer(currentS);
			item.setText(currentTokenizer.nextToken());
			lastTime = System.currentTimeMillis();
			begunFlag = true;
		//if middle of sentence 
		} else if (currentTokenizer.hasMoreTokens()) {
			String temp = currentTokenizer.nextToken();
			thisTime = System.currentTimeMillis();
			timeDiff = thisTime - lastTime;
			//if middle of sentence and current word is RT, record this RT
			if (temp.equals("RT")) {
				temp = currentTokenizer.nextToken();
				theRT = timeDiff;
			}
			item.setText(temp);
			lastTime = thisTime;
		//if end of sentence, advance to question/buttons
		} else {
			thisTime = System.currentTimeMillis();
			timeDiff = thisTime - lastTime;
			yes.setEnabled(true);
			no.setEnabled(true);
			item.setText(currentQ);
			instructions.setText(INSTRUC2);
		}
	}
	public void keyPressed(KeyEvent e) {}
	public void keyReleased(KeyEvent e) {}
	public void actionPerformed(ActionEvent e) {
		String result;
		//if question, and there are more, advance to next sentence
		if (yes.isEnabled() && en.hasMoreElements()) {
			requestFocus();
			yes.setEnabled(false);
			no.setEnabled(false);
			result = code + "\t" + currentC + "\t" +
				e.getActionCommand() + "\t" + theRT;
			results.addElement(result);
			currentItemSet = (ItemSet) en.nextElement();
			currentS = currentItemSet.getS();
			currentQ = currentItemSet.getQ();
			currentC = currentItemSet.getC();
			currentTokenizer = new StringTokenizer(currentS);
			item.setText(currentTokenizer.nextToken());
			thisTime = System.currentTimeMillis();
		//if question, and there are not more, advance to thankyou
		} else if (yes.isEnabled()) {
			requestFocus();
			yes.setVisible(false);
			no.setVisible(false);
			yes.setEnabled(false);
			no.setEnabled(false);
			result = code + "\t" + currentC + "\t" +
				e.getActionCommand() + "\t" + theRT;
			results.addElement(result);
			south.add(thankyou);
			item.setText("");
			instructions.setText(INSTRUC3);
			validate();
		//if thankyou, quit
		} else {
			saveResults();
			System.exit(0);
		}
	}
	public static void main(String argv[]) {
		new SelfPacedExp();
	}
}

