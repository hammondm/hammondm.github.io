import java.awt.*;
import java.util.*;
import java.io.*;

public abstract class ExpGUI extends Frame {
	String filename,file,code,outfilename,outfile;
	Mats m;
	public Vector results;
	public ExpGUI() {
		results = new Vector();
		getInfo();
		runExp();
	}
	private void getInfo() {
		while (file == null) {
			FileDialog fd = new FileDialog(this,
				"Choose the materials file", FileDialog.LOAD);
			fd.show();
			file = fd.getFile();
			filename = fd.getDirectory() + file;
		}
		while (outfile == null) {
			FileDialog fd2 = new FileDialog(this,
				"Choose the results file", FileDialog.SAVE);
			fd2.show();
			outfile = fd2.getFile();
			outfilename = fd2.getDirectory() + outfile;
		}
		while ((code == null) || (code.equals(""))) {
			Dialog id = new InfoDialog(this,"Enter the subject number",true);
		}
		m = new Mats(filename);
	}
	public abstract void runExp();
	public Vector randomize(Vector v) {
		Randomizer r = new Randomizer(v);
		Vector temp = r.getVec();
		return temp;
	}
	public void setCode(String s) {
		code = s;
	}
	public void saveResults() {
		try {
			FileWriter fw = new FileWriter(outfilename,true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			Enumeration e = results.elements();
			String temp;
			while (e.hasMoreElements()) {
				temp = (String) e.nextElement();
				pw.println(temp);
				pw.flush();
			}
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

