public class WhileEx3 {
	public static void main(String argv[]) {
		int myInt;
		myInt = 0;
		while (myInt < 0) {
			System.out.println("myInt = " + myInt);
			myInt = myInt + 1;
		}
	}
}
