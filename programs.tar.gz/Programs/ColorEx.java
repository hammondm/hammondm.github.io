import java.awt.*;
import java.awt.event.*;

public class ColorEx extends Frame implements ActionListener {
	Color colors[] = {Color.black, Color.blue, Color.cyan,
			Color.darkGray, Color.gray, Color.green,
			Color.lightGray, Color.magenta, Color.orange,
			Color.pink, Color.red, Color.white, Color.yellow};
	int count;
	Button b;
	public ColorEx() {
		setSize(300,200);
		setLayout(new FlowLayout());
		addWindowListener(new Closer());
		b = new Button("Next Color");
		b.addActionListener(this);
		add(b);
		count = 0;
		setBackground(colors[count++]);
		show();
	}
	public void actionPerformed(ActionEvent e) {
		count++;
		if (count >= colors.length) {
			count = 0;
		}
		setBackground(colors[count]);
		repaint();
	}
	public static void main(String argv[]) {
		new ColorEx();
	}
}
