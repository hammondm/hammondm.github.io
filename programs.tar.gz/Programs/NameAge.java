import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class NameAge extends Applet implements ActionListener {
	private Panel top,center,bottom;
	private Label ageLabel,nameLabel;
	private TextField name,age;
	private Button submit;
	public void init() {
		setBackground(Color.white);
		setLayout(new BorderLayout());
		top = new Panel();
		center = new Panel();
		bottom = new Panel();
		ageLabel = new Label("Enter your age here");
		nameLabel = new Label("Enter your name here");
		name = new TextField(40);
		age = new TextField(5);
		submit = new Button("Submit");
		top.add(nameLabel);
		top.add(name);
		center.add(ageLabel);
		center.add(age);
		submit.addActionListener(this);
		bottom.add(submit);
		add("North",top);
		add("Center",center);
		add("South",bottom);
	}
	public void actionPerformed(ActionEvent e) {
		String results;
		results = "name=" + URLEncoder.encode(name.getText()) + "&" +
			"age=" + URLEncoder.encode(age.getText());
		try {
//			URL url = new URL(getCodeBase(),"thankyou.html?" + results);
//			URL url = new URL(getCodeBase(),"cgi-bin/nameagebridge.pl?" + results);
			URL url = new URL(getCodeBase(),"servlet/NameAgeServlet?" + results);
			getAppletContext().showDocument(url);
		} catch (Exception ex) {ex.printStackTrace();}
	}
}

