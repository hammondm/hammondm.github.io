import java.awt.*;

public class ButtonEx4OLD extends Frame {
	Button b;
	int i;
	public ButtonEx4OLD() {
		i = 1;
		setSize(300,300);
		setLayout(new FlowLayout());
		b = new Button("Press me!");
		add(b);
		show();
	}
	public boolean action(Event e, Object arg) {
		if (e.target.equals(b)) {
			System.out.println("Button press #" + i++);
			return true;
		}
		return false;
	}
	public boolean handleEvent(Event e) {
		if (e.id == Event.WINDOW_DESTROY) {
			System.exit(0);
		}
		return super.handleEvent(e);
	}
	public static void main(String argv[]) {
		new ButtonEx4OLD();
	}
}

