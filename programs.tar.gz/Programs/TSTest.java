import java.util.*;

public class TSTest {
	public static void main(String argv[]) {
		TreeSet ts = new TreeSet();
		for (int i = 0; i < argv.length; i++) {
			ts.add(argv[i]);
		}
		Iterator i = ts.iterator();
		String temp;
		while (i.hasNext()) {
			temp = (String) i.next();
			System.out.println(temp);
		}
	}
}
