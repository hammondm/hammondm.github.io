import java.applet.*;
import java.awt.*;
import java.net.*;

public class AppImg extends Applet {
	Image i;
	int bigX,bigY,littleX,littleY;
	public void init() {
		Dimension d1 = getSize();
		bigX = d1.width;
		bigY = d1.height;
		try {
			URL url = new URL(getCodeBase(),"puck.jpg");
			i = getImage(url);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void paint(Graphics g) {
		littleX = i.getWidth(this);
		littleY = i.getHeight(this);
		int x = (bigX / 2) - (littleX / 2);
		int y = (bigY / 2) - (littleY / 2);
		g.drawImage(i,x,y,this);
	}
}
