import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;

public class SoundProg extends Frame implements ActionListener {
	Button b;
	AudioClip ac;
	public SoundProg() {
		setSize(100,90);
		setLayout(new FlowLayout());
		addWindowListener(new Closer());
		b = new Button("Play");
		b.addActionListener(this);
		add(b);
		getTheClip();
		show();
	}
	private void getTheClip() {
		try {
			URL url = new URL("file:chirp1.au");
			ac = Applet.newAudioClip(url);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
	public void actionPerformed(ActionEvent e) {
		ac.play();
	}
	public static void main(String argv[]) {
		new SoundProg();
	}
}
