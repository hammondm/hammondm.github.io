import java.util.*;

public class IntVec {
	public static void main(String argv[]) {
		Vector v = new Vector();
		int i = 5;
		int j = 3;
		int k = 17;
		Integer ci = new Integer(i);
		Integer cj = new Integer(j);
		Integer ck = new Integer(k);
		v.addElement(ci);
		v.addElement(cj);
		v.addElement(ck);
		Enumeration e = v.elements();
		while (e.hasMoreElements()) {
			Integer temp = (Integer) e.nextElement();
			int t = temp.intValue();
			System.out.println(t);
		}
	}
}
