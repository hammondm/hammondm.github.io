import java.io.*;

public class DumbGrep5 {
	public static void main(String argv[]) {
		String argResults[] = new String[2];
		argResults = stripCheck(argv[0]);
		String word = argResults[0];
		String filename = argv[1];
		String optThird = argResults[1];
		String line;
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				if (findIt(line,word,optThird)) {
					System.out.println(line);
				}
			}
			fr.close();
		} catch (Exception e) {
			System.out.println("Uhoh!");
		}
	}
	public static String[] stripCheck(String s) {
		String results[] = new String[2];
		if ((s.indexOf("^") == 0) && (s.indexOf("$") == s.length() - 1)) {
			results[0] = s.substring(1,s.length() - 1);
			results[1] = "if";
		} else if (s.indexOf("^") == 0) {
			results[0] = s.substring(1,s.length());
			results[1] = "in";
		} else if (s.indexOf("$") == s.length() - 1) {
			results[0] = s.substring(0,s.length() - 1);
			results[1] = "nf";
		} else {
			results[0] = s;
			results[1] = "nn";
		}
		return results;
	}
	public static boolean findIt(String theLine,
			String theWord, String third) {
		int where;
		if (third.equals("in")) {
			if (theLine.indexOf(theWord) == 0) {
				return true;
			}
		} else if (third.equals("nf")) {
			where = theLine.indexOf(theWord) + theWord.length();
			if ((where == theLine.length()) &&
					(theLine.indexOf(theWord) > -1)) {
				return true;
			}
		} else if (third.equals("if")) {
			where = theLine.indexOf(theWord) + theWord.length();
			if ((where == theLine.length()) &&
					(theLine.indexOf(theWord) == 0)) {
				return true;
			}
		} else {
			if (theLine.indexOf(theWord) > -1) {
				return true;
			}
		}
		return false;
	}
}

