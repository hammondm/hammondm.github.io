import javax.swing.*;

public class SwingGraph extends JFrame {
	public SwingGraph() {
		setSize(200,300);
		addWindowListener(new Closer());
		getContentPane().add(new MyJPanel());
		show();
	}
	public static void main(String argv[]) {
		new SwingGraph();
	}
}
