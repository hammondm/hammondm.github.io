import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class AppWin extends Applet implements ActionListener {
	Button b;
	MyWindow mw;
	public void init() {
		b = new Button("Show window.");
		b.addActionListener(this);
		add(b);
		mw = new MyWindow();
	}
	public void actionPerformed(ActionEvent e) {
		mw.show();
	}
}

