import java.io.*;
import java.util.zip.*;

public class FileEx3 {
	public static void main(String argv[]) {
		try {
			FileOutputStream fos = new FileOutputStream("mh.gz");
			GZIPOutputStream gos = new GZIPOutputStream(fos);
			OutputStreamWriter osw = new OutputStreamWriter(gos);
			BufferedWriter bw = new BufferedWriter(osw);
			PrintWriter pw = new PrintWriter(bw);
			pw.println("This is a test");
			pw.flush();
			pw.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
