public class InsMeth {
	public void right() {
		System.out.println("This will work!");
	}
	public static void main(String argv[]) {
		InsMeth im = new InsMeth();
		im.right();
	}
}
