public class IfExample {
	public static void main(String argv[]) {
		int myInt;
		myInt = 1;
		if (myInt > 2) {
			System.out.println("big");
		}
	}
}
