public class VblTest2 {
	public static void main(String argv[]) {
		String hat;
		hat = "the purple house";
		System.out.println(hat);
		hat = "the red chair";
		System.out.println(hat);
	}
}
