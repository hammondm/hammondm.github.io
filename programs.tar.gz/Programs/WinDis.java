import java.awt.event.*;

public class WinDis extends WindowAdapter {
	MyWindow parent;
	public WinDis(MyWindow p) {
		parent = p;
	}
	public void windowClosing(WindowEvent e) {
		parent.dispose();
	}
}
