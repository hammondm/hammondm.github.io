import java.util.*;

public class Ran1 {
	public static void main(String argv[]) {
		Random r = new Random();
		int max = Integer.parseInt(argv[0]);
		int limit = Integer.parseInt(argv[1]);
		for (int i = 0; i < max; i++) {
			System.out.println(i + ": " + r.nextInt(limit));
		}
	}
}

