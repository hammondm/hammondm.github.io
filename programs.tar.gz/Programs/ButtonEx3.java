import java.awt.*;
import java.awt.event.*;

public class ButtonEx3 extends Frame implements WindowListener {
	Button b;
	public ButtonEx3() {
		addWindowListener(this);
		setSize(300,300);
		Panel p = new Panel();
		b = new Button("Do nothing");
		p.add(b);
		add(p);
		show();
	}
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
	public static void main(String argv[]) {
		ButtonEx3 be = new ButtonEx3();
	}
}

