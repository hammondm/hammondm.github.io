public class Daughter2 extends Parent2 {
	public static void main(String argv[]) {
		Daughter2 d = new Daughter2();
		System.out.println("d.n = " + d.n);
	}
}
