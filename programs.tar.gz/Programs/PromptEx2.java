import java.io.*;

public class PromptEx2 {
	public static void main(String argv[]) {
		System.out.print("Enter a line of text: ");
		System.out.flush();
		String theInput = "";
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		try {
			theInput = br.readLine();
			br.close();
		} catch (IOException e) {
			System.out.println("A problem occurred!");
		}
		System.out.println("You entered: " + theInput);
	}
}
