public class VblTest3 {
	public static void main(String argv[]) {
		System.out.println(2 + 3);
		int chair;
		int stool;
		chair = 4;
		stool = 10;
		chair = chair * stool;
		System.out.println(chair);
		System.out.println(chair / 3);
		System.out.println(chair % 7);
	}
}
