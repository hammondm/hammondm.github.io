public class Stimuli1 {
	public static void main(String argv[]) {
		String names[] = {"Mike", "Joe", "Diane", "Puck", "Artie", "Sunny", "Bob"};
		String verbs[] = {"see", "chase", "have fun with"};
		for (int i = 0; i < names.length; i++) {
			for (int j = 0; j < names.length; j++) {
				for (int k = 0; k < verbs.length; k++) {
					for (int m = 0; m < names.length; m++) {
						System.out.println(names[i] + " and " +
							names[j] + " " + verbs[k] + " " +
							names[m]);
					}
				}
			}
		}
	}
}

