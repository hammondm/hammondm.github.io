public class Try1 {
	public static void main(String argv[]) {
		System.out.println("starting...");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("Oops!");
		}
		System.out.println("Time's up!");
	}
}
