import java.awt.*;
import java.awt.event.*;

public class ChoiceEx1 extends Frame implements ItemListener {
	Choice c;
	public ChoiceEx1() {
		setSize(300,200);
		setLayout(new FlowLayout());
		addWindowListener(new Closer());
		c = new Choice();
		c.addItem("hat");
		c.addItem("chair");
		c.addItem("purple");
		c.addItemListener(this);
		add(c);
		show();
	}
	public void itemStateChanged(ItemEvent e) {
		int item = c.getSelectedIndex();
		switch (item) {
			case 0:
				System.out.println("clothing: " + c.getSelectedItem());
				break;
			case 1:
				System.out.println("furniture: " + c.getSelectedItem());
				break;
			default:
				System.out.println("color: " + c.getSelectedItem());
		}
	}
	public static void main(String argv[]) {
		new ChoiceEx1();
	}
}
