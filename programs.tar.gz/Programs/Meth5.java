public class Meth5 {
	public static void main(String argv[]) {
		for (int i = 0; i < argv.length; i++) {
			System.out.println(repeater(argv[i]));
		}
	}
	public static String repeater(String s) {
		return s + " " + s;
	}
}
