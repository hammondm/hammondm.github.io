import java.util.*;

public class FixItRan {
	public static void main(String argv[]) {
		Random r = new Random();
		int max = Integer.parseInt(argv[0]);
		int limit = Integer.parseInt(argv[1]);
		int num;
		for (int i = 0; i < max; i++) {
			num = Math.abs(r.nextInt()) % limit;
			System.out.println(i + ": " + num);
		}
	}
}

