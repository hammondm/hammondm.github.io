public class Meth4 {
	public static void main(String argv[]) {
		int n,m;
		n = Integer.parseInt(argv[0]);
		m = timesThirtySeven(n);
		System.out.println("The result is: " + m);
	}
	public static int timesThirtySeven(int k) {
		return k * 37;
	}
}
