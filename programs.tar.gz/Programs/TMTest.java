import java.util.*;

public class TMTest {
	public static void main(String argv[]) {
		TreeMap t = new TreeMap();
		t.put(new String("hat"),new Integer(5));
		t.put(new String("chair"),new Integer(1));
		t.put(new String("people"),new Integer(35));
		Iterator i = t.keySet().iterator();
		while (i.hasNext()) {
			String s = (String) i.next();
			Integer myInt = (Integer) t.get(s);
			System.out.println(s + ":\t" + myInt.toString());
		}
	}
}

