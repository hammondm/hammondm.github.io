import java.io.*;
import java.util.*;

public class Util1 {
	public static void main(String argv[]) {
		String line, word;
		StringTokenizer st;
		try {
			FileReader fr = new FileReader(argv[0]);
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				st = new StringTokenizer(line);
				while (st.hasMoreTokens()) {
					word = st.nextToken();
					System.out.println(word);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
