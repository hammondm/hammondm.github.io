public class Vbloo3 {
	int n;
	public Vbloo3(String k) {
		n = Integer.parseInt(k);
		printIt();
	}
	public void printIt() {
		System.out.println("n = " + n);
	}
	public static void main(String argv[]) {
		Vbloo3 vb1 = new Vbloo3(argv[0]);
	}
}
