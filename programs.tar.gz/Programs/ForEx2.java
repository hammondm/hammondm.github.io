public class ForEx2 {
	public static void main(String argv[]) {
		for (int i = 10; i > 0; i--) {
			System.out.println("the value of i is " + i);
		}
	}
}

