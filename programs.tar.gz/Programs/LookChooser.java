import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class LookChooser extends JFrame implements ActionListener {
	ButtonGroup bg;
	JRadioButton metal,windows,motif;
	JButton quit;
	public LookChooser() {
		quit = new JButton("Quit");
		quit.addActionListener(this);
		addWindowListener(new Closer());
		getContentPane().setLayout(new FlowLayout());
		metal = new JRadioButton("Metal");
		metal.addActionListener(this);
		metal.setSelected(true);
		windows = new JRadioButton("Windows");
		windows.addActionListener(this);
		motif = new JRadioButton("Motif");
		motif.addActionListener(this);
		bg = new ButtonGroup();
		bg.add(metal);
		bg.add(windows);
		bg.add(motif);
		getContentPane().add(metal);
		getContentPane().add(windows);
		getContentPane().add(motif);
		getContentPane().add(quit);
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		pack();
		show();
	}
	public void actionPerformed(ActionEvent e) {
		String name = e.getActionCommand();
		String look = "";
		if (name.equals("Metal")) {
			look = "javax.swing.plaf.metal.MetalLookAndFeel";
		} else if (name.equals("Windows")) {
			look = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
		
		} else if (name.equals("Motif")) {
			look = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
		} else if (name.equals("Quit")) {
			System.exit(0);
		}
		try {
			UIManager.setLookAndFeel(look);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		SwingUtilities.updateComponentTreeUI(this);
		pack();
	}
	public static void main(String argv[]) {
		new LookChooser();
	}
}

