import javax.swing.*;
import java.awt.*;

public class MyJPanel extends JPanel {
	public void paintComponent(Graphics g) {
		g.drawLine(15,50,100,50);
		g.drawOval(15,100,30,30);
		g.fillRect(15,150,100,80);
	}
}
