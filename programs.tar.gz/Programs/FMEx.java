import java.awt.*;
import java.awt.event.*;

public class FMEx extends Frame implements ComponentListener {
	public FMEx() {
		addWindowListener(new Closer());
		setSize(300,300);
		show();
	}
	public void paint(Graphics g) {
		String s = "This is a test.";
		Dimension d = getSize();
		int x = d.width / 2;
		int y = d.height / 2;
		g.setFont(new Font("Serif",Font.PLAIN,18));
		FontMetrics fm = g.getFontMetrics();
		int width = fm.stringWidth(s);
		int height = fm.getHeight();
		int newX = x - (width / 2);
		int newY = y + (height / 2);
		g.drawString(s,newX,newY);
	}
	public void componentHidden(ComponentEvent e) {}
	public void componentMoved(ComponentEvent e) {}
	public void componentResized(ComponentEvent e) {
		repaint();
	}
	public void componentShown(ComponentEvent e) {}
	public static void main(String argv[]) {
		new FMEx();
	}
}
