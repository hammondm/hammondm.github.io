public class Adjective extends Word {
	public Adjective(String s) {
		super(s);
		setPos("adjective");
	}
	public Adjective(String s, boolean b) {
		super(s,b);
		setPos("adjective");
	}
	public String getInfo() {
		String theInfo = "part of speech: " + getPos() + "\n";
		theInfo = theInfo + "borrowed: ";
		if (getBorrowed()) {
			theInfo = theInfo + "yes\n";
		} else {
			theInfo = theInfo + "no\n";
		}
		return theInfo;
	}
}
