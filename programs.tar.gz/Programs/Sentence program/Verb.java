import java.io.*;

public class Verb extends Word {
	private boolean transitive;
	public Verb(String s) {
		super(s);
		setPos("verb");
		setTransitive();
	}
	public Verb(String s, boolean b, boolean t) {
		super(s,b);
		setPos("verb");
		transitive = t;
	}
	private void setTransitive() {
		System.out.print("Is the verb transitive? (y/n): ");
		try {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			String answer = br.readLine();
			if (answer.equals("y")) {
				transitive = true;
			} else {
				transitive = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean getTransitive() { return transitive; }
	public String getInfo() {
		String theInfo = "part of speech: " + getPos() + "\n";
		theInfo = theInfo + "borrowed: ";
		if (getBorrowed()) {
			theInfo = theInfo + "yes\n";
		} else {
			theInfo = theInfo + "no\n";
		}
		theInfo = theInfo + "transitive: ";
		if (getTransitive()) {
			theInfo = theInfo + "yes\n";
		} else {
			theInfo = theInfo + "no\n";
		}
		return theInfo;
	}
}
