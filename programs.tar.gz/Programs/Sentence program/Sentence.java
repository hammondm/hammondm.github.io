import java.io.*;

public class Sentence {
	Word[] sentence;
	static final String POS = "nvao";
	public Sentence(String[] words) {
		sentence = new Word[words.length];
		query(words);
	}
	private void query(String[] s) {
		String line;
		try {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			for (int i = 0; i < sentence.length; i++) {
				line = "";
				while ((POS.indexOf(line) < 0) || (line.length() != 1)) {
					System.out.print("\"" + s[i] + "\": noun(n), " +
						"verb(v), adjective(a), other(o): ");
					line = br.readLine();
				}
				makeWord(s[i],line,i);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void makeWord(String word, String pos, int index) {
		System.out.println("word: " + word + ", pos: " + pos);
		if (pos.equals("n")) {
			sentence[index] = new Noun(word);
		} else if (pos.equals("v")) {
			sentence[index] = new Verb(word);
		} else if (pos.equals("a")) {
			sentence[index] = new Adjective(word);
		} else {
			sentence[index] = new Other(word);
		}
	}
	public String getInfo() {
		String info = "";
		for (int i = 0; i < sentence.length; i++) {
			info = info + sentence[i].getWord() +
				"\n" + sentence[i].getInfo();
		}
		return info;
	}
	public static void main(String argv[]) {
		Sentence s = new Sentence(argv);
		System.out.println(s.getInfo());
	}
}

