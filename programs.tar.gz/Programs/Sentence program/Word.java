import java.io.*;

public abstract class Word {
	private String word, pos;
	private boolean borrowed;
	public Word(String s) {
		word = s;
		setBorrowed();
	}
	public Word(String s, boolean b) {
		word = s;
		borrowed = b;
	}
	private void setBorrowed() {
		System.out.print("Is the word borrowed? (y/n): ");
		try {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			String answer = br.readLine();
			if (answer.equals("y")) {
				borrowed = true;
			} else {
				borrowed = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean getBorrowed() { return borrowed; }
	public String getWord() { return word; }
	public void setPos(String s) { pos = s; }
	public String getPos() { return pos; }
	abstract String getInfo();
}

