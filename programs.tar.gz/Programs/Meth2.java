public class Meth2 {
	public static void main(String argv[]) {
		test("1");
		test("2");
	}
	public static void test(String s) {
		System.out.println("This is test number " + s);
	}
}
