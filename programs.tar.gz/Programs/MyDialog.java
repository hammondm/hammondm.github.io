import java.awt.*;
import java.awt.event.*;

public class MyDialog extends Dialog implements ActionListener {
	Button a,b;
	DialogFrame parent;
	public MyDialog(DialogFrame f) {
		super(f,true);
		parent = f;
		setSize(100,100);
		setLayout(new FlowLayout());
		a = new Button("A");
		b = new Button("B");
		a.addActionListener(this);
		b.addActionListener(this);
		add(a);
		add(b);
		show();
	}
	public void actionPerformed(ActionEvent e) {
		parent.l.setText("You pressed button: " + e.getActionCommand());
		dispose();
	}
}
