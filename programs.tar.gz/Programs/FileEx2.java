import java.io.*;

public class FileEx2 {
	public static void main(String argv[]) {
		String line = "";
		try {
			FileReader fr = new FileReader("mh.txt");
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
			fr.close();
		} catch (IOException e) {
			System.out.println("Something went wrong!");
		}
	}
}
