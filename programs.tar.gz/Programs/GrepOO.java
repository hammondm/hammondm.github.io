public class GrepOO {
	public GrepOO(String[] a) {
		ArgParser ap = new ArgParser(a);
		MyReader mr = new MyReader(ap);
	}
	public static void main(String argv[]) {
		GrepOO g = new GrepOO(argv);
	}
}

