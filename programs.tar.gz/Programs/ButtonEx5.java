import java.awt.*;
import java.awt.event.*;

public class ButtonEx5 extends Frame
		implements WindowListener, ActionListener {
	Button b;
	int i;
	public ButtonEx5() {
		i = 1;
		addWindowListener(this);
		setLayout(new FlowLayout());
		setSize(300,300);
		b = new Button("Press me!");
		b.addActionListener(this);
		add(b);
		show();
	}
	public void actionPerformed(ActionEvent e) {
		System.out.println("Button press #" + i++);
	}
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
	public static void main(String argv[]) {
		ButtonEx5 be = new ButtonEx5();
	}
}

