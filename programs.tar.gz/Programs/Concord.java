import java.util.*;

public class Concord {
	private Hashtable h;
	private Vector lines;
	public Concord(String f) {
		h = new Hashtable();
		VReader vr = new VReader(f);
		lines = vr.getLines();
		makeConc();
	}
	private void makeConc() {
		Enumeration e1 = lines.elements();
		StringTokenizer st;
		String line, word;
		while (e1.hasMoreElements()) {
			line = (String) e1.nextElement();
			st = new StringTokenizer(line," \t\n.");
			while (st.hasMoreTokens()) {
				word = st.nextToken();
				doConc(word);
			}
		}
	}
	private void doConc(String w) {
		Integer i;
		if (h.containsKey(w)) {
			i = (Integer) h.get(w);
			int myInt = i.intValue();
			myInt++;
			i = new Integer(myInt);
		} else {
			i = new Integer(1);
		}
		h.put(w,i);
	}
	public Hashtable getConc() {
		return h;
	}
	public static void main(String argv[]) {
		Concord c = new Concord(argv[0]);
		Hashtable theHash = c.getConc();
		Enumeration e = theHash.keys();
		String temp1, temp2;
		Integer i;
		while (e.hasMoreElements()) {
			temp1 = (String) e.nextElement();
			i = (Integer) theHash.get(temp1);
			temp2 = i.toString();
			System.out.println(temp1 + ":\t" + temp2);
		}
	}
}

