public class WhileEx1 {
	public static void main(String argv[]) {
		int myInt;
		myInt = 0;
		while (myInt < 10) {
			System.out.println("myInt = " + myInt);
			myInt = myInt + 1;
		}
	}
}
