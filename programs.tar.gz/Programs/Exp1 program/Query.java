import java.io.*;

public abstract class Query {
	String preamble, finish, subject, filename;
	String[] items;
	String[] results;
	public Query(Materials m, String s) {
		items = m.getItems();
		subject = s;
		results = new String[items.length];
		preamble = "";
		finish = "";
		filename = "";
		makeBits();
		display();
		saveResults();
	}
	/* Use this class to create the experimental task. The question is put into
	 * the 'preamble'. The type of response accepted is put into 'finish', The
	 * filename is also specified here. */
	abstract void makeBits();
	/* To present a more complex experiment, e.g. one recording reaction times or
	 * displaying graphics, the display() method must be redefined. */
	private void display() {
		try {
			InputStreamReader isr;
			isr = new InputStreamReader(System.in);
			BufferedReader br;
			br = new BufferedReader(isr);
			for (int i = 0; i < items.length; i++) {
				System.out.println();
				System.out.println(preamble);
				System.out.println(items[i]);
				System.out.print(finish);
				System.out.flush();
				results[i] = br.readLine();
			}
			br.close();
		} catch (Exception e) {
			System.out.println("Something went wrong. Please inform" +
				" the experimentor");
		}
	}
	private void saveResults() {
		try {
			FileWriter fr = new FileWriter(filename,true);
			BufferedWriter br = new BufferedWriter(fr);
			PrintWriter pw = new PrintWriter(br);
			for (int i = 0; i < results.length; i++) {
				pw.println(subject + "\t" + items[i] + "\t" + results[i]);
			}
			pw.flush();
			fr.close();
		} catch (Exception e) {
			System.out.println("Error writing to results file.");
		}
	}
}

