public class YesNoQuery extends Query {
	public YesNoQuery(Materials m, String s) {
		super(m,s);
	}
	void makeBits() {
		preamble = "Is this question grammatical?";
		finish = "yes(y) or no(n): ";
		filename = "exptest.txt";
	}
}

