public class CLEx1 {
	public static void main(String argv[]) {
		System.out.println(argv[0]);
	}
}
