import java.awt.*;
import java.awt.event.*;

public class ButtonEx4 extends Frame implements ActionListener {
	Button b;
	int i;
	public ButtonEx4() {
		i = 1;
		addWindowListener(new Closer());
		setSize(300,300);
		setLayout(new FlowLayout());
		b = new Button("Press me!");
		b.addActionListener(this);
		add(b);
		show();
	}
	public void actionPerformed(ActionEvent e) {
		System.out.println("Button press #" + i++);
	}
	public static void main(String argv[]) {
		ButtonEx4 be = new ButtonEx4();
	}
}

