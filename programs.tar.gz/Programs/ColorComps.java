import java.awt.*;
import java.awt.event.*;

public class ColorComps extends Frame
		implements ActionListener, ItemListener {
	Color colors[] = {Color.black, Color.blue, Color.cyan,
			Color.darkGray, Color.gray, Color.green,
			Color.lightGray, Color.magenta, Color.orange,
			Color.pink, Color.red, Color.white, Color.yellow};
	String cnames[] = {"black","blue","cyan",
			"dark gray", "gray", "green",
			"light gray", "magenta", "orange",
			"pink", "red", "white", "yellow"};
	int count;
	Button b;
	Choice c;
	CheckboxGroup cbg;
	Checkbox cb[] = new Checkbox[13];
	Panel p1,p2;
	public ColorComps() {
		setSize(300,200);
		addWindowListener(new Closer());
		b = new Button("Next Color");
		b.addActionListener(this);
		p1 = new Panel();
		p1.add(b);
		c = new Choice();
		for (int i = 0; i < cnames.length; i++) {
			c.addItem(cnames[i]);
		}
		c.addItemListener(this);
		p1.add(c);
		add("North",p1);
		count = 0;
		b.setBackground(colors[count++]);
		p2 = new Panel();
		cbg = new CheckboxGroup();
		for (int i = 0; i < cb.length; i++) {
			cb[i] = new Checkbox(cnames[i],cbg,false);
			cb[i].setBackground(colors[i]);
			cb[i].addItemListener(this);
			p2.add(cb[i]);
		}
		add("Center",p2);
		show();
	}
	public void actionPerformed(ActionEvent e) {
		count++;
		if (count >= colors.length) {
			count = 0;
		}
		b.setBackground(colors[count]);
	}
	public void itemStateChanged(ItemEvent e) {
		c.setBackground(colors[c.getSelectedIndex()]);
		Checkbox temp = cbg.getSelectedCheckbox();
		if (temp != null) {
			for (int i = 0; i < cb.length; i++) {
				if (temp.equals(cb[i])) {
					p1.setBackground(colors[i]);
					p1.repaint();
					p2.setBackground(colors[i]);
					p2.repaint();
				}
			}
		}
	}
	public static void main(String argv[]) {
		new ColorComps();
	}
}

