import gnu.regexp.*;
import java.io.*;

public class GnuREEx {
	public GnuREEx(String pat, String file) {
		String line = "";
		try {
			RE re = new RE(pat);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				if (re.getMatch(line) != null) {
					System.out.println(line);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String argv[]) {
		new GnuREEx(argv[0],argv[1]);
	}
}

