public class Apple {
	public Apple(String loc) {
		System.out.println("My apple is on my " + loc);
	}
	public static String growWhere() {
		return "trees";
	}
	public static void main(String argv[]) {
		System.out.println("Apples grow on " + growWhere());
		Apple myApple = new Apple(argv[0]);
	}
}
