import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class FileDiaEx extends Frame implements ActionListener {
	Button open,clear,quit;
	TextArea ta;
	public FileDiaEx() {
		open = new Button("Open");
		clear = new Button("Clear");
		quit = new Button("Quit");
		ta = new TextArea("",20,80,TextArea.SCROLLBARS_BOTH);
		ta.setEditable(false);
		open.addActionListener(this);
		clear.addActionListener(this);
		quit.addActionListener(this);
		Panel p1 = new Panel();
		p1.add(open);
		p1.add(clear);
		p1.add(quit);
		add("North",p1);
		add("Center",ta);
		pack();
		show();
	}
	public void actionPerformed(ActionEvent e) {
		String temp = e.getActionCommand();
		if (temp.equals("Open")) {
			readTheFile();
		} else if (temp.equals("Clear")) {
			ta.setText("");
		} else {
			System.exit(0);
		}
	}
	private void readTheFile() {
		FileDialog fd = new FileDialog(this);
		fd.show();
		String filename = fd.getFile();
		String dir = fd.getDirectory();
		String fileContents = "";
		String line = "";
		try {
			FileReader fr = new FileReader(dir + filename);
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				fileContents = fileContents + "\n" + line;
			}
			br.close();
		} catch (Exception e) {
			fileContents = "File not readable!";
		}
		ta.setText(fileContents);
	}
	public static void main(String argv[]) {
		new FileDiaEx();
	}
}

