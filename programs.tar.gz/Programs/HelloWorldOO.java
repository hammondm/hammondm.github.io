public class HelloWorldOO {
	public HelloWorldOO() {
		System.out.println("Hello World!");
	}
	public static void main(String argv[]) {
		new HelloWorldOO();
	}
}

