import java.io.*;

public class FileEx1 {
	public static void main(String argv[]) {
		try {
			FileWriter fw = new FileWriter("mh.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			pw.println("This is a test.");
			pw.flush();
			fw.close();
		} catch (IOException e) {
			System.out.println("Something went wrong!");
		}
	}
}
