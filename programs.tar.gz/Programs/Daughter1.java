public class Daughter1 extends Parent1 {
	public static void main(String argv[]) {
		Daughter1 d = new Daughter1();
		d.printSomething("an inherited method");
	}
}
