import java.io.*;

public class DumbGrep1 {
	public static void main(String argv[]) {
		String word = argv[0];
		String filename = argv[1];
		String line;
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				if (line.indexOf(word) > -1) {
					System.out.println(line);
				}
			}
			fr.close();
		} catch (Exception e) {
			System.out.println("Uhoh!");
		}
	}
}

