import java.io.*;
import java.util.*;

public class ArrVec {
	public static void main(String argv[]) {
		Vector v = new Vector();
		String a[] = new String[0];
		String line;
		int count = 0;
		try {
			FileReader fr = new FileReader("exp.txt");
			BufferedReader br = new BufferedReader(fr);
			int max = Integer.parseInt(br.readLine());
			a = new String[max];
			while ((line = br.readLine()) != null) {
				a[count++] = line;
				v.addElement(line);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("array contents");
		for (count = 0; count < a.length; count++) {
			System.out.println(a[count]);
		}
		System.out.println("vector contents");
		Enumeration e = v.elements();
		while (e.hasMoreElements()) {
			System.out.println((String) e.nextElement());
		}
	}
}

