public class HWCaller {
	public static void main(String argv[]) {
		new HelloWorldOO();
	}
}
