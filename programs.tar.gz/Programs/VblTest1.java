public class VblTest1 {
	public static void main(String argv[]) {
		String hat;
		int chair;
		hat = "the purple house";
		System.out.println(hat);
		chair = 13;
		System.out.println(chair);
	}
}
