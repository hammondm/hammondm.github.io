public class IfEx4 {
	public static void main(String argv[]) {
		int myInt;
		myInt = 1;
		if (myInt > 2) {
			System.out.println("big");
		} else if ( myInt == 2) {
			System.out.println("2!");
		} else {
			System.out.println("small");
		}
	}
}
