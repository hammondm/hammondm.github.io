import java.applet.*;

import java.awt.*;

import java.awt.event.*;



public class AppSound extends Applet implements ActionListener {

	Button b;

	AudioClip ac;

	public void init() {

		b = new Button("Play");

		String s = getParameter("THEFILE");

		ac = getAudioClip(getCodeBase(),s);

		b.addActionListener(this);

		add(b);

	}

	public void actionPerformed(ActionEvent e) {

		ac.play();

	}

}

