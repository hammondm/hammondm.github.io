public class Parent2 {

	int n;

	public Parent2() {

		n = 2;

	}

}

