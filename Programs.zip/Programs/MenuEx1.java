import java.awt.*;

import java.awt.event.*;



public class MenuEx1 extends Frame implements ActionListener {

	MenuBar mb;

	Menu m1;

	MenuItem mi1, mi2;

	public MenuEx1() {

		setSize(300,200);

		addWindowListener(new Closer());

		mb = new MenuBar();

		m1 = new Menu("Test Menu");

		mi1 = new MenuItem("Item #1");

		mi2 = new MenuItem("Item #2");

		mi1.setActionCommand("1");

		mi2.setActionCommand("2");

		m1.add(mi1);

		m1.add(mi2);

		m1.addActionListener(this);

		mb.add(m1);

		setMenuBar(mb);

		show();

	}

	public void actionPerformed(ActionEvent e) {

		System.out.println(e.getActionCommand());

	}

	public static void main(String argv[]) {

		new MenuEx1();

	}

}



