public class ForEx1 {

	public static void main(String argv[]) {

		for (int i = 0; i < 10; i++) {

			System.out.println("the value of i is " + i);

		}

	}

}



