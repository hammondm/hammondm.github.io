public class VblTest4 {

	public static void main(String argv[]) {

		String hat;

		hat = "This " + "is " + "a " + "long " + "string.";

		System.out.println(hat);

		hat = hat + " Uhoh!";

		System.out.println(hat);

		hat = "2" + "3";

		System.out.println(hat);

	}

}

