import java.io.*;

import java.util.*;

import javax.servlet.*;

import javax.servlet.http.*;



public class NameAgeServlet extends HttpServlet {

	public void doGet (HttpServletRequest req, HttpServletResponse res)

			throws ServletException, IOException {

		String query = req.getQueryString();

		Date today = new Date();

		FileWriter fw = new FileWriter("nameage.txt",true);

		BufferedWriter bw = new BufferedWriter(fw);

		PrintWriter pw = new PrintWriter(bw);

                pw.println(today.toString() + "\t" + query);

		pw.flush();

		pw.close();

		res.setContentType("text/html");

		PrintWriter out = res.getWriter();

		out.println("<html><head><title>Thank you</title></head>");

		out.println("<body>Thank you!</body></html>");

	}

}

