import java.util.*;



public class FixIt2 {

	public static String[] sortKeys (Hashtable h) {

		int size = h.size();

		Enumeration e = h.keys();

		String[] theKeys = new String[size];

		int j = 0;

		while (e.hasMoreElements()) {

			theKeys[j] = (String) e.nextElement();

			j++;

		}

		j = 0;

		String temp;

		for (int i = 1; i < theKeys.length; i++) {

			temp = theKeys[i];

			for (j = i; j > 0 && temp.compareTo(theKeys[j-1]) < 0; j--) {

				theKeys[j] = theKeys[j-1];

			}

			theKeys[j] = temp;

		}

		return theKeys;

	}

}



