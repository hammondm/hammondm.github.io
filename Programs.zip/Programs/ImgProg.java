import java.awt.*;



public class ImgProg extends Frame {

	Image i;

	int bigX,bigY;

	public ImgProg() {

		bigX = 550;

		bigY = 550;

		setSize(bigX,bigY);

		addWindowListener(new Closer());

		i = Toolkit.getDefaultToolkit().getImage("puck.jpg");

		show();

	}

	public void paint(Graphics g) {

		int littleX = i.getWidth(this);

		int littleY = i.getHeight(this);

		int x = (bigX / 2) - (littleX / 2);

		int y = (bigY / 2) - (littleY / 2);

		g.drawImage(i,x,y,this);

	}

	public static void main(String argv[]) {

		new ImgProg();

	}

}

