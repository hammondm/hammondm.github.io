import java.applet.*;

import java.awt.*;



public class SimpleApp1 extends Applet {

	Label l;

	public void init() {

		setBackground(Color.yellow);

		l = new Label("This is a boring applet.");

		add(l);

	}

}

