import java.awt.*;

import java.awt.event.*;



public class DialogFrame extends Frame implements ActionListener {

	Button b1,b2;

	Label l;

	public DialogFrame() {

		setSize(300,200);

		setLayout(new FlowLayout());

		b1 = new Button("Dialog");

		b2 = new Button("Quit");

		l = new Label("This is the parent window.");

		b1.addActionListener(this);

		b2.addActionListener(this);

		add(b1);

		add(b2);

		add(l);

		show();

	}

	public void actionPerformed(ActionEvent e) {

		String temp = e.getActionCommand();

		if (temp.equals("Dialog")) {

			new MyDialog(this);

		} else {

			System.exit(0);

		}

	}

	public static void main(String argv[]) {

		new DialogFrame();

	}

}



