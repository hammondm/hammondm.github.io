import java.io.*;



public class DumbGrep2 {

	public static void main(String argv[]) {

		String word = argv[0];

		String filename = argv[1];

		String line;

		try {

			FileReader fr = new FileReader(filename);

			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null) {

				if (findIt(line,word)) {

					System.out.println(line);

				}

			}

			fr.close();

		} catch (Exception e) {

			System.out.println("Uhoh!");

		}

	}

	public static boolean findIt(String theLine, String theWord) {

		if (theLine.indexOf(theWord) > -1) {

			return true;

		} else {

			return false;

		}

	}

}



