import java.util.*;



public class ConcordCaller {

	public static void main(String argv[]) {

		Concord conc = new Concord(argv[0]);

		Hashtable results = conc.getConc();

		String[] myKeys = FixIt2.sortKeys(results);

		for (int i = 0; i < myKeys.length; i++) {

			String theKey = myKeys[i];

			String theValue = ((Integer) results.get(theKey)).toString();

			System.out.println(theKey + ": " + theValue);

		}

	}

}



