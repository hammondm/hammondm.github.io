#!perl

exec("javaw NameAgeCGI $ENV{QUERY_STRING}");



