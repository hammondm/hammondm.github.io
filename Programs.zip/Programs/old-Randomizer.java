import java.util.*;



public class Randomizer {

	Vector input, output;

	public Randomizer(Vector v) {

		input = v;

		output = new Vector();

		randomize();

	}

	private void randomize() {

		Random r = new Random();

		Enumeration e = input.elements();

		String let;

		int max,current;

		while (e.hasMoreElements()) {

			let = (String) e.nextElement();

			max = output.size();

			current = r.nextInt(max + 1);

			output.insertElementAt(let,current);

		}

	}

	public Vector getVec() {

		return output;

	}

	public static void main(String argv[]) {

		Vector testVec = new Vector();

		for (int i = 0; i < argv.length; i++) {

			testVec.addElement(argv[i]);

		}

		Randomizer ran = new Randomizer(testVec);

		Vector resVec = ran.getVec();

		Enumeration e = resVec.elements();

		String letter;

		while (e.hasMoreElements()) {

			letter = (String) e.nextElement();

			System.out.println(letter);

		}

	}

}



