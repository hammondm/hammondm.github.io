public class Daughter3 extends Parent2 {

	int n;

	public Daughter3() {

		n = 5;

	}

	public static void main(String argv[]) {

		Daughter3 d = new Daughter3();

		System.out.println("d.n = " + d.n);

	}

}

