import java.io.*;

import java.util.*;

import java.net.*;



public class NameAgeCGI {

	public NameAgeCGI(String s) {

		String theInput = "";

		try {

			theInput = URLDecoder.decode(s);

		} catch (Exception e) {

			e.printStackTrace();

		}

		Date today = new Date();

		try {

			FileWriter fw = new FileWriter("nameage.txt",true);

			BufferedWriter bw = new BufferedWriter(fw);

			PrintWriter pw = new PrintWriter(bw);

			pw.println(today.toString() + "\t" + theInput);

			pw.flush();

			pw.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

		System.out.println("Content-type: text/html\n\n");

		System.out.println("<html><head><title>Thank you!</title></head>");

		System.out.println("<body>Thank you</body></html>");

	}

	public static void main(String argv[]) {

		new NameAgeCGI(argv[0]);

	}

}



