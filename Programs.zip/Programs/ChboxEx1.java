import java.awt.*;

import java.awt.event.*;



public class ChboxEx1 extends Frame implements ItemListener {

	Checkbox a,b,c;

	CheckboxGroup cbg;

	public ChboxEx1() {

		setSize(300,200);

		setLayout(new FlowLayout());

		addWindowListener(new Closer());

		cbg = new CheckboxGroup();

		a = new Checkbox("a",cbg,false);

		b = new Checkbox("b",cbg,false);

		c = new Checkbox("c",false);

		a.addItemListener(this);

		b.addItemListener(this);

		c.addItemListener(this);

		add(a);

		add(b);

		add(c);

		show();

	}

	public void itemStateChanged(ItemEvent e) {

		if (a.getState()) {

			System.out.println("a is selected.");

		}

		if (b.getState()) {

			System.out.println("b is selected.");

		}

		if (c.getState()) {

			System.out.println("c is selected.");

		}

	}

	public static void main(String argv[]) {

		new ChboxEx1();

	}

}

