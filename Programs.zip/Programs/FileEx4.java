import java.io.*;

import java.util.zip.*;



public class FileEx4 {

	public static void main(String argv[]) {

		String line = "";

		try {

			FileInputStream fis = new FileInputStream("mh.gz");

			GZIPInputStream gis = new GZIPInputStream(fis);

			InputStreamReader isr = new InputStreamReader(gis);

			BufferedReader br = new BufferedReader(isr);

			while ((line = br.readLine()) != null) {

				System.out.println(line);

			}

			br.close();

		} catch (IOException e) {

			System.out.println(e.getMessage());

		}

	}

}

