public class Meth1 {

	public static void main(String argv[]) {

		test();

	}

	public static void test() {

		System.out.println("This is a test.");

	}

}

