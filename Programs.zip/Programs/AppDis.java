import java.applet.*;

import java.awt.*;

import java.io.*;

import java.net.*;



public class AppDis extends Applet {

	TextArea ta;

	String filename;

	public void init() {

		setLayout(new BorderLayout());

		ta = new TextArea("");

		add("Center",ta);

		filename = getParameter("THEFILE");

		String theText = getText();

		ta.setText(theText);

	}

	private String getText() {

		String temp = "";

		String line;

		try {

			URL url = new URL(getCodeBase(),filename);

			InputStreamReader isr = new InputStreamReader(url.openStream());

			BufferedReader br = new BufferedReader(isr);

			while ((line = br.readLine()) != null) {

				temp = temp + "\n" + line;

			}

			br.close();

		} catch (Exception e) {

			temp = "Couldn't open URL!";

		}

		return temp;

	}

}

