import java.awt.*;

import java.awt.event.*;



public class ButtonEx6 extends Frame implements ActionListener {

	Button b1,b2,b3;

	public ButtonEx6() {

		addWindowListener(new Closer());

		setSize(300,300);

		setLayout(new FlowLayout());

		b1 = new Button("1");

		b2 = new Button("2");

		b3 = new Button("3");

		b1.addActionListener(this);

		b2.addActionListener(this);

		b3.addActionListener(this);

		b2.setActionCommand("hat");

		add(b1);

		add(b2);

		add(b3);

		show();

	}

	public void actionPerformed(ActionEvent e) {

		String temp = e.getActionCommand();

		if (temp.equals("1")) {

			System.out.println("Button 1 pressed.");

		} else if (temp.equals("hat")) {

			System.out.println("Button 2 pressed.");

		} else {

			System.out.println("Button 3 pressed.");

		}

	}

	public static void main(String argv[]) {

		ButtonEx6 be = new ButtonEx6();

	}

}



