import java.io.*;



public class DumbGrep3 {

	public static void main(String argv[]) {

		String word = argv[0];

		String filename = argv[1];

		String optThird = "not";

		if (argv.length == 3) {

			optThird = argv[2];

		}

		if (!optThird.equals("initial")) {

			optThird = "not";

		}

		String line;

		try {

			FileReader fr = new FileReader(filename);

			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null) {

				if (findIt(line,word,optThird)) {

					System.out.println(line);

				}

			}

			fr.close();

		} catch (Exception e) {

			System.out.println("Uhoh!");

		}

	}

	public static boolean findIt(String theLine,

			String theWord, String third) {

		if (third.equals("initial")) {

			if (theLine.indexOf(theWord) == 0) {

				return true;

			}

		} else {

			if (theLine.indexOf(theWord) > -1) {

				return true;

			}

		}

		return false;

	}

}



