public class CLEx2 {

	public static void main(String argv[]) {

		try {

			System.out.println(argv[0]);

		} catch (ArrayIndexOutOfBoundsException e) {

			System.out.println("Enter an argument on the command-line.");

		}

	}

}

