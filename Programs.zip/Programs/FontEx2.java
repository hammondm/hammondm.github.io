import java.awt.*;

import java.awt.event.*;



public class FontEx2 extends Frame implements ItemListener {

	Choice nameC,styleC,sizeC;

	String name;

	int style,size;

	int sizes[] = {9,10,12,18,24,36};

	int styles[] = {Font.PLAIN,Font.BOLD,Font.ITALIC};

	String names[] = {"Dialog","DialogInput","Monospaced",

		"Serif","SansSerif","Symbol"};

	Font font;

	public FontEx2() {

		setSize(400,200);

		addWindowListener(new Closer());

		setLayout(new FlowLayout());

		nameC = new Choice();

		for (int i = 0; i < names.length; i++) {

			nameC.addItem(names[i]);

		}

		add(nameC);

		nameC.addItemListener(this);

		styleC = new Choice();

		styleC.addItem("Plain");

		styleC.addItem("Bold");

		styleC.addItem("Italic");

		add(styleC);

		styleC.addItemListener(this);

		sizeC = new Choice();

		for (int i = 0; i < sizes.length; i++) {

			sizeC.addItem(Integer.toString(sizes[i]));

		}

		add(sizeC);

		sizeC.addItemListener(this);

		show();

	}

	public void paint(Graphics g) {

		g.setFont(font);

		g.drawString("This is a test",50,100);

	}

	public void itemStateChanged(ItemEvent e) {

		int nameInd = nameC.getSelectedIndex();

		int styleInd = styleC.getSelectedIndex();

		int sizeInd = sizeC.getSelectedIndex();

		font = new Font(names[nameInd],styles[styleInd],sizes[sizeInd]);

		repaint();

	}

	public static void main(String argv[]) {

		new FontEx2();

	}

}



