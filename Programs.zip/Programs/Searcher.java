public class Searcher {

	public Searcher(String l, String p, String e) {

		int where;

		if (e.equals("in")) {

			if (l.indexOf(p) == 0) {

				System.out.println(l);

			}

		} else if (e.equals("nf")) {

			where = l.indexOf(p) + p.length();

			if ((where == l.length()) && (l.indexOf(p) > -1)) {

				System.out.println(l);

			}

		} else if (e.equals("if")) {

			where = l.indexOf(p) + p.length();

			if ((where == l.length()) && (l.indexOf(p) == 0)) {

				System.out.println(l);

			}

		} else {

			if (l.indexOf(p) > -1) {

				System.out.println(l);

			}

		}

	}

}

