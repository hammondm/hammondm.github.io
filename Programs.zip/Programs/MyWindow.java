import java.awt.*;



public class MyWindow extends Frame {

	public MyWindow() {

		setSize(200,100);

		addWindowListener(new WinDis(this));

	}

}

