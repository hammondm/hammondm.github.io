public class StaticWRONG {

	public void wrong() {

		System.out.println("This won't work!");

	}

	public static void main(String argv[]) {

		wrong();

	}

}

