import java.util.*;

import java.io.*;



public class VReader {

	private Vector lines;

	private String filename;

	public VReader(String f) {

		filename = f;

		lines = new Vector();

		putLines();

	}

	private void putLines() {

		String line;

		try {

			FileReader fr = new FileReader(filename);

			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null) {

				lines.addElement(line);

			}

			br.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

	public Vector getLines() {

		return lines;

	}

	public static void main(String argv[]) {

		VReader vr = new VReader(argv[0]);

		Vector temp = vr.getLines();

		Enumeration e = temp.elements();

		while (e.hasMoreElements()) {

			System.out.println((String) e.nextElement());

		}

	}

}

