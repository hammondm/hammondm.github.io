public class Vbloo1 {

	int n;

	static int m = 0;

	public Vbloo1(String k) {

		n = Integer.parseInt(k);

		m++;

	}

	public static void main(String argv[]) {

		Vbloo1 vb1 = new Vbloo1(argv[0]);

		Vbloo1 vb2 = new Vbloo1(argv[1]);

		System.out.println("vb1.n: " + vb1.n);

		System.out.println("vb2.n: " + vb2.n);

		System.out.println("Vbloo1.m: " + Vbloo1.m);

	}

}

