import java.awt.*;



public class CloseFrame extends Frame {

	public CloseFrame() {

		Closer c = new Closer();

		addWindowListener(c);

		setSize(300,300);

		show();

	}

	public static void main(String argv[]) {

		CloseFrame cf = new CloseFrame();

	}

}



