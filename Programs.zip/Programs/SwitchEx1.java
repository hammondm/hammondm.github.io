public class SwitchEx1 {

	public static void main(String argv[]) {

		int theInt;

		theInt = 5;

		switch(theInt) {

			case 2:

				System.out.println("That's a 2!");

				break;

			case 5:

				System.out.println("That's a 5.");

				break;

			default:

				System.out.println("What number was that?");

		}

	}

}

