public class WhileEx5 {

	public static void main(String argv[]) {

		long waitTime, firstTime, secondTime, diffTime;

		waitTime = 2000;

		diffTime = 0;

		System.out.println("starting...");

		firstTime = System.currentTimeMillis();

		while (diffTime < waitTime) {

			secondTime = System.currentTimeMillis();

			diffTime = secondTime - firstTime;

		}

		System.out.println("wait time was: " + diffTime);

	}

}

