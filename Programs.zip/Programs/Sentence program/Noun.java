import java.io.*;



public class Noun extends Word {

	private boolean proper;

	public Noun(String s) {

		super(s);

		setPos("noun");

		setProper();

	}

	public Noun(String s, boolean b, boolean p) {

		super(s,b);

		setPos("noun");

		proper = p;

	}

	private void setProper() {

		System.out.print("Is the noun a proper noun? (y/n): ");

		try {

			InputStreamReader isr = new InputStreamReader(System.in);

			BufferedReader br = new BufferedReader(isr);

			String answer = br.readLine();

			if (answer.equals("y")) {

				proper = true;

			} else {

				proper = false;

			}

		} catch (Exception e) {

			e.printStackTrace();

		}



	}

	public boolean getProper() { return proper; }

	public String getInfo() {

		String theInfo = "part of speech: " + getPos() + "\n";

		theInfo = theInfo + "borrowed: ";

		if (getBorrowed()) {

			theInfo = theInfo + "yes\n";

		} else {

			theInfo = theInfo + "no\n";

		}

		theInfo = theInfo + "proper noun: ";

		if (getProper()) {

			theInfo = theInfo + "yes\n";

		} else {

			theInfo = theInfo + "no\n";

		}

		return theInfo;

	}

}



