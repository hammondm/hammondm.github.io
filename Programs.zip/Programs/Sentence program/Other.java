public class Other extends Word {

	public Other(String s) {

		super(s);

		setPos("other");

	}

	public Other(String s, boolean b) {

		super(s,b);

		setPos("other");

	}

	public String getInfo() {

		String theInfo = "part of speech: " + getPos() + "\n";

		theInfo = theInfo + "borrowed: ";

		if (getBorrowed()) {

			theInfo = theInfo + "yes\n";

		} else {

			theInfo = theInfo + "no\n";

		}

		return theInfo;

	}

}



