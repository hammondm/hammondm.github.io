import java.awt.*;



public class Displays extends Frame {

	public Displays() {

		setLayout(new FlowLayout());

		addWindowListener(new Closer());

		Label l = new Label("I'm a label.");

		add(l);

		TextField tf = new TextField("I'm a textfield.");

		add(tf);

		TextArea ta = new TextArea("I'm a textarea.",3,20,

			TextArea.SCROLLBARS_BOTH);

		add(ta);

		pack();

		show();

	}

	public static void main(String argv[]) {

		new Displays();

	}

}

