public class Parent1 {

	public void printSomething(String s) {

		System.out.println(s);

	}

}

