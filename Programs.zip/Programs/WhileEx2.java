public class WhileEx2 {

	public static void main(String argv[]) {

		int myInt;

		myInt = 0;

		do {

			System.out.println("myInt = " + myInt);

			myInt = myInt + 1;

		} while (myInt < 10);

	}

}

