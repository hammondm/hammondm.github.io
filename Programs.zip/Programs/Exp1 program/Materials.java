import java.io.*;



public class Materials {

	String filename;

	String items[];

	public Materials(String f) {

		filename = f;

		doIO();

	}

	public String[] getItems() {

		return items;

	}

	private void doIO() {

		String line;

		int i = 0;

		try {

			FileReader fr = new FileReader(filename);

			BufferedReader br = new BufferedReader(fr);

			int n = Integer.parseInt(br.readLine());

			items = new String[n];

			while ((line = br.readLine()) != null) {

				items[i++] = line;

			}

			fr.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

}



