public class Exp {

	public Exp(String f, String s) {

		Materials m = new Materials(f);

		YesNoQuery q = new YesNoQuery(m,s);

	}

	public static void main(String argv[]) {

		if (argv.length != 2) {

			System.out.println("Enter a filename and subject code");

		} else {

			Exp e = new Exp(argv[0],argv[1]);

		}

	}

}



