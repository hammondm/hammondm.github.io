import java.awt.*;

import java.awt.event.*;



public class FontEx extends Frame implements ItemListener {

	Label l;

	Choice nameC,styleC,sizeC;

	String name;

	int style,size;

	int sizes[] = {9,10,12,18,24,36};

	int styles[] = {Font.PLAIN,Font.BOLD,Font.ITALIC};

	String names[] = {"Dialog","DialogInput","Monospaced",

		"Serif","SansSerif","Symbol"};

	Font font;

	public FontEx() {

		setSize(400,200);

		addWindowListener(new Closer());

		Panel p1 = new Panel();

		nameC = new Choice();

		for (int i = 0; i < names.length; i++) {

			nameC.addItem(names[i]);

		}

		p1.add(nameC);

		nameC.addItemListener(this);

		styleC = new Choice();

		styleC.addItem("Plain");

		styleC.addItem("Bold");

		styleC.addItem("Italic");

		p1.add(styleC);

		styleC.addItemListener(this);

		sizeC = new Choice();

		for (int i = 0; i < sizes.length; i++) {

			sizeC.addItem(Integer.toString(sizes[i]));

		}

		p1.add(sizeC);

		add("North",p1);

		sizeC.addItemListener(this);

		l = new Label("This is a test");

		l.setAlignment(Label.CENTER);

		add("Center",l);

		show();

	}

	public void itemStateChanged(ItemEvent e) {

		int nameInd = nameC.getSelectedIndex();

		int styleInd = styleC.getSelectedIndex();

		int sizeInd = sizeC.getSelectedIndex();

		font = new Font(names[nameInd],styles[styleInd],sizes[sizeInd]);

		l.setFont(font);

		l.repaint();

	}

	public static void main(String argv[]) {

		new FontEx();

	}

}



