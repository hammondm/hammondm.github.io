public class PigLatin {

	String input,result;

	public PigLatin(String s) {

		input = s;

		makeRes();

	}

	private void makeRes() {

		StringBuffer sb = new StringBuffer(input);

		StringBuffer prefix = new StringBuffer("");

		while (consonant(sb.charAt(0))) {

			prefix.append(sb.charAt(0));

			sb.deleteCharAt(0);

		}

		if (prefix.length() == 0) {

			prefix.append("y");

		}

		sb.append(prefix.toString());

		sb.append("ay");

		result = sb.toString();

	}

	private boolean consonant(char c) {

		String consonants = "bcdfghjklmnpqrstvwxyz";

		if (consonants.indexOf(c) > -1) {

			return true;

		} else {

			return false;

		}

	}

	public String getResult() {

		return result;

	}

	public static void main(String argv[]) {

		PigLatin pl = new PigLatin(argv[0]);

		System.out.println(pl.getResult());

	}

}

