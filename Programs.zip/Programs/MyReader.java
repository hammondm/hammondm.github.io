import java.io.*;



public class MyReader {

	String pattern;

	String filename;

	String edge;

	public MyReader(ArgParser ap) {

		filename = ap.getFilename();

		pattern = ap.getPat();

		edge = ap.getEdge();

		doFileIO();

	}

	void doFileIO() {

		String line;

		Searcher search;

		try {

			FileReader fr = new FileReader(filename);

			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null) {

				search = new Searcher(line,pattern,edge);

			}

			fr.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

}

