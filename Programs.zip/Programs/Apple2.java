public class Apple2 {

	public void foundWhere(String s) {

		System.out.println("myApple is on my " + s);

	}

	public static void growWhere() {

		System.out.println("Apples grow on trees");

	}

	public static void main(String argv[]) {

		growWhere();

		Apple2 myApple = new Apple2();

		myApple.foundWhere(argv[0]);

	}

}

