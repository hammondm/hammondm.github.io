public class TryWRONG {

	public static void main(String argv[]) {

		System.out.println("starting...");

		Thread.sleep(2000);

		System.out.println("Time's up!");

	}

}

