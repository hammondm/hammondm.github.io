import java.applet.*;

import java.awt.*;



public class AppParam extends Applet {

	Label l;

	public void init() {

		String text = getParameter("THETEXT");

		l = new Label(text);

		add(l);

	}

}

