import java.awt.*;

import java.awt.event.*;



public class TextEx1 extends Frame implements ActionListener {

	Label l;

	TextField tf;

	Button b;

	public TextEx1() {

		setSize(300,200);

		setLayout(new FlowLayout());

		addWindowListener(new Closer());

		tf = new TextField("Edit this field.");

		add(tf);

		l = new Label("I'm a label.");

		add(l);

		b = new Button("Copy");

		b.addActionListener(this);

		add(b);

		show();

	}

	public void actionPerformed(ActionEvent e) {

		String temp = tf.getText();

		l.setText(temp);

		validate();

	}

	public static void main(String argv[]) {

		new TextEx1();

	}

}

