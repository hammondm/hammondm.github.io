public class IfEx6 {

	public static void main(String argv[]) {

		String myString;

		myString = "this is a string";

		int myInt;

		myInt = 5;

		if ((myInt > 4) && (myString.length() != 10)) {

			System.out.println("That worked!");

		}

	}

}

