public class ArrayTest {

	public static void main(String argv[]) {

		int hat[] = new int[3];

		hat[0] = 17;

		hat[1] = 0;

		hat[2] = 56;

		System.out.println(hat[2]);

		System.out.println(hat[1]);

		System.out.println(hat[0]);

	}

}

