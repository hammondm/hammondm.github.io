public class Meth3 {

	public static void main(String argv[]) {

		test(3,"Mike");

	}

	public static void test(int n, String s) {

		for (int i = 0; i < n; i++) {

			System.out.println("Hello, " + s);

		}

	}

}

