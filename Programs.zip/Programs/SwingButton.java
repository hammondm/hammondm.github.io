import java.awt.*;

import java.awt.event.*;

import javax.swing.*;



public class SwingButton extends JFrame implements ActionListener {

	JButton b;

	int i;

	public SwingButton() {

		i = 1;

		addWindowListener(new Closer());

		setSize(300,300);

		getContentPane().setLayout(new FlowLayout());

		b = new JButton("Press me!");

		b.addActionListener(this);

		getContentPane().add(b);

		show();

	}

	public void actionPerformed(ActionEvent e) {

		System.out.println("Button press #" + i++);

	}

	public static void main(String argv[]) {

		new SwingButton();

	}

}



