import java.awt.*;

import java.awt.event.*;



public class ButtonEx2 extends Frame implements WindowListener {

	Button b;

	public ButtonEx2() {

		addWindowListener(this);

		setSize(300,300);

		setLayout(new FlowLayout());

		b = new Button("Do nothing");

		add(b);

		show();

	}

	public void windowClosing(WindowEvent e) {

		System.exit(0);

	}

	public void windowActivated(WindowEvent e) {}

	public void windowClosed(WindowEvent e) {}

	public void windowDeactivated(WindowEvent e) {}

	public void windowDeiconified(WindowEvent e) {}

	public void windowIconified(WindowEvent e) {}

	public void windowOpened(WindowEvent e) {}

	public static void main(String argv[]) {

		ButtonEx2 be = new ButtonEx2();

	}

}



