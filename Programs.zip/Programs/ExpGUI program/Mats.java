import java.io.*;

import java.util.*;



public class Mats {

	private String filename;

	private Vector items;

	public Mats(String f) {

		filename = f;

		items = new Vector();

		doIO();

	}

	public Vector getItems() {

		return items;

	}

	private void doIO() {

		String line;

		try {

			FileReader fr = new FileReader(filename);

			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null) {

				items.addElement(line);

			}

			fr.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

}



