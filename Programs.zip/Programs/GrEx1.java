import java.awt.*;

import java.awt.event.*;



public class GrEx1 extends Frame {

	public GrEx1() {

		setSize(200,300);

		addWindowListener(new Closer());

		show();

	}

	public void paint(Graphics g) {

		g.drawLine(15,50,100,50);

		g.drawOval(15,100,30,30);

		g.fillRect(15,150,100,80);

	}

	public static void main(String argv[]) {

		new GrEx1();

	}

}

