import java.awt.*;



public class DrawStringEx extends Frame {

	String str;

	public DrawStringEx(String s) {

		str = s;

		addWindowListener(new Closer());

		setSize(400,200);

		show();

	}

	public void paint(Graphics g) {

		g.drawString(str,40,100);

	}

	public static void main(String argv[]) {

		String temp = "";

		for (int i = 0; i < argv.length; i++) {

			temp = temp + " " + argv[i];

		}

		new DrawStringEx(temp);

	}

}



