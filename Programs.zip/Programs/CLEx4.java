public class CLEx4 {

	public static void main(String argv[]) {

		int total, current;

		total = 0;

		for (int i = 0; i < argv.length; i++) {

			current = Integer.parseInt(argv[i]);

			total = total + current;

		}

		System.out.println("total: " + total);

	}

}

