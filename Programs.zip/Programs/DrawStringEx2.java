import java.awt.*;



public class DrawStringEx2 extends Frame {

	public DrawStringEx2() {

		addWindowListener(new Closer());

		setSize(400,200);

		show();

	}

	public void paint(Graphics g) {

		g.drawString("Here is some text.",40,100);

		g.drawString("A second string.",40,95);

		g.drawString("This is a third string.",58,100);

	}

	public static void main(String argv[]) {

		new DrawStringEx2();

	}

}



