import java.io.*;
import com.oroinc.text.regex.*;

public class OroEx {
	public static void main(String argv[]) {
		String theTerm = argv[0];
		Perl5Matcher matcher = new Perl5Matcher();
		Perl5Compiler compiler = new Perl5Compiler();
		Perl5Pattern thePattern;
		Perl5StreamInput theInput;
		MatchResult result;
		try {
			thePattern = (Perl5Pattern) compiler.compile(theTerm);
			FileReader fr = new FileReader(argv[1]);
			theInput = new Perl5StreamInput(fr);
			while(matcher.contains(theInput, thePattern)) {
				result = matcher.getMatch();  
				System.out.println(result.toString());
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}

