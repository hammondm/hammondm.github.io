public class Vbloo2 {

	public Vbloo2(String k) {

		int n = Integer.parseInt(k);

		printIt(n);

	}

	public void printIt(int i) {

		System.out.println("n = " + i);

	}

	public static void main(String argv[]) {

		Vbloo2 vb1 = new Vbloo2(argv[0]);

	}

}

