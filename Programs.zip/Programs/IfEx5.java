public class IfEx5 {

	public static void main(String argv[]) {

		String myString;

		myString = "this is a string";

		System.out.println(myString);

		if (myString.equals("this")) {

			System.out.println("myString equals \"this\".");

		} else if (myString.indexOf("this") > -1) {

			System.out.println("myString contains \"this\".");

		} else if (myString.length() > 10) {

			System.out.println("myString is really long: " + myString.length());

		}

	}

}

