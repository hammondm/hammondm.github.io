import java.util.*;



public class HashTest1 {

	public static void main(String argv[]) {

		Hashtable h = new Hashtable();

		String x = "hat";

		String y = "zebra";

		String z = "orange";

		Integer a = new Integer(35);

		Integer b = new Integer(10);

		Integer c = new Integer(3);

		h.put(x,a);

		h.put(y,b);

		h.put(z,c);

		Enumeration e = h.keys();

		while (e.hasMoreElements()) {

			String temp1 = (String) e.nextElement();

			Integer tempInteg = (Integer) h.get(temp1);

			String temp2 = tempInteg.toString();

			System.out.println(temp1 + ": " + temp2);

		}

	}

}

