from tkinter import *

#all the same except pack for b1
w = Tk()
l = Label(text='This is a label')
l.pack()
b1 = Button(
	text='wow',
	command=lambda: print('wow')
)
b1.pack(side=RIGHT)   #here's the difference
b2 = Button(text='quit',command=quit)
b2.pack()

mainloop()

