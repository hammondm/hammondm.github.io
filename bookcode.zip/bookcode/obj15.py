class MyParent:    #parent class def
	info = 'wow!'   #class variable
	def oh(self):   #instance method
		#creates an instance variable
		self.oh = 'yippee!'

#child class def
class MyChild(MyParent):
	pass            #nothing in the body

#create instance of child
a = MyChild()
#inherits parent class variable
print(MyChild.info)
#inherits parent instance method
a.oh()
#inherits parent instance variable
print(a.oh)

