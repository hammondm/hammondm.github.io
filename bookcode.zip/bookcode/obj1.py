import re

#open and read file
f = open('alice.txt','r')
t = f.read()
f.close()
t = t[10841:]    #strip header
#split into sentences
ss = re.split('([\.?!])',t)
i = 0            #show first 10
while i < 20:
	s = ss[i] + ss[i+1] + '\n'
	print(s)
	i += 2

