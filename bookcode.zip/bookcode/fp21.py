a = [1,2,3]          #create two lists
b = [4,5,6]
c = zip(a,b)         #zip each pair together
#sum elements of each pair
d = list(map(sum,c))
print(d)             #print result

