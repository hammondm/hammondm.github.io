from tkinter import *

w = Tk()         #start GUI
#make and place label
l = Label(text='This is a label')
l.pack()
b1 = Button(     #make and place button
	text='wow',
	command=lambda: print('wow')
)
b1.pack()
#make and place another button
b2 = Button(text='quit',command=quit)
b2.pack()

mainloop()       #go...

