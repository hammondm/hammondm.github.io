from obj20 import *

a = Segment('ng','ŋ')
print(a.spell())
print(a.pronounce())

