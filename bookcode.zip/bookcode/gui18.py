from tkinter import *
import gui16     #import stemmer code

r = Tk()         #start GUI
#label for instructions
linfo = Label(text='instructions...')
linfo.pack()
e = Entry()      #entry for word to stem
e.pack()
#where we'll put the result
lres = Label(text='result...')
lres.pack()
#apply the stemmer code
bstem = Button(text='Stem')
bstem.pack()
#quit
bquit = Button(text='Quit',command=quit)
bquit.pack()
mainloop()       #go...

