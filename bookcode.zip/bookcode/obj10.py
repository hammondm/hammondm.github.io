class Word:        #class definition
	count = 0       #class variable
	#initializer takes an extra arg
	def __init__(self,x):
		#create instance variable, set to x
		self.pos = x
		#increment class count variable
		Word.count += 1

a = Word('noun')   #instantiate with 'noun'
b = Word('verb')   #instantiate with 'verb'
#continue as before
print('a count:',a.count)
print('b count:',b.count)
print('a POS:',a.pos)
print('b POS:',b.pos)
