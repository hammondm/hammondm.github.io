from functools import reduce

a = [1,2,3,4,5]           #lists
#add pairs
print(reduce(lambda x,y: x+y,a,0))

#dictionaries
b = {'Tom':14,'Dick':25,'Harry':8}
#length of each key
print(list(map(len,b)))

c = 'happy'               #strings
#double each letter
print(list(map(lambda x: x+x,c)))

f = open('test.txt','r')  #files
#length of each line
print(list(map(len,f)))
f.close()

