class Word:    #a class definition
	#this class has a variable
	info = "I'm a word."

w = Word()     #create instance of class
#access variable from instance
print('w:',w.info)
#access variable from class
print('Word:',Word.info)

