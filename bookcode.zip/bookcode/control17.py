for i in [1,2,3]:   #using variable twice
	print('{} + 2 = {}'.format(i,i+2))

