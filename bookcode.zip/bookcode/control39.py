vowels = 'aeiou'      #define more Vs
consonants = 'ptkbdg' #define more Cs
for v in vowels:      #for every vowel
	#choose a consonant
	for c in consonants:
		#now print them together
		print(c,v,sep='')

