def myfunction():
	print('This is a function')
	print("That's all it does")

