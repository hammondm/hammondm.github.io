import re,time
import multiprocessing as mp

def mytime():     #gets time in milliseconds
	return round(time.time() * 1000)

start = mytime()  #start the clock

def myconc(wds):  #build concordance
	d = {}
	for w in wds:
		if w in d:
			d[w] += 1
		else:
			d[w] = 1
	return d

#read file
f = open('alice.txt','r')
t = f.read()
f.close()

t = t[11000:]     #strip header

t = t.lower()     #normalize
t = re.sub('[^a-z]+',' ',t)

ws = t.split(' ') #split into words

#partition words
ws = [ws[:9000],ws[9000:18000],ws[18000:]]

#start multiprocessing
mypool = mp.Pool()
res = mypool.map(myconc, ws)

d = res[0]        #merge results
for dx in res[1:]:
	for w in dx:
		if w in d:
			d[w] += dx[w]
		else:
			d[w] = dx[w]

print(len(d))
print(sum(d.values()))

#print total elapsed
now = str(mytime() - start)
print("Total = " + now + " ms")

