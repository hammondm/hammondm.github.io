vowels = 'aeiou'       #define vowels
word = 'Winnepesaukee' #set word
#create two counters
counter = 0
vowelcount = 0
#go letter by letter
while counter < len(word):
	#is current letter a vowel?
	if word[counter] in vowels:
		vowelcount += 1
	#keep track of total number of letters
	counter += 1
#when counter is too big, do this:
else:
	print('There are',vowelcount,
		'vowels in this word')

