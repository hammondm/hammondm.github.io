#create list comprehension
a = [x+x for x in 'happy' if x+x != 'aa']
for i in a:     #iterate through list
	print(i)
