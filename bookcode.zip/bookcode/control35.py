vowels = 'aeiou' #define vowels 
word = 'sthenic' #define word
counter = 0      #initialize counter
while True:      #iterate forever
	#is current letter a vowel?
	if word[counter] in vowels:
		break      #if so, exit
	#remember to increment counter
	counter += 1
#print result
print('The word begins with',
	counter,'consonant letters')

