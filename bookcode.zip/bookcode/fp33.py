import multiprocessing as mp
import re,time,glob

def mytime():     #time in milliseconds
	return round(time.time() * 1000)

start = mytime()  #start the clock

#names of files that end in .py
filenames = glob.glob('*.py')

def countwords(filename):
	f = open(filename,'r')
	t = f.read()
	f.close()
	t = t.lower()
	t = re.sub('[^a-z]+',' ',t)
	ws = t.split()
	wds = []
	for w in ws:
		m = re.search('(.).*(.).*\\1.*\\2',w)
		if m:
			wds.append(w)
	return len(wds)

#start multiprocessing
mypool = mp.Pool(processes=4)
#map function to all filenames
wds = mypool.map(countwords,filenames)

print(sum(wds))   #print total
#stop the clock
now = str(mytime() - start)
#total elapsed time
print("Total time = " + now + " ms")

