#create a comprehension from two sequences
a = [x+y for x in 'hat' for y in 'dog']
for i in a:        #iterate through result
	print(i)
