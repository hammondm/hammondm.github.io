from tkinter import *

#function to print Entry contents
def printit():
	print('Entry:',t.get())

r = Tk()         #start GUI
#set up stringvar AFTER GUI starts
t = StringVar()
#set value of t
t.set('Type something here')
#Entry field linked to t variable
e = Entry(r,textvariable=t)
e.pack()
#button to print contents of Entry
b1 = Button(
	text='Print',
	command=printit
)
b1.pack()
b2 = Button(     #quit button
	text='Quit',
	command=quit
)
b2.pack()

mainloop()

