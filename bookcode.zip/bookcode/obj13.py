import re

class File:        #File def
	#initialize with file name
	def __init__(self,s):
		#read in file
		f = open(s,'r')
		self.text = f.read()
		f.close()
		#strip header
		self.text = self.text[10841:]
	#return text of the file
	def getText(self):
		return self.text

class Text:        #Text class def
	#initialize with File instance arg
	def __init__(self,f):
		#get the text from File instance
		text = f.getText()
		#split on sentence breaks
		#saving split letter with parens!
		bits = re.split('([\.!?])',text)
		#instance variable list to save sentences
		self.sentences = []
		#assemble each sentence and add to list
		i = 0
		while i < len(bits)-1:
			self.sentences.append(
				bits[i]+bits[i+1]
			)
			i += 2
	#return the sentences
	def getSentences(self):
		return self.sentences

#instance of File
f = File('alice.txt')
t = Text(f)        #instance of Text
#get sentences
ss = t.getSentences()
for s in ss[:10]:  #print the first 10
	print(s)

