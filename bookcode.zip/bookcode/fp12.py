from functools import reduce

a = list(range(5))  #create list of numbers
#reduce with addition
b = reduce(lambda x,y: x+y,a,9)
print(b)            #print result
#another reudction
c = reduce(lambda x,y: x+y,[],9)
print(c)            #print result

