class Word:  #class definition
	#instance method
	def whatami(self):
		#creating an instance variable
		self.x = "I'm a noun!"

w = Word()   #create instance of class
w.whatami()  #call the instance method
print(w.x)   #print the instance variable

