import itertools

#generate all combinations of letters
def items(ls):
	n = ['']
	while True:
		nn = [x+y for x in n for y in ls]
		for x in nn:
			yield x
		n = nn

j = 0   #iterate up to a specific point
for i in items('abc'):
	print(i)
	j += 1
	if j == 10:
		break

#extract a sequence from the iteration
myslice = itertools.islice(items('ab'),100,105)
print(list(myslice))

