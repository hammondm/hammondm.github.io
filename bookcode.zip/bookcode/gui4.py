from tkinter import *

w = Tk()
l = Label(
	w,
	text='Press the button!'
)
l.pack()
b = Button(
	w,
	text='Quit',
	command=quit
)
b.pack()

mainloop()

