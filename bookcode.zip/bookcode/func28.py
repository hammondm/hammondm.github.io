#import with abbreviated prefix
import func25 as f

#invoke function with f prefix
print(f.myVar)
#invoke both with f prefix
print(f.myFunc(f.myVar))

