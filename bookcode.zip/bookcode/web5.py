f = open('hammond.html','r')
t = f.read()
f.close()
print(t)

