from nltk.tokenize import sent_tokenize

f = open('alice.txt','r')  #read in alice
t = f.read()
f.close()
t = t[11000:]              #strip header
#break into sentences
ss = sent_tokenize(t)
#how many sentences
print(len(ss))
#print first 10 with extra spaces
for s in ss[:10]:
	print(s,'\n')

