#an iterator that represents an
#infinite sequence of integers
class Sequence:
	#initialize starting point
	def __init__(self,low):
		self.now = low
	#required for iterators
	def __iter__(self):
		return self
	#gets the next item
	def __next__(self):
		#return current value and increment
		i = self.now
		self.now += 1
		return i

s = Sequence(3)    #create a new sequence
for i in range(5): #iterate through sequence
	print(next(s))
