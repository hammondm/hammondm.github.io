class MyParent:    #parent class def
	def wow():      #class method
		print('wow!')
	#instance method with arg
	def printthis(self,x):
		print(x)

#child class def inherits from MyParent
class MyChild(MyParent):
	pass            #nothing in the body

a = MyChild()      #make instance of child
#inherits parent class method
MyChild.wow()
#inherits parent instance method
a.printthis('oh?')

