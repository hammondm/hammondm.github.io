count = 0         #declare counter
while count < 3:  #check value of counter
	print(count)   #print the value
	count += 1     #NOW increment counter

