print(4+7) #this does some math

#the following prints a string
print('that should be 11')

