class MyMom:       #parent class def
	info = 'wow'    #class variable
	#instance method
	def mySet(self,x):
		self.oh = x  #instance variable

class MyDad:       #other parent class def
	#initializer method
	def __init__(self,x):
		#instance variable
		self.var = x

#child class def multiply inherits
class MyChild(MyMom,MyDad):
	pass            #nothing in body

#make an instance of the child
#uses initializer from MyDad
a = MyChild('ok')
#instance method from MyMom
a.mySet('hm')
#class variable from MyMom
print(MyChild.info)
#instance variable from MyDad
print(a.var)
#instance variable from MyMom
print(a.oh)

