gv = []       #create a global list variable
gv.append(0)

def f1(g,x):  #function to manipulate global
	g[0] += x
	return g

print(gv[0])  #print initial value of global
gv = f1(gv,3) #invoke the function
print(gv[0])  #print the new global value
