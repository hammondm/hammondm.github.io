#set up initial variables
vowels = 'aeiou'
word = 'Mississippi'
counter = 0
i = 0
#go through word letter by letter
while i < len(word):
	#is current letter a vowel?
	if word[i] in vowels:
		i += 1     #if so, increment letter count
		continue   #...and exit current loop
	i += 1        #else, increment letter count
	counter += 1  #increment consonant count
#print result
print('The word has',
	counter,'consonant letters')

