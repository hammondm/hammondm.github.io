if 2+2==5:   #only else block executes
	print("this won't print")
else:
	print('but this will')
	print('...and so will this')

