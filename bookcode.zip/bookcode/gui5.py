from tkinter import *

#function to print something
def wow(): print('wow!')

w = Tk()      #start GUI
l = Label(    #make a label
	w,
	text='Press either button!'
)
l.pack()      #place the label
b1 = Button(  #make a button
	w,
	text='Wow',
	command=wow
)
b1.pack()     #place the button
b2 = Button(  #make another button
	w,
	text='Quit',
	command=quit
)
b2.pack()     #place the other button

mainloop()    #go...
