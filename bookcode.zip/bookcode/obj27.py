class Speech:           #Speech class def
	#return spelling and pronunciation
	def spell(self):
		return self.spelling
	def pronounce(self):
		return self.pronunciation

class Segment(Speech):  #Segment class def
	#initialize from strings
	def __init__(self,s,p):
		if type(s) != str or type(p) != str:
			raise Exception(
				'Usage: Segment(str,str)'
			)
		#set instance variables
		self.spelling = s
		self.pronunciation = p

class Subsyl(Speech):   #Subsyl class def
	#daughters are Segment type
	daughters = Segment
	#initialize from list of Segments
	def __init__(self,xs):
		self.spelling = '' 
		self.pronunciation = ''
		for x in xs:
			if type(x) != self.daughters:
				raise Exception(
					'Type error for Subsyl!'
				)
			#set instance variables by concatenating
			self.spelling += x.spelling
			self.pronunciation += x.pronunciation

#all inherit from Subsyl
class Onset(Subsyl):
	pass
class Nucleus(Subsyl):
	pass
class Coda(Subsyl):
	pass

class Rhyme(Speech):     #Rhyme class def
	#initialize from Nucleus and optional Coda
	def __init__(self,n,c=''):
		if type(n) != Nucleus:
			raise Exception(
				'Type error for Rhyme!'
			)
		self.spelling = n.spelling
		self.pronunciation = n.pronunciation
		if c != '':
			if type(c) != Coda:
				raise Exception(
					'Type error for Rhyme!'
				)
			self.spelling += c.spelling
			self.pronunciation += c.pronunciation

class Syllable(Speech):  #Syllable class def
	#initialize from Rhyme and optional Onset
	def __init__(self,r,o=''):
		#check Rhyme type
		if type(r) != Rhyme:
			raise Exception(
				'Type error for Syllable!'
			)
		#set instance variables
		self.spelling = r.spelling
		self.pronunciation = r.pronunciation
		#if onset arg is present
		if o != '':
			#check that it's an onset
			if type(o) != Onset:
				raise Exception(
					'Type error for Syllable!'
				)
			#concatenate with existing
			#instance variables
			self.spelling = o.spelling + \
				self.spelling
			self.pronunciation = o.pronunciation \
				+ self.pronunciation

