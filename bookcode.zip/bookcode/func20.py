print((lambda x: x + x)('hat'))

