if 2 + 2 == 5:   #2-statement block
	print("that shouldn't happen")
	print('or this....')

