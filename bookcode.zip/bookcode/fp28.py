def sequence(low,high): #sequence generator
	while low <= high:
		yield low
		low += 1

s = sequence(3,10)      #create new sequence
for i in s:             #go through sequence
	print(i)
