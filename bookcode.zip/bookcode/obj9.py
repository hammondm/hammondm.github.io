class MyClass:
	def __init__(self):
		print('Instantiating MyClass!')

x = MyClass()
y = MyClass()
