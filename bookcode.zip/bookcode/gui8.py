from tkinter import *

w = Tk()         #start gui

#create a tkinter integer variable
count = IntVar(w)
count.set(0)     #set it to 0

#function to increment count variable
def wow():
	#get the current value + 1
	c = count.get() + 1
	count.set(c)  #reset count variable

#a label that's tagged for the count variable
l = Label(w,textvariable=count)
l.pack()
b1 = Button(     #a button
	w,
	text='Wow',
	command=wow
)
b1.pack()
b2 = Button(     #another button
	w,
	text='Quit',
	command=quit
)
b2.pack()

mainloop()       #go...

