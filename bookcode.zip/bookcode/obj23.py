class Speech:        #Speech class def
	def spell(self):  #return spelling
		return self.spelling
	#return pronunciation
	def pronounce(self):
		return self.pronunciation

#Segment class def
class Segment(Speech):
	#initialize from spelling and pronunciation
	def __init__(self,s,p):
		#those have to be strings!
		if type(s) != str or type(p) != str:
			raise Exception(
				'Usage: Segment(str,str)'
			)
		#set instance variables
		self.spelling = s
		self.pronunciation = p

#general class for elements above segments
class Subsyl(Speech):
	#daughter elements are segments
	daughters = Segment
	#initializer from a list of segments
	def __init__(self,xs):
		#set instance variables
		self.spelling = '' 
		self.pronunciation = ''
		#got through the argument list 1 by 1
		for x in xs:
			#check that they are segments
			if type(x) != self.daughters:
				raise Exception('Type error!')
			#concatenate spellings
			self.spelling += x.spelling
			#concatenate pronunciations
			self.pronunciation += x.pronunciation

#now inheriting from Subsyl
class Onset(Subsyl):
	pass
class Nucleus(Subsyl):
	pass
class Coda(Subsyl):
	pass
#still inheriting from Speech
class Rhyme(Speech):
	pass
class Syllable(Speech):
	pass

