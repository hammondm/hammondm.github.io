#recursive function to find prefixes
def pfx1(s):
	if len(s) > 0:
		print(s)
		pfx1(s[:-1])

def pfx2(s):    #same function using map()
	list(map(
		lambda x: print(s[:x]),
		range(len(s),0,-1)
	))

pfx1('happy')   #comparing
pfx2('happy')
