vowels = 'aeiou'        #define vowels
#variable to accumulate count
vowelCount = 0
word = 'Appalachicola'  #define the word
for letter in word:     #go letter by letter
	if letter in vowels: #check if vowel
		vowelCount += 1   #if so, add 1
print(vowelCount)       #print the total

