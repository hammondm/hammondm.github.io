import numpy as np

#create two numpy arrays
a = np.array([1,2,3])
b = np.array([4,5,6])
c = a + b      #vectorized addition
d = a * b      #vectorized multiplication
print(c)       #print results
print(d)
