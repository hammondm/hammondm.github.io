import sys as s

print(s.argv)

