class Speech:        #Speech class def
	def spell(self):  #return spelling
		return self.spelling
	#return pronunciation
	def pronounce(self):
		return self.pronunciation

#everybody inherits from Speech
class Syllable(Speech):
	pass
class Onset(Speech):
	pass
class Nucleus(Speech):
	pass
class Coda(Speech):
	pass
class Rhyme(Speech):
	pass
class Segment(Speech):
	#initializer from spelling,pronunciation
	def __init__(self,s,p):
		#check that args are strings!
		if type(s) != str or type(p) != str:
			raise Exception(
				'Usage: Segment(str,str)'
			)
		#set instance variables
		self.spelling = s
		self.pronunciation = p

