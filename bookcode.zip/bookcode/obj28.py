from obj27 import *

k = Segment('c','kʰ')
a = Segment('a','a')
r = Segment('r','r')
t = Segment('t','t')
o = Onset([k])
n = Nucleus([a])
c = Coda([r,t])
r = Rhyme(n,c)
s = Syllable(r,o)
print(s.spelling)
print(s.pronunciation)

