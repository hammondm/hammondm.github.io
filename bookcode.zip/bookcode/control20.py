prefix = 'anti'               #initial prefix
word = 'missile'              #initial word
print(word)                   #print word
for i in range(3):            #iterate 3 times
	word = prefix + '-' + word #add prefix...
	print(word)                #print new word

