a = [1,2,3]    #create two lists
b = [4,5,6]
print(a+b)     #plus concatenates them
c = []         #make a new list
#go through old lists
for i in range(0,len(a)):
	#add current values together
	c.append(a[i]+b[i])
print(c)       #print result

