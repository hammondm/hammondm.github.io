if 2+2==4:   #else-block does not execute
	print('this will print')
else:
	print("but this won't")
	print('...and neither will this')

