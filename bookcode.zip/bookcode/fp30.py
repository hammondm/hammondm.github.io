import re,time

def mytime():    #gets time in milliseconds
	return round(time.time() * 1000)

start = mytime() #start the clock

#read file
f = open('alice.txt','r')
t = f.read()
f.close()

t = t[11000:]    #strip header

t = t.lower()    #normalize
t = re.sub('[^a-z]+',' ',t)

#split into words
ws = t.split(' ')

d = {}           #build concordance
for w in ws:
	if w in d:
		d[w] += 1
	else:
		d[w] = 1

print(len(d))
print(sum(d.values()))

#print total elapsed
now = str(mytime() - start)
print("Total = " + now + " ms")

