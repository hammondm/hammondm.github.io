a = ['Tom','Ann','Bess']  #list of strings
#nested comprehension
b = [let for wd in a for let in wd]
for i in b:               #iterate through
	print(i)
