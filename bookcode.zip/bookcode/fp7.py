x = [5,7,2,6,3]  #arbitrary list of numbers

#a silly function that returns the max
#function or the min function
def f(n):
	if n == 'max':
		return max
	if n == 'min':
		return min
	return None

#testing the function
print('max:',f('max')(x))
print('min:',f('min')(x))
