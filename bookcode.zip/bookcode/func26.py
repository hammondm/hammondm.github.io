import func25        #import function

#invoke variable with full name
print(func25.myVar)
#invoke both with full names
print(func25.myFunc(func25.myVar))

