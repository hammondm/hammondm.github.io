vowels = 'aeiou'      #define Vs 
consonants = 'ptkbdg' #define Cs
#for every vowel, onset, coda
for v in vowels:
	for o in consonants:
		for c in consonants:
			if o == c:   #skip if onset == coda
				continue
			#print combination
			print(o,v,c,sep='')

