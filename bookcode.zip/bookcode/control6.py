if 2+2 == 4:
	 print('that was true')   #produces error
   print('...really true')

