#a list of strings
a = ['Tom','Dick','Harry','Mike','Abby']
#create a filter object where a lambda
#function is applied to each element
b = filter(lambda x: len(x) == 4,a)
#convert map object to a list
print(list(b))
