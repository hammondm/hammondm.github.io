total = 0            #set variable
for i in range(5):   #iterate...
	total = total + i #...add to total
print(total)         #print total

