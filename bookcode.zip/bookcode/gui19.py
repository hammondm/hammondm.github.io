from tkinter import *
import gui16     #import stemmer code

f = ('times',18) #a pleasing font

r = Tk()         #start GUI
#instructions in pleasing font
linfo = Label(text='instructions...',font=f)
#put some space on all sides
linfo.pack(pady=10,padx=10)
#entry in the same font
e = Entry(font=f)
e.pack(padx=10)  #a little space on the side
#result goes here in the same font
lres = Label(text='result...',font=f)
#a little space above and below
lres.pack(pady=10)
#the button to do everything
bstem = Button(text='Stem')
bstem.pack()
#quit button
bquit = Button(text='Quit',command=quit)
bquit.pack(pady=10)
mainloop()       #go...

