word = 'alphabet'        #set word
vowels = 'aeiou'         #define vowels
count = 0                #set counter
while count < len(word): #iterate
	letter = word[count]  #get current letter
	#is it a non-vowel?
	if letter not in vowels:
		print(letter)      #if so, print it
	count += 1            #increment counter

