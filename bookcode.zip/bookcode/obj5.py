class Word:             #class definition
	def whatami(self):   #instance method
		return "I'm a word."

#create instance of class
w = Word()
#call instance method
print('w:',w.whatami())

