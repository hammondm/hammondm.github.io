from tkinter import *
import gui16

r = Tk()
b1 = Button(text='Quit',command=quit)
b1.pack()
mainloop()

