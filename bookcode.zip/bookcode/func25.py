#our own module

myVar = 'hats and lemons'  #variable

def myFunc(s):             #function
	return len(s)

