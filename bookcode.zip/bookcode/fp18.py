a = ['Tom','Ann','Bess']   #list of strings
b = []                     #nested for loops
for wd in a:
	for let in wd:
		b.append(let)
for i in b:                #iterate through
	print(i)
