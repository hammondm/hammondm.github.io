#define vowels
vowels = 'aeiou'
#variable to accumulate count
vowelCount = 0
word = 'Appalachicola'            #define word
#go letter by letter
for letter in word:
	if letter in vowels:           #vowel?
		vowelCount = vowelCount + 1 #add 1
print(vowelCount)                 #print total

