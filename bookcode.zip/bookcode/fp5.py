#simulate global variable with a function
def gv():
	return 0

#function that manipulates the global
def f1(g,x):
	return gv() + x

#print initial value of the global
print(gv())
#print the new global value
print(f1(gv(),3))
