nouns = 'bla dor sna'.split()  #Ns
verbs = 'ha mog ge di'.split() #Vs
ivs = 'ha ge'.split()          #intransitives
#for every S+V combo:
for s in nouns:
	for v in verbs:
		#if verb is intransitive:
		if v in ivs:
			print(s,v)
		#otherwise (transitives)
		else:
			for o in nouns:
				#if subject and object the same
				if s == o:
					#replace O with reflexive
					o = 'vi'
				print(s,v,o)

