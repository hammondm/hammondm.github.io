class MyParent:      #parent class def
	info = 'wow'      #class variable
	#instance method
	def mySet(self,x):
		self.oh = x    #instance variable
	#initializing method
	def __init__(self,x):
		#another instance variable
		self.var = x

#child class def
class MyChild(MyParent):
	#instance method overrides parent method!
	def mySet(self,x):
		self.oh = x+x  #instance variable

a = MyChild('ok')    #create child instance
#invoke child instance method
#(overriding parent)
a.mySet('hm')
#invoke parent class variable
print(MyChild.info)
#parent instance variable
print(a.var)
#child instance variable
print(a.oh)

