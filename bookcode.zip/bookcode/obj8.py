class Word:           #class definition
	count = 0          #class variable
	#instance method
	def setPOS(self,x):
		#create instance variable and
		#set to x
		self.pos = x
		#increment class variable count
		Word.count += 1

a = Word()            #make class instance
#set its instance variable to 'noun'
a.setPOS('noun')
b = Word()            #make another instance
#set its instance variable to 'verb'
b.setPOS('verb')
#print the value of count associated with a
print('a count:',a.count)
#print the value of count associated with b
print('b count:',b.count)
#print value of count associated with the class
print('Word count:',Word.count)
print('a POS:',a.pos) #print pos of a
print('b POS:',b.pos) #print pos of b

