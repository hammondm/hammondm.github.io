class File:        #class def for File
	#initialize with arg
	def __init__(self,s):
		#instance variable for filename from arg
		self.filename = s
	#method that will eventually extract text
	def getText(self):
		return 'some text'

class Text:        #class def for Text
	#initialize by getting text from File arg
	def __init__(self,f):
		self.strings = f.getText()
	#method that will eventually
	#return a list of sentences
	def getSentences(self):
		return ['1','2','3','4','5']

#instantiate File with filename
f = File('alice.txt')
#instantiate Text with file instance
t = Text(f)
#extract sentences from Text
ss = t.getSentences()
for s in ss[:3]:   #print the first 3
	print(s)

