import nltk
from nltk.tokenize import word_tokenize

f = open('alice.txt','r') #read in alice
t = f.read()
f.close()
t = t[11000:]             #strip header
t = t.lower()             #normalize
ws = word_tokenize(t)     #break into words
#create a frequency distribution
fd = nltk.FreqDist(ws)
#print the 50 most frequent items
fd.plot(50,cumulative=False)
