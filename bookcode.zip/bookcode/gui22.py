from tkinter import *
#import specifically for messagebox
from tkinter import messagebox
import gui16     #import for stemming code

#the instructions
instructions = '''This is a demo of the
Porter stemmer. Type a
word in the box, press
enter or press the button
and the stem form will be
displayed.'''

#an error message
error = '''You must enter a single
word with only letters
of the alphabet.'''

f = ('times',18) #the pleasing font

#function for the stemming button
def guistem():
	w = ev.get()  #get what user entered
	#check if it's a single word
	if re.search('^[a-zA-Z]+$',w):
		#if so stem it
		res = gui16.stem(w)
		#display result
		lv.set(res)
	else:         #if not...
		#set result to nothing
		lv.set('')
		#display the error message
		messagebox.showerror('Error',error)

r = Tk()         #start the GUI

ev = StringVar() #textvariable for entry
ev.set('Type your word here')
lv = StringVar() #textvariable for result
lv.set('result....')

#label for instructions
linfo = Label(text=instructions,font=f)
linfo.pack(pady=10,padx=10)
#entry for the word to stem
e = Entry(font=f,textvariable=ev)
e.pack(padx=10)
#label for result
lres = Label(textvariable=lv,font=f)
lres.pack(pady=10)
#button to trigger stemming
bstem = Button(text='Stem',command=guistem)
bstem.pack()
#quit button
bquit = Button(text='Quit',command=quit)
bquit.pack(pady=10)
mainloop()       #go...

