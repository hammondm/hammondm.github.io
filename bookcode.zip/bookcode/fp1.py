gv = 0      #create global variable

def f1(x):  #function to manipulate global
	global gv
	gv += x

print(gv)   #print initial value of global
f1(3)       #invoke the function
print(gv)   #print the new global value

