class Syllable:
	pass
class Onset:
	pass
class Nucleus:
	pass
class Coda:
	pass
class Rhyme:
	pass
class Segment:
	pass
