from nltk.corpus import names

male = names.words('male.txt')
female = names.words('female.txt')

mavg = sum(map(len,male))/len(male)
favg = sum(map(len,female))/len(female)

s = '{:>6} names: {:>5} {:>3}'
print(s.format(
	'Male',
	len(male),
	round(mavg,3)
))
print(s.format(
	'Female',
	len(female),
	round(favg,3)
))
