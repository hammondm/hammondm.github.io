#define prefix and 3 words
prefix = 'anti'
words = ['missile','racism','music']
for word in words:   #iterate over words
	print(word)       #print word
	#for each word, iterate 3 times
	for i in range(3):
		#add prefix to current word
		word = prefix + '-' + word
		print(word)    #print new word

