from func32 import *  #doesn't work!

print(_mySplit("This doesn't work"))

