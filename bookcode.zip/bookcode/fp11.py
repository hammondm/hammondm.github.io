from functools import reduce

a = list(range(10))  #create list of numbers
#reduce with addition
b = reduce(lambda x,y: x+y,a)
print(b)             #print result

