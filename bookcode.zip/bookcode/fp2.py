gv = 0        #create global variable

def f1(g,x):  #function to manipulate global
	g += x
	return g

print(gv)     #print initial value of global
gv = f1(3,gv) #invoke the function
print(gv)     #print the new global value

