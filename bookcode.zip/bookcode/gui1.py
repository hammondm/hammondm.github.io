from tkinter import *

r = Tk()      #start tkinter
f = Frame(r)  #make a window
f.pack()
b = Button(   #make a button
	f, 
	padx=20,
	pady=10,
	text="Quit",
	command=quit
)
b.pack(       #position the button
	side=LEFT,
	padx=20,
	pady=20
)
mainloop()    #wait for something to happen
