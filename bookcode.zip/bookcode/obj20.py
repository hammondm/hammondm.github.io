class Speech:        #parent class def
	#initialize with spelling, pronunciation
	def __init__(self,s,p):
		self.spelling = s
		self.pronunciation = p
	def spell(self):  #return spelling
		return self.spelling
	#return pronunciation
	def pronounce(self):
		return self.pronunciation

#all classes inherit from Speech
class Syllable(Speech):
	pass
class Onset(Speech):
	pass
class Nucleus(Speech):
	pass
class Coda(Speech):
	pass
class Rhyme(Speech):
	pass
class Segment(Speech):
	pass

