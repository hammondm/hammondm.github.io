from functools import reduce

def mult(x,y):      #multiplication function
	return x*y

def fac(n):         #factorial with reduce()
	return reduce(mult,range(1,n+1),1)

#example of the base case
print('1! =',fac(1))
#another example
print('5! =',fac(5))
