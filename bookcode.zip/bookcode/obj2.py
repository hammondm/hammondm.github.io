#Only schematic; generates errors!

f = File('alice.txt')

t = Text(f)

ss = t.getSentences()

for s in ss[:10]:
	print(s)

