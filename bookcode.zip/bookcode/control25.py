vowels = 'aeiou'        #define vowels
letterCount = 0         #set counter to zero
word = 'Appalachicola'  #define word
#is 1st letter a lowercase vowel?
if word[0].lower() in vowels:
	for letter in word:  #go letter by letter
		letterCount += 1  #for each letter, add 1
#do this if word is not V-initial
else:
	print('Not vowel-initial')
print(letterCount)      #print letter total

