nouns = 'bla dor sna'.split()  #Ns
verbs = 'ha mog ge di'.split() #Vs
ivs = 'ha ge'.split()          #intransitives
#for every N and V
for s in nouns:
	for v in verbs:
		#if V is intransitive
		if v in ivs:
			print(s,v)
		#otherwise it's transitive
		else:
			for o in nouns:
				print(s,v,o)

