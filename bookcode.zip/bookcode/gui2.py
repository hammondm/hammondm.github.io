from tkinter import *
Tk()
mainloop()

