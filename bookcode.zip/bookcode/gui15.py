from tkinter import *

#function to print contents of Entry
def printit():
	print('Entry:',t.get())

r = Tk()         #start GUI
t = StringVar()  #string variable for Entry
#set value of variable
t.set('Type something here')
#Entry field
e = Entry(r,textvariable=t)
e.pack()
#link Entry to return key!
e.bind('<Return>', lambda x: printit())
b1 = Button(     #one button
	text='Print',
	command=printit
)
b1.pack()
b2 = Button(     #another button
	text='Quit',
	command=quit
)
b2.pack()

mainloop()       #go...

