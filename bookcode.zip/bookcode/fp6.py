x = [5,7,2,6,3]  #arbitrary list of numbers

#a silly function that applies a function
#to an argument
def f1(f,a):
	return f(a)

#testing the function
print('max:',f1(max,x))
print('min:',f1(min,x))
