vowels = 'aeiou' #define vowels
word = 'sthenic' #define word
counter = 0      #initialize counter
#go through all letters
for i in range(len(word)):
	#is current letter a vowel?
	if word[i] in vowels:
		break      #if so, exit loop
	#don't forget to update counter
	counter += 1
#print result
print('The word begins with',
	counter,'consonant letters')

