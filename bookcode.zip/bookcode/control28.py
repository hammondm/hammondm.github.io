count = 0
while count < 3: #error: infinite loop!
	print(count)
	count = 1

