x = zip('cat','dog')  #make pairs object
print(list(x))        #convert to list
x = zip('cat','dog')  #make pairs again
for p in x:           #iterate through pairs
	print(p)
