def fibonacci():  #fibonacci generator
	res = [1,1]
	while True:
		res.append(res[-1]+res[-2])
		yield res[-3]

j = 0             #iterate through values
for i in fibonacci():
	print(i)
	j += 1
	if j == 10: break
