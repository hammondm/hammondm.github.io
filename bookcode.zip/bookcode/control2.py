#single statement indented on next line
if 2+2 == 4:
	print('that was true')

