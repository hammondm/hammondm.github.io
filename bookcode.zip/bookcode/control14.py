x = 'hat'   #set a variable
if x[0] == 'a':
	pass     #if clause with empty block
else:
	print('doing something here....')

