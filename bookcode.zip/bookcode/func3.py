#print a famous sentence over two lines
print('Colorless green ideas...')
print('...sleep furiously')
#get the user to enter a number
num = input('Enter a number: ')
#print the sentence again if it's < 5
if int(num) < 5:
	print('Colorless green ideas...')
	print('...sleep furiously')
else:
	print('Your number was big enough')

