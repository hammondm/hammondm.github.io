from tkinter import *

w = Tk()         #start GUI
#make and place a label
l = Label(text='This is a label')
l.pack()
b1 = Button(     #make a button
	text='wow',
	command=lambda: print('wow')
)
#place with expand=TRUE
b1.pack(expand=TRUE)
#make and place another button
b2 = Button(text='quit',command=quit)
b2.pack()

mainloop()       #go...

