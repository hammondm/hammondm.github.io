vowels = 'aeiou' #define vowels
word = 'sthenic' #define word
counter = 0      #set up a counter
#iterate through word letter by letter
while counter < len(word):
	#if current letter is vowel, exit loop
	if word[counter] in vowels:
		break
	#don't forget to update the counter!
	counter += 1
#print value of counter when break occurred
print('The word begins with',
	counter,'consonant letters')

