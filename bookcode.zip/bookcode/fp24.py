#an iterator that represents a sequence
#of integers
class Sequence:
	#initialize endpoints
	def __init__(self,low,high):
		self.now = low
		self.high = high
	#required for iterators
	def __iter__(self):
		return self
	#gets the next item
	def __next__(self):
		#must throw this error at limit
		if self.now > self.high:
			raise StopIteration
		#return current value and increment
		else:
			i = self.now
			self.now += 1
			return i

s = Sequence(3,10) #create a new sequence
#iterate through the sequence
for i in s:
	print(i)

