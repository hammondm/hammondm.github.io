class MyGrandparent: #grandparent class def
	info = 'wow'      #class variable
	def hm(self,x):   #instance method
		self.oh = x    #instance variable

#parent class inherits from MyGrandparent
class MyParent(MyGrandparent):
	pass              #nothing in body

#child class inherits from MyParent
class MyChild(MyParent):
	pass              #nothing in body

#an instance of the child class
a = MyChild()
#inherits grandparent class variable
print(a.info)
#inherits grandparent instance method
a.hm('bummer')
#inherits grandparent instance variable
print(a.oh)

