#single statement on the same line
if 2+2 == 4: print('that was true')

