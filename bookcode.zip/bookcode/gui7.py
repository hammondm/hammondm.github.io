from tkinter import *

cs = ['red','blue','green']  #list of colors
fs = [('times',14,'italic'), #list of fonts
('monaco',24),
('Comic Sans MS',30)]

#current foreground, background, and color
fgval = 0
bgval = 0
fontval = 0

#change the *val variables to next leval value
def switch(x):
	if x < 2: x += 1
	else: x = 0
	return x

def fval():                  #change font
	global fontval
	fontval = switch(fontval)
	l.configure(font=fs[fontval])

#change foreground
def fgcol():
	global fgval
	fgval = switch(fgval)
	l.configure(fg=cs[fgval])

#change background
def bgcol():
	global bgval
	bgval = switch(bgval)
	l.configure(bg=cs[bgval])

w = Tk()                     #start GUI
#make and place a label
l = Label(
	w,
	text='I am a label',
	fg=cs[fgval],
	bg=cs[bgval],
	font=fs[fontval],
	padx=30,
	pady=30
)
l.pack()
#button to change foreground
b1 = Button(
	w,
	text='Foreground',
	command=fgcol
)
b1.pack()
#button to change background
b2 = Button(
	w,
	text='Background',
	command=bgcol
)
b2.pack()
#button to change font
b3 = Button(
	w,
	text='Font',
	command=fval
)
b3.pack()
b4 = Button(
	w,
	text='Quit',
	command=quit
)
b4.pack()

mainloop()                   #go...

