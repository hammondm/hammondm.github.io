from tkinter import *

#variable to store number of button presses
count = 0

#function to update button presses
def wow():
	#we're updating the variable above, so
	#we have to specify that
	global count
	count += 1    #update the variable
	#reset the label below
	l.configure(text=count)

w = Tk()         #start the GUI
#make and place a label
l = Label(w,text=count)
l.pack()
b1 = Button(     #make and place a button
	w,
	text='Wow',
	command=wow
)
b1.pack()
b2 = Button(     #make/place another button
	w,
	text='Quit',
	command=quit
)
b2.pack()

mainloop()       #go...

