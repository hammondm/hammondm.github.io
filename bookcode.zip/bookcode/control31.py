i = 1
while i < 4:
	print(i)
	i += 1

