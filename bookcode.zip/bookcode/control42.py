nouns = 'bla dor sna'  #every possible N
verbs = 'ha mog ge di' #every possible V
#every possible SVO combo
for s in nouns.split():
	for v in verbs.split():
		for o in nouns.split():
			print(s,v,o)  #print combination

