#function with 2 args:
#	a function f
#	and something else x
def func(f,x):
	return f(x)

print(func(len,'hat'))  #invoking it

