#variable to accumulate additions
total = 0
for i in range(10000):  #iterate a lot
	total = total + i    #add i to total
print(total)            #print total

