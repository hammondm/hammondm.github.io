x = 'русский язык'
y = '中文'
print(x,': ',len(x),sep='')
print(y,': ',len(y),sep='')

