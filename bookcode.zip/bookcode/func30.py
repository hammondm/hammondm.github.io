def myLen(s):
	'''This computes the length of a string.

	s -- the string
	'''
	return len(s)

