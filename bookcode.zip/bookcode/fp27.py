class Fibonacci:  #an iterator for Fibonacci
	#initialize starting point
	def __init__(self):
		self.now = [1,1]
	#required for iterators
	def __iter__(self):
		return self
	#gets the next item
	def __next__(self):
		#return current value and increment
		i = self.now[-2]
		self.now.append(
			self.now[-2]+self.now[-1]
		)
		return i

f = Fibonacci()   #create a new sequence
#iterate through sequence
for i in range(10):
	print(next(f))

