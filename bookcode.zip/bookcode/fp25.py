#a different kind of iterator
class Students:
	#initialize with list of names
	def __init__(self,listofstudents):
		self.students = listofstudents
	#how to change a name
	def __setitem__(self,n,name):
		self.students[n] = name
	#how to retrieve names
	def __getitem__(self,n):
		  return self.students[n]
	#returns number of names
	def __len__(self):
		return len(self.students)
	#adds a name to the list
	def append(self,name):
		self.students.append(name)
	#deletes an item
	def __delitem__(self,n):
		del self.students[n]

#create a new student list
s = Students(['Mike','Joey'])
s[1] = 'Diane'   #change name of 2nd student
s.append('Bob')  #add a student
del s[0]         #delete a student
for n in s:      #iterate through final list
	print(n)

