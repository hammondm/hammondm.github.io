vowels = 'aeiou'      #define Vs 
consonants = 'ptkbdg' #define Cs
for v in vowels:      #for every vowel:
	#choose a consonant
	for o in consonants:
		#now choose another consonant
		for c in consonants:
			#print them together
			print(o,v,c,sep='')

