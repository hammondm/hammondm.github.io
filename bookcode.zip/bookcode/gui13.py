from tkinter import *
#special import for messageboxes!
from tkinter import messagebox
 
root = Tk()               #start GUI
root.withdraw()           #hide main window
messagebox.showerror(     #error message
	"Error",
	"An error occurred"
)
messagebox.showwarning(   #warning message
	"Warning",
	"You are warned!"
)
messagebox.showinfo(      #info message
	"Info",
	"You are informed."
)
quit()                    #quit

