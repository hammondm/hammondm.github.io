from nltk import pos_tag
from nltk.tokenize import sent_tokenize
from nltk.tokenize import word_tokenize

f = open('alice.txt','r')  #read in alice
t = f.read()
f.close()
t = t[11000:]              #strip header
#break into sentences
ss = sent_tokenize(t)
#go through the first 5 sentences
for s in ss[:5]:
	ws = word_tokenize(s)   #break into words
	print(pos_tag(ws),'\n') #tag and print

