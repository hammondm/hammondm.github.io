class Word:                 #class def
	def whatami():           #method def
		return "I'm a word."  #method body

#invoke method from class name
print('Word:',Word.whatami())

