from tkinter import *
import gui16     #the stemming code

#more verbose instructions
instructions = '''This is a demo of the
Porter stemmer. Type a
word in the box, press
enter or press the button
and the stem form will be
displayed.'''

f = ('times',18) #that pleasing font again

r = Tk()         #start the GUI

#text variable for the entry
ev = StringVar()
ev.set('Type your word here')
#text variable for the result
lv = StringVar()
lv.set('result....')

#instruction label
linfo = Label(text=instructions,font=f)
linfo.pack(pady=10,padx=10)
#entry variable tied to ev
e = Entry(font=f,textvariable=ev)
e.pack(padx=10)
#result variable tied to lv
lres = Label(textvariable=lv,font=f)
lres.pack(pady=10)
#the button that does everything
bstem = Button(text='Stem')
bstem.pack()
#quit button
bquit = Button(text='Quit',command=quit)
bquit.pack(pady=10)
mainloop()       #go...

