if 2 + 2 == 5:   #1-statement block
	print("that shouldn't happen")
print('or this....')
