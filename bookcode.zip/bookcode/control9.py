#nested if with separate statement
if 2+2==4:
	print('wow')
	if 7*7==48:
		print('wow again')
	print('wow a third time')

