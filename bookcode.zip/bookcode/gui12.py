from tkinter import *

w = Tk()           #start GUI
#make and place label
l = Label(text='This is a label')
l.pack()
b1 = Button(       #make a button
	text='wow',
	command=lambda: print('wow')
)
b1.pack(padx=30)   #padding on x-axis
#make another button
b2 = Button(text='quit',command=quit)
b2.pack(ipady=20)  #padding on y-axis

mainloop()         #go...

