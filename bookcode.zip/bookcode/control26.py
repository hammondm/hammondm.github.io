count = 0          #set counter
while count < 3:   #check counter value
	count += 1      #increment, escape clause!
	print(count)

