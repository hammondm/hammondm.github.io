#a list of strings
x = ['Tom','Dick','Harry']
#create a map object where len()
#is applied to each string
y = map(len,x)
#print map object (not too useful)
print(y)
print(list(y)) #convert map object to a list
y = map(len,x) #recreate map object
for i in y:    #iterate through map object
	print(i)
