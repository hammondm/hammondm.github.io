from tkinter import *

w = Tk()
l = Label(
	w,
	text='Hello world!',
	padx=30,
	pady=30
)
l.pack()

mainloop()

