class MyClass:
	def setVal(self,x):
		self.n = x
	def getVal(self):
		return self.n

x = MyClass()
x.setVal(3)
print(x.getVal())

