from nltk.corpus import brown

words = brown.words()  #get the words
for w in words[:5]:    #print first 5 words
	print(w)
#get the sentences
sentences = brown.sents()
#print the first 5 sentences
#(with extra spaces)
for s in sentences[:5]:
	print(s,'\n')

