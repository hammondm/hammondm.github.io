from obj25 import *

a = Segment('a','a')
r = Segment('r','r')
t = Segment('t','t')
n = Nucleus([a])
c = Coda([r,t])
r = Rhyme(n,c)
print(r.spelling)
print(r.pronunciation)

