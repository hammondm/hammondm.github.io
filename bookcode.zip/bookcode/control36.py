vowels = 'aeiou' #define vowels 
word = 'sthenic' #define word
counter = 0      #initialize counter
#go through each letter
for i in range(len(word)):
	#is current letter a vowel?
	if word[i] in vowels:
		continue   #if so, skip it
	#increment counter (only for non-vowels!)
	counter += 1
#print result
print('The word has',
	counter,'consonant letters')

