gv = []      #create global list variable
gv.append(0)

def f1(x):   #function to manipulate global
	gv[0] += x

print(gv[0]) #print initial value of global
f1(3)        #invoke the function
print(gv[0]) #print the new global value

