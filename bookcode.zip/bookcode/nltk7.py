from nltk.corpus import brown

for s in brown.tagged_sents()[:5]:
	print(s,'\n')

