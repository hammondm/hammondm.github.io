#make a list of strings
a = ['Tom','Dick','Harry']
#dictionary comprehension with strings
#as keys and lengths as values
b = {w:len(w) for w in a}
for w in b:
	print('{:>5}: {}'.format(w,b[w]))
