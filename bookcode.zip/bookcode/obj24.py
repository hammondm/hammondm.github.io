from obj23 import *

c = Segment('c','k')
l = Segment('l','l')
o = Onset([c,l])
print(o.spelling)
print(o.pronunciation)

