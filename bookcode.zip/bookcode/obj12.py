class File:        #File class def
	#initialize with string argument
	def __init__(self,s):
		#open connection to file
		f = open(s,'r')
		#read it all in and assign to
		#instance variable
		self.text = f.read()
		f.close()    #close connection
		#strip header
		self.text = self.text[10841:]
		#temp placeholder message!
		print('<file read in>')
	#instance method to return the text
	def getText(self):
		return self.text

class Text:        #Text class def
	#initialize with File arg
	def __init__(self,f):
		#set instance variable
		self.strings = f.getText()
	#return sentences
	def getSentences(self):
		return ['1','2','3','4','5']

#create an instance of File
f = File('alice.txt')
#create Text instance from File instance
t = Text(f)
#get the sentences
ss = t.getSentences()
for s in ss[:3]:   #print the first 3
	print(s)

