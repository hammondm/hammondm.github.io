class Speech:            #speech class def
	#return spelling and pronunciation
	def spell(self):
		return self.spelling
	def pronounce(self):
		return self.pronunciation

class Segment(Speech):   #segment class def
	#initialize from strings
	def __init__(self,s,p):
		if type(s) != str or type(p) != str:
			raise Exception(
				'Usage: Segment(str,str)'
			)
		self.spelling = s
		self.pronunciation = p

class Subsyl(Speech):    #Subsyl class def
	#daughters are segments
	daughters = Segment
	#initialize from list of segments
	def __init__(self,xs):
		self.spelling = '' 
		self.pronunciation = ''
		#check each element in list
		for x in xs:
			if type(x) != self.daughters:
				raise Exception(
					'Type error for Subsyl!'
				)
			#concatenate instance variables
			self.spelling += x.spelling
			self.pronunciation += x.pronunciation

#inherit from Subsyl
class Onset(Subsyl):
	pass
class Nucleus(Subsyl):
	pass
class Coda(Subsyl):
	pass

class Rhyme(Speech):     #Rhyme class def
	#initialize from Nucleus and optional Coda
	def __init__(self,n,c=''):
		#check type of Nucleus
		if type(n) != Nucleus:
			raise Exception(
				'Type error for Rhyme!'
			)
		#set instance variables
		self.spelling = n.spelling
		self.pronunciation = n.pronunciation
		#check if a coda argument is present
		if c != '':
			#check that it's the right type
			if type(c) != Coda:
				raise Exception(
					'Type error for Rhyme!'
				)
			#set instance variables
			self.spelling += c.spelling
			self.pronunciation += c.pronunciation

#still inherits from Speech
class Syllable(Speech):
	pass

