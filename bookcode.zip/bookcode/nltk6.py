from nltk.corpus import stopwords
from nltk.tokenize import wordpunct_tokenize

#sample sentences
s1 = 'Here is a short sentence for you.'
s2 = 'Voici une phrase courte pour vous.'
s3 = 'Вот короткое предложение для вас.'

def identify(s):    #to count stop words
	print(s)
	wds = wordpunct_tokenize(s.lower())
	wdsset = set(wds)
	for l in stopwords.fileids():
		stopwordsset = set(stopwords.words(l))
		score = len(
			wdsset.intersection(stopwordsset)
		)
		print('\t',score,l,
			len(stopwords.words(l))
		)

identify(s1)        #test on the 3 sentences
identify(s2)
identify(s3)

