from tkinter import *
import gui16     #import for stemming code

#instructions
instructions = '''This is a demo of the
Porter stemmer. Type a
word in the box, press
enter or press the button
and the stem form will be
displayed.'''

f = ('times',18) #pleasing font

def guistem():   #invoking stemming function
	w = ev.get()  #get what the user entered
	#stem it
	res = gui16.stem(w)
	lv.set(res)   #display the result

r = Tk()         #start the gui

ev = StringVar() #entry textvariable
ev.set('Type your word here')
lv = StringVar() #result textvariable
lv.set('result....')

#make and place instructoins
linfo = Label(text=instructions,font=f)
linfo.pack(pady=10,padx=10)
#make and place user entry
e = Entry(font=f,textvariable=ev)
e.pack(padx=10)
#make and place result label
lres = Label(textvariable=lv,font=f)
lres.pack(pady=10)
#stemming button
bstem = Button(text='Stem',command=guistem)
bstem.pack()
#quit button
bquit = Button(text='Quit',command=quit)
bquit.pack(pady=10)
mainloop()       #go...

