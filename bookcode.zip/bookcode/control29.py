word = 'alphabet'     #define word
count = 0             #define counter
#iterate while count is less than word length
while count < len(word):
	print(word[count]) #print current letter
	count += 1         #increment counter
	othercount = 1     #start new counter
	#check if 2nd counter is less than 1st
	while othercount < count+1:
		#print ever larger prefixes
		print('\t',word[0:othercount])
		othercount += 1 #increment other counter

