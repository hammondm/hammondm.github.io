print(4+7)
print('that should be 11')

