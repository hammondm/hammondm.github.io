for i in 'tone':
	print(i,end=' ')   #letters with spaces
print()               #add return at end

