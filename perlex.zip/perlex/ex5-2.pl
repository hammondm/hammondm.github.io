#Recursively generate random nested prepositional phrases; the number of phrases
#is given as a command-line argument

#set of possible prepositions
@prepositions = ('in', 'on', 'at');

#set of possible noun phrases
@nounphrases = ('the kitchen', 'the shelf', 'the beach');

#the sentence begins the same way
$presentence = 'I see the man';

#the total number of prepositional phrases
$max = $ARGV[0];

#print out the beginning of the sentence
print($presentence);

#invoke the recursive method
doPPs($max);

#terminate the sentence
print(".\n");

#the recursive method
sub doPPs {
	#this localizes the number of prepositional phrases yet to create
	my($c) = shift();
	if ($c > 0) {
		#selects a random preposition
		my($p) = getRan(@prepositions);
		#selects a random NP
		my($np) = getRan(@nounphrases);
		#prints them out
		print(" $p $np");
		#recurses with one fewer preposition
		doPPs($c - 1);
	}
}

#this selects a random element from an array
sub getRan {
	my(@a) = @_;
	my($r) = rand($#a + 1);
	return($a[$r]);
}

