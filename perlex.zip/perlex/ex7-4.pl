open(F, $ARGV[0]) or die("Oops!\n");

$punc = "[\.\?!]";

while ($line = <F>) {
	#@f = split(/($punc)/, $line);
	@f = split(/($punc)\W/, $line);
	push(@frags, @f);
}

close(F);

foreach $frag (@frags) {
	$sentence .= $frag;
	if ($frag =~ /$punc/) {
		$sentence =~ tr/\n/ /;
		$sentence =~ s/ +/ /g;
		$sentence =~ s/^\W+//;
		push(@sentences, $sentence);
		$sentence = "";
	}
}

foreach $s (@sentences) {
	print("$s\n\n");
}

