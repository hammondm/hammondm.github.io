#!perl

#This program takes the contents of a textfield as input. It strips out any HTML
#code and sends it back to the user as an unformatted page. Note how special
#HTML characters are encoded for transmission via a POST request. We undo that
#encoding here and then strip the HTML

read(STDIN, $stuff, $ENV{CONTENT_LENGTH});

$stuff =~ s/^thehtml=//;
$stuff =~ s/%3C/</g;
$stuff =~ s/%3E/>/g;
$stuff =~ s/%0D%0A/\n/g;
$stuff =~ s/%2F/\//g;
$stuff =~ s/%21/!/g;
$stuff =~ s/\+/ /g;
$stuff =~ s/%26/&/g;
$stuff =~ s/%3B/;/g;
$stuff =~ s/<[^>]+>//g;
$stuff =~ s/&amp;/&/g;
$stuff =~ s/&gt;/>/g;
$stuff =~ s/&lt;/</g;
$stuff =~ s/&quot;/"/g;

print(<<"PLAIN")
Content-type: text/plain

$stuff
PLAIN

