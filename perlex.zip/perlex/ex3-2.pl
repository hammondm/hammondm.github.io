@nouns = ('John', 'Mary', 'Joe');
@verbs = ('sees', 'meets', 'greets');

foreach $n1 (@nouns) {
	foreach $v (@verbs) {
		foreach $n2 (@nouns) {
			print("$n1 $v $n2\n") if ($n1 ne $n2);
		}
	}
}
