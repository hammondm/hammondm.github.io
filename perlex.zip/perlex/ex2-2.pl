print("Hello world! ");
print(" Hello linguist world!\n");
