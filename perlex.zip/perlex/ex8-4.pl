#Stripping HTML is actually quite simple. This program also replaces the special
#characters of HTML.

open(F,"$ARGV[0]") or die("Can't open file\n");

while ($line = <F>) {
	$line =~ s/<[^>]+>//g;
	$line =~ s/&amp;/&/g;
	$line =~ s/&gt;/>/g;
	$line =~ s/&lt;/</g;
	$line =~ s/&quot;/"/g;
	print($line);
}

close(F);

