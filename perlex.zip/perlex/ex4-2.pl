open(F,$ARGV[0]) or die("oops!\n");

while ($line = <F>) {
	$i++;
	if ($i % 2 == 0) {
		unshift(@lines, $line);
	}
}

close(F);

foreach $line (@lines) {
	print($line);
}
