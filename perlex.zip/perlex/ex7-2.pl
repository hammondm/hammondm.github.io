open(F, $ARGV[0]) or die("Oops!\n");

while ($line = <F>) {
	$line =~ tr/0-9//d;
	#one alternative method:
	#$line =~ s/\d+//g;
	#another alternative:
	#$line = $` . $' while ($line =~ /\d/);
	print($line);
}

close(F);

