package Ex6dash4;

use Exporter;
@ISA = ("Exporter");
@EXPORT = ("myjoin");

sub myjoin {
	my($joiner, @elements) = @_;
	my($result) = shift(@elements);
	while (@elements) {
		$result .= $joiner . shift(@elements);
	}
	return($result);
}

1;

