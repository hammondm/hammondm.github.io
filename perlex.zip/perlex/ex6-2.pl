#replace the first print() statement of piglatin1.pl with

print("$1-hay");

