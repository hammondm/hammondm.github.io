$start = time();
$max = 10000;
for ($i = 2; $i <= $max; $i++) {
	$isprime = 0;
	for ($j = 2; $j < $i and $isprime != 1; $j++) {
		$isprime = 1 if ($i % $j == 0);
	}
	print("$i\n") if ($isprime == 0);
}
$end = time();
$diff = $end-$start;
print("Elapsed: $diff\n");
