#There are two properties of interest in this code. First, note how leading and
#ending tags are handled in a single substitution using backreferences. Second,
#notice how, since the two tag sets are switching values, we must save one of
#them with a temporary tag while making the switch.

open(F,"$ARGV[0]") or die("Can't open file\n");

while ($line = <F>) {
	$line =~ s/(<\/?em)(>)/\1x\2/g;
	$line =~ s/(<\/?)i(>)/\1em\2/g;
	$line =~ s/(<\/?)emx(>)/\1i\2/g;
	$line =~ s/(<\/?strong)(>)/\1x\2/g;
	$line =~ s/(<\/?)b(>)/\1strong\2/g;
	$line =~ s/(<\/?)strongx(>)/\1b\2/g;
	print($line);
}

close(F);

