#replace the for-loop of the expprog.pl program with the following:

for ($i = 0; $i < $#newmats; $i++) {
	$then = time();
	print("$newmats[$i] (y/n): ");
	$response = <STDIN>;
	$diff = time() - $then;
	print(RES "$newindices[$i]\t$newmats[$i]\t$diff\t$response");
}
