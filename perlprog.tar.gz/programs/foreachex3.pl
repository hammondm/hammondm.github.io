foreach $n (1..10) {
	print "$n\n";
}
