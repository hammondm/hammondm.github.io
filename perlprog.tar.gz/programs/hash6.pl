$myhash{lion} = 6;
$myhash{tiger} = "lion";
$myhash{bear} = $myhash{lion} .  " " . $myhash{tiger} . "s";

print "using \"values\"\n";
foreach $val (values %myhash) {
	print "value:\t$val\n";
}

print "\nusing \"keys\"\n";
foreach $key (keys %myhash) {
	print "value:\t$myhash{$key}\n";
}

