$name = getlogin;
print "Your name is: $name\n";
if ($name lt 'b') {
	print "Your name begins with \'a\'.\n";
	if ($name lt 'ab') {
		print "Your name must be \'aardvark\'!\n";
	}
}

