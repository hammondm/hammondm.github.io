use Tk;

$b1text = 'show';

$mw = MainWindow->new;
$b1 = $mw->Button(-textvariable => \$b1text, -command => \&doit);
$b1->pack;
$b2 = $mw->Button(-text => 'Quit', -command => sub { exit });

MainLoop;

sub doit {
	if ($b1text eq 'show') {
		$b1text = 'hide';
		$b2->pack;
	} else {
		$b1text = 'show';
		$b2->packForget;
	}
}
