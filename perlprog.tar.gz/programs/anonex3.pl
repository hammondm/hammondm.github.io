@verbs = ('run', 'jump', 'hit');
foreach (@verbs) {
	print;
}
