$i = 10;
do {
	print "$i\n";
	$i++;
} while ($i < 10);
