print "string" . " " . "concatenation\n";
