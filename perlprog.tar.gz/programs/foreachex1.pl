@verbs = ('run', 'jump', 'hit');
foreach $verb (@verbs) {
	print "$verb\n";
}
