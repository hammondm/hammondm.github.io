open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	$line =~ tr/\341\351\355\363\372/aeiou/;
	print $line;
}

close F;

