#initialize
system cls;
$materials = $ARGV[0];
$results = $ARGV[1];

#read materials
open MATS, $materials or die "Can't open materials file!\n";
$i = 0;
while ($line = <MATS>) {
	chomp $line;
	push @mats, $line;
	push @indices, $i;
	$i++;
}
close MATS;

#randomize materials
srand;
while ($#mats > -1) {
	$r = rand $#mats+1;
	$item = splice @mats, $r, 1;
	$index = splice @indices, $r, 1;
	push @newmats, $item;
	push @newindices, $index;
}

#present materials, saving results
print "For each of the following sentences, indicate\
whether you find it acceptable or not.\n";
open RES, ">>$results" or die "Can't save results!\n";
for ($i = 0; $i <= $#newmats; $i++) {
	print "$newmats[$i] (y/n): ";
	$response = <STDIN>;
	print RES "$newindices[$i]\t$newmats[$i]\t$response";
}

close RES;

