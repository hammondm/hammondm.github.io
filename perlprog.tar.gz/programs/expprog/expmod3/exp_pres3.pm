package exp_pres3;

use Exporter;
@ISA = ("Exporter");
@EXPORT = ("&presentmats");

#present materials, saving results
sub presentmats {
	my $response;
	my $resfile = shift;
	my @mats = @_;
	print "For each of the following words, indicate\
the number of syllables.\n";
	open RES, ">>$resfile" or die "Can't save results!\n";
	for (my $i = 0; $i <= $#{$mats[0]}; $i++) {
		print $mats[0][$i];
		$response = &getResp;
		print RES "$mats[1][$i]\t$mats[0][$i]\t$response";
	}
	close RES;
}

sub getResp {
	my $response = 0;
	while ($response < 1) {
		print " (enter a number): ";
		$response = <STDIN>;
		$response += 0;
	}
	return $response;
}

1;

