use exp_init2;
use exp_read2;
use exp_pres2;
use exp_rand2;

&initialize(@ARGV);

&presentmats($ARGV[1], &randomizemats(&readmaterials($ARGV[0])));

