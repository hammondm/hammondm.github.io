package exp_init2;

use Exporter;
@ISA = ("Exporter");
@EXPORT = ("&initialize");

#does initialization; replace "cls" with "clear" for unix
sub initialize {
	my @args = @_;
	system cls;
	if ($#args != 1) {
		die "usage:\tperl expprog5.pl materialsfile resultsfile\n";
	}
}

1;

