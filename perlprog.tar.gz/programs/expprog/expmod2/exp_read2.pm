package exp_read2;

use Exporter;
@ISA = ("Exporter");
@EXPORT = ("&readmaterials");

#reads materials from file into array
sub readmaterials {
	my @mats;
	my $line;
	my $matsfile = shift;
	open MATS, $matsfile or die "Can't open materials file!\n";
	my $i = 0;
	while ($line = <MATS>) {
		chomp $line;
		push @{$mats[0]}, $line;
		push @{$mats[1]}, $i;
		$i++;
	}
	close MATS;
	return @mats;
}

1;

