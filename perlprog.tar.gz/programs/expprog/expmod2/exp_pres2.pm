package exp_pres2;

use Exporter;
@ISA = ("Exporter");
@EXPORT = ("&presentmats");

#present materials, saving results
sub presentmats {
	my $response;
	my $resfile = shift;
	my @mats = @_;
	print "For each of the following sentences, indicate\
whether you find it acceptable or not.\n";
	open RES, ">>$resfile" or die "Can't save results!\n";
	for (my $i = 0; $i <= $#{$mats[0]}; $i++) {
		print "$mats[0][$i] (y/n): ";
		$response = <STDIN>;
		print RES "$mats[1][$i]\t$mats[0][$i]\t$response";
	}
	close RES;
}

1;

