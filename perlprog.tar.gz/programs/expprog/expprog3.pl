&initialize(@ARGV);
&presentmats($ARGV[1],&randomizemats(&readmaterials($ARGV[0])));

#does initialization; replace "cls" with "clear" for unix
sub initialize {
	my @args = @_;
	system cls;
	if ($#args != 1) {
		die "usage:\tperl expprog3.pl materialsfile resultsfile\n";
	}
}

#reads materials from file into array
sub readmaterials {
	my @mats;
	my $line;
	my $matsfile = shift;
	open MATS, $matsfile or die "Can't open materials file!\n";
	my $i = 0;
	while ($line = <MATS>) {
		chomp $line;
		push @{$mats[0]}, $line;
		push @{$mats[1]}, $i;
		$i++;
	}
	close MATS;
	return @mats;
}

#randomizes materials, saving initial indices
sub randomizemats {
	my ($r, $item, $index);
	my @mats = @_;
	my @newmats;
	srand;
	while ($#{$mats[0]} > -1) {
		$r = rand $#{$mats[0]}+1;
		$item = splice @{$mats[0]}, $r, 1;
		$index = splice @{$mats[1]}, $r, 1;
		push @{$newmats[0]}, $item;
		push @{$newmats[1]}, $index;
	}
	return @newmats;
}

#present materials, saving results
sub presentmats {
	my $response;
	my $resfile = shift;
	my @mats = @_;
	print "For each of the following sentences, indicate\
whether you find it acceptable or not.\n";
	open RES, ">>$resfile" or die "Can't save results!\n";
	for (my $i = 0; $i <= $#{$mats[0]}; $i++) {
		print "$mats[0][$i] (y/n): ";
		$response = <STDIN>;
		print RES "$mats[1][$i]\t$mats[0][$i]\t$response";
	}
	close RES;
}

