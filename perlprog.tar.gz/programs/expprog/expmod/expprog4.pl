use exp_init;
use exp_read;
use exp_pres;
use exp_rand;

&exp_init::initialize(@ARGV);

&exp_pres::presentmats($ARGV[1],
	&exp_rand::randomizemats(&exp_read::readmaterials($ARGV[0])));

