package exp_init;

#does initialization; replace "cls" with "clear" for unix
sub initialize {
	my @args = @_;
	system cls;
	if ($#args != 1) {
		die "usage:\tperl expprog4.pl materialsfile resultsfile\n";
	}
}

1;

