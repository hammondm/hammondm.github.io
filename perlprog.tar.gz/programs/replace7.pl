open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	$num+= $line =~ tr/0-9/0-9/;
}

close F;

print "$num\n";

