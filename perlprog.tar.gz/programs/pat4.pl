if ($#ARGV != 1) {
	die "usage:\tperl pat4.pl filename number-of-consonants\n";
}

if ($ARGV[1] !~ /\d+/) {
	die "second argument must be a number\n";
}

$c = "[bcdfghjklmnpqrstvwxz]";

$thepattern = "";

for ($i = 1; $i <= $ARGV[1]; $i++) {
	$thepattern .= $c;
}

$thepattern .= "[\.\?!;: ]";

open F, $ARGV[0] or die "can\'t open file...\n";

while ($line = <F>) {
	if ($line =~ /$thepattern/) {
		print $line;
	}
}

close F;

