print "Language family program\n";

$theprompt =  "Enter a language family> ";
$otherprompt = "Enter a specific language> ";
$i = 0;

print $theprompt;

while (($family = <STDIN>) ne "\n") {
	chomp $family;
	$j = 0;
	$family[$i][$j++] = $family;
	print $otherprompt;
	while (($language = <STDIN>) ne "\n") {
		chomp $language;
		$family[$i][$j++] = $language;
		print $otherprompt;
	}
	print $theprompt;
	$i++;
}

for ($i = 0; $i <= $#family; $i++) {
	print "Family:\t$family[$i][0]\n";
	for ($j = 1; $j <= $#{$family[$i]}; $j++) {
		print "Language:\t$family[$i][$j]\n";
	}
}

