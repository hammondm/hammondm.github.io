@frCountries = ('France', 'Canada');
$myData{French} = \@frCountries;
@enCountries = ('USA', 'Canada', 'England');
$myData{English} = \@enCountries;
@toCountries = ('USA', 'Mexico');
$myData{'Tohono O\'odham'} = \@toCountries;

foreach $key (sort keys %myData) {
	print "$key:\t@{$myData{$key}}\n";
}
