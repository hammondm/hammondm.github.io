
@letters = 'a'..$ARGV[0];
@numbers = 1..$ARGV[1];
&let;

sub let {
	for ($i = 0; $i <= $#letters; $i++) {
		print "$letters[$i]";
		&num;
		&pn;
	}
}

sub num {
	for ($i = 0; $i <= $#numbers; $i++) {
		print "\t$numbers[$i]";
	}
}

sub pn {
	print "\n";
}

