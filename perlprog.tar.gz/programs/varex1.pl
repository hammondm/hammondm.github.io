$myvariable = 4 + 2;
print "The variable is: ";
print $myvariable;
print "\n";
