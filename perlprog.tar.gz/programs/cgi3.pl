#!perl

$date = localtime;

print <<"HERE";
Content-type: text/html

<html>
<head>
<title>What time is it?</title>
</head>
<body>
The time here is: $date.
</body>
</html>
HERE

