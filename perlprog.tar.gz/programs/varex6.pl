$start = time;
$name = getlogin;
print "Hello, $name!\n";
$end = time;
$diff = $end - $start;
print "That took $diff seconds.\n";
