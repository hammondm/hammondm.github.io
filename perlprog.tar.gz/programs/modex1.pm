package modex1;

sub printit {
	my ($name, $food);
	if ($#_ == 0) {
		$name = "Joe";
		$food = "donuts";
	} elsif ($#_ == 1) {
		$name = shift;
		$food = "donuts";
	} else {
		$name = shift;
		$food = shift;
		foreach (@_) {
			$food = $food . " and " . $_;
		}
	}
	print "Dear $name:\nThank you for the $food!\n\n";
}

1;

