print "Enter a number: ";
$number = <STDIN>;
chomp $number;
print &times37;
&pn;

sub times37 {
	return $number * 37;
}

sub pn {
	print "\n";
}

