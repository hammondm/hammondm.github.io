$max = 100;
for ($i = 2; $i <= $max; $i++) {
	$nat = 0;
	for ($j = 2; $j < $i and $nat != 1; $j++) {
		$nat = 1 if ($i % $j == 0);
	}
	print "$i\n" if ($nat == 0);
}
