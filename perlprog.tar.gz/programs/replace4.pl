open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	$line =~ tr/0-9/a-j/;
	print $line;
}

close F;

