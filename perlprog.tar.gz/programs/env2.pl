#!perl

print "Content-type: text/html\n\n";

print "<html><head><title>ENV information</title><head><body><ol>\n";

foreach $key (keys %ENV) {
	print "<li>$key\t$ENV{$key}\n";
}

print "</ol></body></html>\n";

