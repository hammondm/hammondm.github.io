use Tk;

$mw = MainWindow->new;
$mw->Button(
	-text => 'Button 1',
	-command => sub { exit })->pack;
$mw->Button(
	-text => 'Button 2',
	-command => sub { exit })->pack;
$mw->Button(
	-text => 'Button 3',
	-command => sub { exit })->pack;

MainLoop;

