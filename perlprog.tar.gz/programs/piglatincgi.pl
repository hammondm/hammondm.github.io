#!perl

print <<'HEAD';
Content-type: text/html

<html>
<head>
<title>Pig Latin CGI</title>
</head>
<body>
HEAD

if (exists $ENV{PATH_INFO}) {
	$word = $ENV{PATH_INFO};
	$word =~ s/^\///;
	print "You entered <strong>$word</strong>.<p>\n";
	print "The Pig Latin form is: ";
	$c = "[bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXZ]";
	$v = "[aeiouyAEIOUY]";
	if ($word =~ /^[yY]?($v.*)$/) {
		print "$1-yay";
	} elsif ($word =~ /^($c+)(.*)$/) {
		print "$2-$1ay";
	}
	print ".<p>\n";
} else {
	print "You didn't enter a word in the URL!<p>\n";
}

print <<'TAIL';
</body>
</html>
TAIL

