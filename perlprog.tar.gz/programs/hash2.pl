$myhash{lion} = 6;
$myhash{tiger} = "lion";
$myhash{bear} = $myhash{lion} . " " . $myhash{tiger} . "s";

if (exists $myhash{$ARGV[0]}) {
	print $myhash{$ARGV[0]} . "\n";
} else {
	print "Not a key in this hash!\n";
}

