open F, $ARGV[0] or die "Can't open file!\n";
while (<F>) {
	print;
}
close F;

