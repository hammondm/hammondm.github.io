#!perl

print <<'HTML';
Content-type: text/html

<html>
<head>
<title>First CGI!</title>
</head>
<body>
You've reached my <strong>first</strong> CGI program.
</body>
</html>
HTML

