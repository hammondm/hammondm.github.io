die "Usage:\tperl piglatin.pl filename\n" if ($#ARGV != 0);

$c = "[bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXZ]";
$v = "[aeiouyAEIOUY]";

open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	if (length $line == 1) {
		print $line;
	} else {
		while ($line =~ /^(\W*)(\w+)(\W*)/) {
			$prebreak = $1;
			$word = $2;
			$break = $3;
			$line = $';
			if ($word =~ /^[yY]?($v.*)$/) {
				print "$1-yay";
			} elsif ($word =~ /^($c+)(.*)$/) {
				print "$2-$1ay";
			}
			print $break;
		}
	}
}

close F;

