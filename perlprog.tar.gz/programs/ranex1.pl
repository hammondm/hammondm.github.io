$howmany = $ARGV[0];
$howbig = $ARGV[1];
for ($i = 0; $i < $howmany; $i++) {
	$r = rand $howbig;
	print "$i\t$r\n";
}

