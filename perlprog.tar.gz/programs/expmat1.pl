@consonant = ('b','c','d','f','g','h','j','k','l','m',
				  'n','p','q','r','s','t','v','w','x','y','z');
@vowel = ('a','e','i','o','u');

foreach $c1 (@consonant) {
	foreach $v1 (@vowel) {
		foreach $c2 (@consonant) {
			foreach $v2 (@vowel) {
				print "$c1$v1$c2$v2\n";
			}
		}
	}
}
