	@lets = 0..9;
print "@lets\n";
	while ($#lets > -1) {
$r = rand $#lets+1;
	$let = splice @lets, $r, 1;
push @newlets, $let;
	}
print "@newlets\n";

