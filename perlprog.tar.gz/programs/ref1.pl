$myVar = $ARGV[0];
$myRef = \$myVar;
print "$$myRef\n";

