open F, $ARGV[2] or die "Oops!\n";

while ($line = <F>) {
	$num += ($line =~ s/$ARGV[0]/$ARGV[1]/g);
	print $line;
}

close F;

print "how many:\t$num\n";

