foreach $a ('a'..'j') {
	print "$a\n";
}
