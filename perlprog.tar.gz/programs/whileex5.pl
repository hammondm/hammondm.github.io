$then = time;
do {
	$now = time;
	$diff = $now - $then;
} while ($diff < 6);
print "done!\n";
