$myhash{lion} = 6;
$myhash{tiger} = "lion";
$myhash{bear} = $myhash{lion} . " " . $myhash{tiger} . "s";

print $myhash{$ARGV[0]} . "\n";

