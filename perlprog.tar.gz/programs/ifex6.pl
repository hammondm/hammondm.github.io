$hat = 4;
$coat = -7;
if ($hat < 17 or $coat == 6) {
	print "$hat and $coat\n";
}
