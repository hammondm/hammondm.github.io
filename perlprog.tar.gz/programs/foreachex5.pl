foreach ('k'..'t') {
	print;
}
