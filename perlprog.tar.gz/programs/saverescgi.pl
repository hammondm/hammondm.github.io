#!perl

read STDIN, $results, $ENV{CONTENT_LENGTH};

$date = localtime; 

open F, '>>expres.txt' or die "oops!\n";
print F "$date\t$results\n";
close F;

print <<'MYHTML';
Content-type: text/html

<html>
<head>
<title>Thank you!</title>
</head>
<body>
Thank you for participating in our experiment!
</body>
</html>
MYHTML
