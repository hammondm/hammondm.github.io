open F, $ARGV[0] or die "File couldn't be opened!\n";

while ($line = <F>) {
	$chars += length $line;
	$lines++;
}

close F;

print "lines: $lines, characters: $chars\n";

