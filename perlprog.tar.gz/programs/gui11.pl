use Tk;

$mw = MainWindow->new;
$mw->Label(-text => 'Make a selection')->pack;
$mw->Button(
	-text => 'German',
	-command => [\&doLang, 'g'])->pack;
$mw->Button(
	-text => 'French',
	-command => [\&doLang, 'f'])->pack;
$mw->Button(
	-text => 'English',
	-command => [\&doLang, 'e'])->pack;
$mw->Label(-textvariable => \$msg)->pack;

MainLoop;

sub doLang {
	$myLang = shift;
	if ($myLang eq 'g') {
		$msg = "Sprechen Sie Deutsch?";
	} elsif ($myLang eq 'f') {
		$msg = "Parlez vous Fran�ais?";
	} else {
		$msg = "Do you speak English?";
	}
}

