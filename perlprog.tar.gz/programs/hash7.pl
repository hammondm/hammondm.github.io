$myhash{lion} = 6;
$myhash{tiger} = "lion";
$myhash{bear} = $myhash{lion} .  " " . $myhash{tiger} . "s";

print "using \"values\"\n";
foreach $val (sort values %myhash) {
	print "value:\t$val\n";
}

print "\nusing \"keys\"\n";
foreach $key (keys %myhash) {
	push @myarray, $myhash{$key};
}
foreach $index (sort @myarray) {
	print "value:\t$index\n";
}

