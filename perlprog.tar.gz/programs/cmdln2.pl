if ($#ARGV == -1) {
	print "No command-line arguments!\n";
} else {
	for ($j = 0; $j <= $#ARGV; $j++) {
		print "$ARGV[$j]\n";
	}
}
