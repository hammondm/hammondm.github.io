sub pn {
	print "\n";
}

@verbs = ('run', 'jump', 'hit');
foreach (@verbs) {
	print;
	pn;
}

