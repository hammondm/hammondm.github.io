$res = 6 * .5;
if ($res == 1) {
	print "1\n";
} elsif ($res * 3 == 6) {
	print "something small\n";
} elsif ($res == 0) {
	print "nothing\n";
}

