open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	$line =~ tr/0-9//d;
	print $line;
}

close F;

