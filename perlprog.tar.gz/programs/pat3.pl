open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	if ($line =~
		/e						#begins with e
			(					#followed by any number of (a(ab|c\d*)\W)
				a				#a
					(			#union of (ab|c\d*)
						ab		#first conjunct
						|		#or
						c\d*	#second conjunct
					)			#end of union
				\W				#non-alphanumeric
			)*					#end of big kleene group
		d/x					#ends with a d
		) {
		print $line;
	}
}

close F;

