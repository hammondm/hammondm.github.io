#!perl

@words = ("hat", "towel", "cowl", "flour", "flower", "happy", "charity");

&randomizeWords;
&doHeader;
&doItems;
&doEnd;

sub randomizeWords {
	my $word, @temp, $ind;
	while ($#words > -1) {
		$ind = rand ($#words + 1);
		$word = splice @words, $ind, 1;
		push @temp, $word;
	}
	@words = @temp;
}

sub doHeader {
	print <<'HEADER';
Content-type: text/html

<html>
<head>
<title>Syllabification experiment</title>
</head>
<body>
<h4>For each of the items below, indicate the number of syllables:</h4>
<form action="http://hammond.ling.arizona.edu/cgi-bin/saverescgi.pl" method=POST>
<ol>
HEADER
}

#<form action="http://www.mysite.org/saverescgi.pl" method=POST>

sub doItems {
	foreach $item (@words) {
		print <<"ITEM";
<li><strong>$item</strong><br>
1<input type="radio" name=$item value=1>
2<input type="radio" name=$item value=2>
3<input type="radio" name=$item value=3>
4<input type="radio" name=$item value=4>
ITEM
	}
}

sub doEnd {
	print <<'MYEND';
</ol>
<input type="submit" value="submit responses">
</form>
</body>
</html>
MYEND
}

