open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	@f = split /([\.\?!])/, $line;
	push @frags, @f;
}

close F;

foreach $frag (@frags) {
	if ($frag !~ /\w/) {
		print "$frag\n\n";
	} else {
		print "$frag";
	}
}

