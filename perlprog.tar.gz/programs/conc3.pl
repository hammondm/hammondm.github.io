open F, $ARGV[0] or die "Enter a file name\n";

$initial = 1;

while ($line = <F>) {
	chomp $line;
	@words = split /([ \.\?,!;:]+)/, $line;
	foreach $word (@words) {
		if ($word =~ /[\.\?!]+/) {
			$initial = 1;
		} elsif ($word =~ /[ ;:]+/) {
			#do nothing in this case!
		} elsif ($initial) {
			$initial = 0;
			if (exists $init{$word}) {
				$init{$word}++;
			} else {
				$init{$word} = 1;
			}
		} else {
			if (exists $medial{$word}) {
				$medial{$word}++;
			} else {
				$medial{$word} = 1;
			}
		}
	}
}

close F;

foreach $initword (keys %init) {
	$lcword = $initword;
	$lcword =~ tr/A-Z/a-z/;
	if (exists $medial{$initword}) {
		$medial{$initword} += $init{$initword};
	} elsif (exists $medial{$lcword}) {
		$medial{$lcword} += $init{$initword};
	} else {
		$medial{$initword} = $init{$initword};
	}
}

foreach $word (sort {lc($a) cmp lc($b)} keys %medial) {
	print "$word:\t$medial{$word}\n";
}

