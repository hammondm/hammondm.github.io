#randomization demo
@lets = 0..9;							#creates array of 10 numbers
print "@lets\n";
#loops over the @lets array
while ($#lets > -1) {
	$r = rand $#lets+1;				#gets random number
	$let = splice @lets, $r, 1;	#pulls out random array element
	push @newlets, $let;				#puts it in the new array
}
print "@newlets\n";

