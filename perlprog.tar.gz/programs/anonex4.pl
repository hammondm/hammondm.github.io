@verbs = ('run', 'jump', 'hit');
foreach (@verbs) {
	print "$_\n";
}
