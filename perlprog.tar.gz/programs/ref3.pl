$myHash{$ARGV[0]} = 1;
$myHash{$ARGV[1]} = 2;

$myRef = \%myHash;
print "$ARGV[0]\t$$myRef{$ARGV[0]}\n";
print "$ARGV[1]\t$$myRef{$ARGV[1]}\n";

%hash2 = %$myRef;
print "$ARGV[0]\t$hash2{$ARGV[0]}\n";
print "$ARGV[1]\t$hash2{$ARGV[1]}\n";
