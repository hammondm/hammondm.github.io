$myhash{lion} = 6;
$myhash{tiger} = "lion";
$myhash{bear} = $myhash{lion} .  " " . $myhash{tiger} . "s";

&enter;

while (length $line > 0) {
	if (exists $myhash{$line}) {
		delete $myhash{$line};
	} else {
		print "New key!\nEnter a value: ";
		$val = <STDIN>;
		chomp $val;
		$myhash{$line} = $val;
	}
	&enter;
}

sub enter {
	&printall;
	print "Enter a key: ";
	$line = <STDIN>;
	chomp $line;
}

sub printall {
	foreach $key (keys %myhash) {
		print "$key\t$myhash{$key}\n";
	}
}

