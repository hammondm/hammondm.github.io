use Tk;

$count = 0;
$countmsg = $count++ . " presses";

$mwin = MainWindow->new;
$mwin->Label(-text => "Press the button")->pack;
$mwin->Button(
	-text => "Press me",
	-command => sub { $countmsg = $count++ . " presses"})->pack;
$mwin->Label(-textvariable => \$countmsg)->pack;
$mwin->Button(-text => "Quit", -command => sub { exit })->pack;

MainLoop;
