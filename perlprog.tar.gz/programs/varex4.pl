$hat = "chair";
$chair = "hat";
print "$hat\n$chair\n";
