if ("hats" eq "hat" . "s") {
	print "yes\n";
}
if ("had" lt "hat") {
	print "yes again\n";
}
