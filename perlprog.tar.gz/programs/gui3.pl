use Tk;

$mw = MainWindow->new;
$mw->Button(
	-text => 'top',
	-command => sub { exit })->pack(-side => 'top');
$mw->Button(
	-text => 'bottom',
	-command => sub { exit })->pack(-side => 'bottom');
$mw->Button(
	-text => 'left',
	-command => sub { exit })->pack(-side => 'left');
$mw->Button(
	-text => 'right',
	-command => sub { exit })->pack(-side => 'right');

MainLoop;

