$arr[0] = $ARGV[0];
$arr[1] = $ARGV[1];

$myRef = \@arr;
print "$$myRef[0]\n";
print "$$myRef[1]\n";

@arr2 = @$myRef;
print "$arr2[0]\n";
print "$arr2[1]\n";

