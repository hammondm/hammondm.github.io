open F, $ARGV[0] or die "Oops!\n";

while ($line = <F>) {
	$line =~ s/
		\d+	#some number of digits
		/
		$&		#the numbers again
		*3		#multiplied by 3
		/gxe;
	print $line;
}

close F;

