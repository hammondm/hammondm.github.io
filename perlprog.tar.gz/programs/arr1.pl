$verb[0] = "run";
$verb[1] = "junk";
$verb[2] = "sing";
print "The three verbs are: $verb[0], $verb[1], and $verb[2].\n";

