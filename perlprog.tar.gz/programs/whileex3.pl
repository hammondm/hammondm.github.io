$i = 10;
while ($i > 0) {
	print "$i\n";
	$i--;
}
