$myData{French} = ['France', 'Canada'];
$myData{English} = ['USA', 'Canada', 'England'];
$myData{'Tohono O\'odham'} = ['USA', 'Mexico'];

foreach $key (sort keys %myData) {
	print "$key:\t@{$myData{$key}}\n";
}
