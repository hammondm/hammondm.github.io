module MathModal

where

import Control.Monad (liftM2)


data World = W Int deriving Eq

instance Show World where
   show (W i) = "w" ++ (show i)


data Model = Model [World] [(World,World)]
             [(World,Wff)] deriving (Eq,Show)

getWorlds                   :: Model -> [World]
getWorlds (Model ws _ _)    =  ws

getAccess                   :: Model -> [(World,World)]
getAccess (Model _ as _)    =  as

getValuation                :: Model -> [(World,Wff)]
getValuation (Model _ _ vs) =  vs


value1           :: Model -> World -> Wff -> Bool
value1 m wld wff =  elem (wld,wff) (getValuation m)


worlds1 :: [World]
worlds1 =  [W 1,W 2]

access1 :: [(World,World)]
access1 =  [(W 1,W 1),(W 2,W 1),(W 2,W 2)]

valuations1 :: [(World,Wff)]
valuations1 =  [(W 1,P),(W 2,P),(W 1,Q)]

model1 :: Model
model1 =  Model worlds1 access1 valuations1


value2                 :: Model -> World -> Wff -> Bool
value2 m wld (Not wff) =  not (value2 m wld wff)
value2 m wld wff       =  elem (wld,wff) (getValuation m)


value3                   :: Model -> World -> Wff -> Bool
value3 m wld (Not wff)   =  not (value3 m wld wff)
value3 m wld (And w1 w2) =  (value3 m wld w1) && (value3 m wld w2)
value3 m wld (Or w1 w2)  =  (value3 m wld w1) || (value3 m wld w2)
value3 m wld (If w1 w2)  =  not (value3 m wld w1) ||
                            (value3 m wld w2)
value3 m wld (Iff w1 w2) =  (value3 m wld (If w1 w2)) &&
                            (value3 m wld (If w2 w1))
value3 m wld wff         =  elem (wld,wff) (getValuation m)


data Wff = P | Q | R | S |
           Not Wff |
           And Wff Wff |
           Or Wff Wff |
           If Wff Wff |
           Iff Wff Wff |
           Box Wff |
           Diamond Wff
           deriving Eq

instance Show Wff where
   show P = "p"
   show Q = "q"
   show R = "r"
   show S = "s"
   show (Not w) = "¬" ++ (show w)
   show (And x y) = "(" ++ (show x) ++ " ∧ " ++ (show y) ++ ")"
   show (Or x y) = "(" ++ (show x) ++ " ∨ " ++ (show y) ++ ")"
   show (If x y) = "(" ++ (show x) ++ " → " ++ (show y) ++ ")"
   show (Iff x y) = "(" ++ (show x) ++ " ↔ " ++ (show y) ++ ")"
   show (Box w) = "◻" ++ (show w)
   show (Diamond w) = "◇" ++ (show w)


getAWlds                :: World -> [(World,World)] -> [World]
getAWlds _ []           =  []
getAWlds w ((w1,w2):ws) =  if w == w1
                           then w2:getAWlds w ws
                           else getAWlds w ws

value :: Model -> Wff -> World -> Bool
value m (Not wff) wld   =  not (value m wff wld)
value m (And w1 w2) wld =  (value m w1 wld) && (value m w2 wld)
value m (Or w1 w2) wld  =  (value m w1 wld) || (value m w2 wld)
value m (If w1 w2) wld  =  not (value m w1 wld) || (value m w2 wld)
value m (Iff w1 w2) wld
      =  (value m (If w1 w2) wld) && (value m (If w2 w1) wld)
value m (Box w) wld
      =  and (map (value m w) (getAWlds wld (getAccess m)))
value m (Diamond w) wld
      =  or (map (value m w) (getAWlds wld (getAccess m)))
value m wff wld         =  elem (wld,wff) (getValuation m)


--powerset of a list
ps        :: [a] -> [[a]]
ps []     =  [[]]
ps (x:xs) =  ps xs ++ map (x:) (ps xs)

--makes tuples of an element with all members of a list
maketuple          :: a -> [b] -> [(a,b)]
maketuple _ []     =  []
maketuple x (y:ys) =  (x,y):maketuple x ys

--makes all possible access relations from a list of worlds
makeaccess    :: [World] -> [[(World,World)]]
makeaccess ws =  map concat (sequence (map (\x -> (map (maketuple x)) (ps ws)) ws))

--makes all possible valuations from WFFs and worlds
makevals       :: [Wff] -> [World] -> [[(World,Wff)]]
makevals vs ws =  map concat (sequence (map (\x -> map (maketuple x) (ps vs)) ws))

--makes all combinations of access and valuations
makecombos       :: [[(World,World)]] -> [[(World,Wff)]] ->
                      [([(World,World)],[(World,Wff)])]
makecombos xs ys = liftM2 (,) xs ys

--checks a wff against a set of worlds and a access-valuation pair
doModel            :: Wff -> [World] -> ([(World,World)],[(World,Wff)]) -> IO ()
doModel w ws (a,v) =  do let m = Model ws a v
                         putStrLn $ show m
                         mapM_ (\x -> putStrLn ("\t" ++ (show x) ++
                             ": " ++ (show (value m w x)))) ws

--checks a wff against a set of worlds and basic wffs
checkWFF             :: Wff -> [World] -> [Wff] -> IO ()
checkWFF w wlds vals = do let access = makeaccess wlds
                          let values = makevals vals wlds
                          let combos = makecombos access values
                          putStrLn $ show $ length combos
                          mapM_ (doModel w wlds) combos


data TLwff = TLp | TLq | TLr | TLs |
             TLif TLwff TLwff |
             TLiff TLwff TLwff |
             TLand TLwff TLwff |
             TLor TLwff TLwff |
             TLnot TLwff |
             TLG TLwff |
             TLH TLwff |
             TLF TLwff |
             TLP TLwff deriving Eq

instance Show TLwff where
   show TLp = "p"
   show TLq = "q"
   show TLr = "r"
   show TLs = "s"
   show (TLnot w) = "¬" ++ (show w)
   show (TLand x y) = "(" ++ (show x) ++ " ∧ " ++ (show y) ++ ")"
   show (TLor x y) = "(" ++ (show x) ++ " ∨ " ++ (show y) ++ ")"
   show (TLif x y) = "(" ++ (show x) ++ " → " ++ (show y) ++ ")"
   show (TLiff x y) = "(" ++ (show x) ++ " ↔ " ++ (show y) ++ ")"
   show (TLG w) = "G" ++ (show w)
   show (TLH w) = "H" ++ (show w)
   show (TLF w) = "F" ++ (show w)
   show (TLP w) = "P" ++ (show w)


data TLworld = TLw Int deriving Eq

instance Show TLworld where
   show (TLw i) = "w" ++ (show i)


data TLmodel = TLmodel Int [(TLworld,TLwff)] deriving (Eq,Show)


tlvalues1 :: [(TLworld,TLwff)]
tlvalues1 =  [(TLw 1,TLp),
              (TLw 2,TLp),
              (TLw 3,TLp),
              (TLw 3,TLq),
              (TLw 4,TLq),
              (TLw 5,TLq)]

tlmodel1 :: TLmodel
tlmodel1 =  TLmodel 5 tlvalues1


getTLvalues                :: TLmodel -> [(TLworld,TLwff)]
getTLvalues (TLmodel _ vs) =  vs

getTLworlds               :: TLmodel -> Int
getTLworlds (TLmodel w _) =  w


getlater           :: TLmodel -> TLworld -> [TLworld]
getlater m (TLw n) =  map TLw [(n+1)..(getTLworlds m)]

getearlier         :: TLworld -> [TLworld]
getearlier (TLw n) =  map TLw [1..(n-1)]

tlvalue  :: TLmodel -> TLwff -> TLworld -> Bool
tlvalue m (TLand x y) wld =  (tlvalue m x wld) && (tlvalue m y wld)
tlvalue m (TLor x y) wld  =  (tlvalue m x wld) || (tlvalue m y wld)
tlvalue m (TLif x y) wld  =  (tlvalue m (TLnot x) wld) ||
                             (tlvalue m y wld)
tlvalue m (TLiff x y) wld =  (tlvalue m (TLif x y) wld) &&
                             (tlvalue m (TLif y x) wld)
tlvalue m (TLnot w) wld   =  not (tlvalue m w wld)
tlvalue m (TLG w) wld
         =  and (map (tlvalue m w) (getlater m wld))
tlvalue m (TLF w) wld     =  or (map (tlvalue m w) (getlater m wld))
tlvalue m (TLP w) wld     =  or (map (tlvalue m w) (getearlier wld))
tlvalue m w wld           =  elem (wld,w) (getTLvalues m)


