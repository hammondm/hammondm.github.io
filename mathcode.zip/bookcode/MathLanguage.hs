module MathLanguage

where

import Data.List (isPrefixOf,nub,sort)
import Control.Monad (liftM2)


data Node = N String | T String deriving (Eq,Show)

data Rule = Rule [Node] [Node] deriving (Eq,Show)

data Grammar = G Node [Rule] deriving Show


--convert a string into a list of terminals
makeTerminals   :: String -> [Node]
makeTerminals s =  map T (words s)


g = G (N "S") [Rule [N "S"] [N "NP",N "VP"],
               Rule [N "NP"] [T "John"],
               Rule [N "NP"] [T "Mary"],
               Rule [N "VP"] [N "V",N "NP"],
               Rule [N "V"] [T "loves"]]


--do a single match of a rule
domatch :: [Node] -> [Node] -> [Node] -> Int -> [Node]
domatch r rs xs n
  = if isPrefixOf rs (drop n xs)
    then (take n xs) ++ r ++ (drop (n + (length rs)) xs)
    else []

--match a rule anywhere in a list
getmatches :: [Node] -> [Node] -> [Node] -> [[Node]]
getmatches r rs xs
  = filter (/=[]) (map (domatch r rs xs) [0..(length xs)])

--match a list of rules
dosubs                     :: [Rule] -> [Node] -> [[Node]]
dosubs [] ws               =  []
dosubs ((Rule n ns):rs) ws =  (getmatches n ns ws) ++ (dosubs rs ws)

--parse a list of terminals
parse             :: Grammar -> [Node] -> Bool
parse (G n rs)  ws =  if [n] == ws
                      then True
                      else or (map (parse (G n rs)) (dosubs rs ws))


g1 = G (N "W") [Rule [N "A"] [T "p"],
                Rule [N "A"] [T "q"],
                Rule [N "A"] [N "A",T "'"],
                Rule [N "W"] [N "A"],
                Rule [N "W"] [T "(",N "W",T "&",N "W",T ")"]]


g2 = G (N "S") [Rule [N "S"] [T "b"],
                Rule [N "S"] [N "A",T "b"],
                Rule [N "A"] [T "a"],
                Rule [N "A"] [N "A",T "a"]]


g3 = G (N "S") [Rule [N "S"] [T "b"],
                Rule [N "S"] [T "a",N "S"]]


g4 = G (N "S") [Rule [N "S"] [T "a",N "C"],
                Rule [N "C"] [T "c",N "C"],
                Rule [N "C"] [T "b"]]


data State = State String deriving (Eq,Ord)

instance Show State where
  show (State s) = "q" ++ s


--states start-state alphabet transitions final-states
data FSA = FSA [State] State [Char] [(State,Char,[State])] [State]

instance Show FSA where
  show (FSA ss _ _ as _) = (show ss) ++ ": " ++ (show as)

getstart                 :: FSA -> State
getstart (FSA _ s _ _ _) =  s

getfinal                 :: FSA -> [State]
getfinal (FSA _ _ _ _ f) =  f

gettrans                 :: FSA -> [(State,Char,[State])]
gettrans (FSA _ _ _ t _) =  t

isfinal                    :: State -> FSA -> Bool
isfinal s (FSA _ _ _ _ fs) =  elem s fs


gett :: (State,Char) -> [(State,Char,[State])] -> [State]
gett _ []               =  []
gett (a,b) ((c,d,e):cs) =  if a == c && b == d
                             then e
                             else gett (a,b) cs

legalfrom            :: String -> FSA -> State -> Bool
legalfrom "" f s     =  isfinal s f
legalfrom (c:cs) f s =  any (legalfrom cs f)
                        (gett (s,c) (gettrans f))

legal     :: String -> FSA -> Bool
legal s f =  legalfrom s f (getstart f)


q1,q2 :: State
q1    =  State "1"
q2    =  State "2"

tmap :: [(State,Char,[State])]
tmap =  [(q1,'a',[q1]),(q1,'b',[q2]),(q2,'b',[q2])]

fsa :: FSA
fsa =  FSA [q1,q2] q1 "ab" tmap [q2]


getthird         :: (a,b,c) -> c
getthird (_,_,x) =  x

isdeterministic   :: FSA -> Bool
isdeterministic f =  all (==1) (map (length . getthird)
                     (gettrans f))


q0 :: State
q0 =  State "0"

arcs :: [(State,Char,[State])]
arcs =  [(q0,'b',[q0,q1]),(q1,'a',[q0]),(q1,'b',[q0])]

nfa1 :: FSA
nfa1 =  FSA [q0,q1] q0 "ab" arcs [q1]


getstates                  :: FSA -> [State]
getstates (FSA ss _ _ _ _) =  ss

getalpha                  :: FSA -> [Char]
getalpha (FSA _ _ as _ _) =  as

iscomplete   :: FSA -> Bool
iscomplete f =  all (not . null) (map (flip gett ts) combos)
                where
                ts = gettrans f
                ss = getstates f
                as = getalpha f
                combos = liftM2 (,) ss as


earcs = [(q0,'a',[q0,q1]),
         (q0,'b',[q0]),
         (q1,'a',[q1]),
         (q1,'b',[q1]),
         (q1,'E',[q0])]

enfa :: FSA
enfa =  FSA [q0,q1] q0 "ab" earcs [q1]


eclosure :: [State] -> FSA -> State -> [State]
eclosure ss f s 
         =  if elem s ss
            then ss
            else nub ([s] ++ ss ++ newnewstates)
               where
               states = gett (s,'E') (gettrans f)
               newstates = filter (\x -> not (elem x ss)) states
               newnewstates =
                  concat (map (eclosure (ss ++ [s]) f) newstates)


earcs2 = [(q0,'a',[q1]),
          (q0,'E',[q1]),
          (q1,'b',[q2]),
          (q1,'E',[q2]),
          (q2,'a',[q2])]

enfa2 :: FSA
enfa2 =  FSA [q0,q1,q2] q0 "ab" earcs2 [q2]


earcs3 = [(q0,'a',[q1]),
          (q0,'E',[q1]),
          (q1,'b',[q0]),
          (q1,'E',[q0])]

enfa3 :: FSA
enfa3 =  FSA [q0,q1] q0 "ab" earcs3 [q1]


elegalfrom        :: String -> FSA -> State -> Bool
elegalfrom "" f s =  any (flip isfinal f) (eclosure [] f s)
elegalfrom (c:cs) f s 
                  =  any (elegalfrom cs f) (concat ss)
                     where
                     ss = map (eclosure [] f) (gett (s,c)
                          (gettrans f))

elegal     :: String -> FSA -> Bool
elegal s f =  any (elegalfrom s f) (eclosure [] f (getstart f))


legalstart                  :: FSA -> Bool
legalstart (FSA ss s _ _ _) =  elem s ss


legalarcsyms                   :: FSA -> Bool
legalarcsyms (FSA _ _ ss as _) =  all (chkss ('E':ss)) as
                                  where
                                  chkss lets (_,s,_) = elem s lets


legalarcstates :: FSA -> Bool
legalarcstates (FSA ss _ _ as _)
               =  all (checkss ss) as
                  where
                  checkss ss (s1,_,ss2) = elem s1 ss &&
                     all (flip elem ss) ss2


legalfinal                   :: FSA -> Bool
legalfinal (FSA ss _ _ _ fs) =  all (flip elem ss) fs


check   :: FSA -> Bool
check f =  legalfinal f &&
           legalarcstates f &&
           legalarcsyms f &&
           legalstart f


makestate                     :: FSA -> State -> String
makestate (FSA _ st _ _ fs) s =  res
  where
  start = "\tnode [shape="
  middle = if elem s fs
           then "doublecircle"
           else "circle"
  late = if st == s
         then ",penwidth=2"
         else ",penwidth=1"
  end = ",label=<" ++ (show s) ++ ">] \"" ++ (show s) ++ "\";\n"
  res = start ++ middle ++ late ++ end

makearc          :: (State,Char,[State]) -> String
makearc (s,c,ss) =
  concat (map (\x -> ("\t\"" ++ (show s) ++ "\" -> \"" ++ (show x) ++ label)) ss)
  where
  sym = if c == 'E'
        then "&epsilon;"
        else [c]
  label = "\" [label=\"" ++ sym ++ "\"];\n"

makedot      :: FSA -> FilePath -> IO ()
makedot f fn =  writeFile fn res
                where
                start = "digraph A {\n\trankdir = LR;\n"
                states = concat (map (makestate f) (getstates f))
                arcs = concat (map makearc (gettrans f))
                end = "}"
                res = start ++ states ++ arcs ++ end


ps        :: [State] -> [[State]]
ps []     =  [[]]
ps (x:xs) =  ps xs ++ map (x:) (ps xs)

getarcs :: [([State],Char)] -> [(State,Char,[State])] ->
           FSA -> [(State,Char,[State])]
getarcs [] as _  =  []
getarcs ((ss,a):xs) as f
  =  first:getarcs xs as f
     where
     fromstate = State (show (sort ss))
     ssec = nub (concat (map (eclosure [] f) ss))
     tostates = concat (map (\x -> (gett (x,a) as)) ssec)
     tostateset = concat (map (eclosure [] f) tostates)
     tostate = State (show (sort (nub tostateset)))
     first = (fromstate,a,[tostate])

determinize :: FSA -> FSA
determinize f =  FSA statenames start alpha newarcs finals
                 where
                 states = ps (getstates f)
                 statenames = map (State . show . sort) states
                 alpha = getalpha f
                 start = State (show [getstart f])
                 oldfinals = getfinal f
                 havefinals = map (\x -> filter (elem x) states)
                              oldfinals
                 finals = map (State . show . sort)
                          (nub (concat havefinals))
                 oldarcs = gettrans f
                 combos = liftM2 (,) states alpha
                 newarcs = getarcs combos oldarcs f


getoutstates                  :: [(State,Char,[State])] ->
                                 State -> [[State]]
getoutstates [] _             =  []
getoutstates ((s1,_,s2):as) s =  if s == s1
                                 then s2:getoutstates as s
                                 else getoutstates as s

accessfrom :: [State] -> [(State,Char,[State])] -> State -> [State]
accessfrom ss as s =
  res
  where
  outstates = concat (getoutstates as s)
  statestocheck = filter (\x -> not (elem x ss)) outstates
  res = if (length statestocheck) > 0
        then concat (map
                     (accessfrom (ss ++ statestocheck) as)
                     statestocheck)
        else ss

accessible   :: FSA -> [State]
accessible f =  nub (accessfrom [start] (gettrans f) start)
                where
                start = getstart f


winnowarcs       :: [State] -> [(State,Char,[State])] ->
                    [(State,Char,[State])]
winnowarcs ss [] =  []
winnowarcs ss ((s1,c,[s2]):as)
                 =  if (elem s1 ss) && (elem s2 ss)
                    then (s1,c,[s2]):winnowarcs ss as
                    else winnowarcs ss as

prune                        :: FSA -> FSA
prune (FSA ss s alpha as fs) =  FSA tokeep s alpha newarcs newfinal
           where
           tokeep = accessible (FSA ss s alpha as fs)
           newfinal = filter (\x -> elem x tokeep) fs
           newarcs = winnowarcs tokeep as


idx      :: [State] -> State -> Int
idx xs i =  myidx 0 i xs
            where
            myidx _ _ []     = -1
            myidx n i (x:xs) = if i == x
                               then n
                               else myidx (n+1) i xs

makenewarcs        :: [State] -> Int -> [(State,Char,[State])] ->
                      [(State,Char,[State])]
makenewarcs _ _ [] =  []
makenewarcs ss n ((s1,c,ss2):as)
                   = (ns1,c,nss2):makenewarcs ss n as
                     where
                     ns1 = State (show ((idx ss s1)+n))
                     nss2 = map (State . show . (+n))
                            (map (idx ss) ss2)

rename :: Int -> FSA -> FSA
rename n (FSA ss s as arcs fs)
        = FSA newstates newstart as newarcs newfinals
          where
          newstates = map (State . show) [n..(n + (length ss) - 1)]
          newstart = (State . show) ((idx ss s) + n)
          newfinals = map (State . show . (+n)) (map (idx ss) fs)
          newarcs = makenewarcs ss n arcs


epsilon :: FSA
epsilon =  FSA [q0] q0 "" [] [q0]

symbol   :: Char -> FSA
symbol c =  FSA [q0,q1] q0 [c] [(q0,c,[q1])] [q1]


conc       :: FSA -> FSA -> FSA
conc f1 f2 =  FSA states start alpha arcs finals
              where
              f1x = rename 0 f1
              f2x = rename (length (getstates f1x)) f2
              start = getstart f1x
              finals = getfinal f2x
              alpha = (getalpha f1x) ++ (getalpha f2x)
              states = (getstates f1x) ++ (getstates f2x)
              f1finals = getfinal f1x
              f2start = getstart f2x
              epsarcs = map (\x -> (x,'E',[f2start])) f1finals
              arcs = (gettrans f1x) ++ epsarcs ++ (gettrans f2x)


union       :: FSA -> FSA -> FSA
union f1 f2 =  FSA states start alpha arcs finals
               where
               f1x = rename 0 f1
               f2x = rename (length (getstates f1x)) f2
               startnum = (length (getstates f1x)) +
                          (length (getstates f2x))
               start = State (show startnum)
               finals = (getfinal f1x) ++ (getfinal f2x)
               alpha = nub ((getalpha f1x) ++ (getalpha f2x))
               states = (getstates f1x) ++
                        (getstates f2x) ++ [start]
               arc = (start,'E',[getstart f1x,getstart f2x])
               arcs = (gettrans f1x) ++ (gettrans f2x) ++ [arc]


makenewfinalarcs :: [(State,Char,[State])] -> State -> [State] ->
                    [(State,Char,[State])] -> [(State,Char,[State])]
makenewfinalarcs ns _ [] as = ns ++ as
makenewfinalarcs ns f os [] = ns ++ (map (\x -> (x,'E',[f])) os)
makenewfinalarcs ns f os ((a,b,cs):as)
   = if b == 'E' && (elem a os)
     then makenewfinalarcs ((a,b,f:cs):ns) f (filter (/=a) os) as
     else makenewfinalarcs ((a,b,cs):ns) f os as

kleene   :: FSA -> FSA
kleene f =  FSA states start alpha newarcs finals
            where
            fx = rename 0 f
            startnum = length (getstates fx)
            finalnum = startnum + 1
            start = State (show startnum)
            final = State (show finalnum)
            alpha = getalpha fx
            states = [start,final] ++ (getstates fx)
            finals = [start,final]
            oldarcs = gettrans fx
            arc1 = (start,'E',[getstart fx])
            arc2 = (final,'E',[start])
            oldfinals = getfinal fx
            arcs = makenewfinalarcs [] final oldfinals oldarcs
            newarcs = arcs ++ [arc1,arc2]


rlg                                   :: Grammar -> Bool
rlg (G s [])                          =  True
rlg (G s ((Rule [N _] [T _]):rs))     =  rlg (G s rs)
rlg (G s ((Rule [N _] [T _,N _]):rs)) =  rlg (G s rs)
rlg _                                 =  False


rlg2states                     :: [Rule] -> [State]
rlg2states []                  =  []
rlg2states ((Rule [N s] _):rs) =  (State s):rlg2states rs

rlg2alpha                           :: [Rule] -> [Char]
rlg2alpha []                        =  []
rlg2alpha ((Rule _ ((T [t]):_):rs)) =  t:rlg2alpha rs

rlg2arcs    :: [Rule] -> [(State,Char,[State])]
rlg2arcs [] =  []
rlg2arcs ((Rule [N m] [T [t]]):rs)
  = (State m,t,[State "F"]):rlg2arcs rs
rlg2arcs ((Rule [N m] [T [t],N n]):rs)
  = (State m,t,[State n]):rlg2arcs rs

rlg2fsa              :: Grammar -> FSA
rlg2fsa (G (N s) rs) =  FSA (final:states) start alpha arcs [final]
                        where
                        start = State s
                        states = nub (rlg2states rs)
                        alpha = nub (rlg2alpha rs)
                        arcs = rlg2arcs rs
                        final = State "F"


complement   :: FSA -> FSA
complement f =  FSA states start alpha arcs newfinals
                where
                df = rename 0 (prune (determinize f))
                states = getstates df
                oldfinals = getfinal df
                newfinals = filter
                            (\x -> not (elem x oldfinals))
                            states
                start = getstart df
                alpha = getalpha df
                arcs = gettrans df


setalpha                             :: FSA -> String -> FSA
setalpha (FSA ss s as arcs fs) alpha =  FSA ss s alpha arcs fs

intersect       :: FSA -> FSA -> FSA
intersect f1 f2 =  complement (union fc1 fc2)
                   where
                   alpha = nub ((getalpha f1) ++ (getalpha f2))
                   fc1 = complement (setalpha f1 alpha)
                   fc2 = complement (setalpha f2 alpha)


