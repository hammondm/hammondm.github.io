module MathSets

where



data Set a = Set [a]


addToSet      :: Eq a => a -> [a] -> [a]
addToSet x ss =  if elem x ss then ss else x:ss


makeSet        :: Eq a => [a] -> [a]
makeSet []     =  []
makeSet (x:xs) =  addToSet x (makeSet xs)


addCommas        :: Show a => [a] -> String
addCommas [x]    =  show x
addCommas (x:xs) =  (show x) ++ "," ++ addCommas xs


instance (Eq a,Show a) => Show (Set a) where
   show (Set []) = "∅"
   show (Set xs) = "{" ++ addCommas (makeSet xs) ++ "}"


myFilter          :: (a -> Bool) -> [a] -> [a]
myFilter _ []     =  []
myFilter f (x:xs) =  if f x then x:myFilter f xs else myFilter f xs


setFilter            :: (a -> Bool) -> Set a -> Set a
setFilter f (Set xs) =  Set (myFilter f xs)


consonants :: Set String
consonants =  Set ["p","t","k","b","d","g",
                   "f","s","T","S","v","z","D","Z",
                   "m","n","N","l","r","y","w","h"]


isNasal   :: String -> Bool
isNasal s =  elem s ["m","n","N","i~","e~","ae~"]


inf   :: Int -> [Int]
inf n =  n:inf (n+1)


myTake          :: Int -> [a] -> [a]
myTake 0 _      =  []
myTake n (x:xs) =  x:myTake (n-1) xs


setTake           :: Int -> Set a -> Set a
setTake n (Set s) =  Set (myTake n s)


infList     :: (a -> a) -> a -> [a]
infList f x =  x:infList f (f x)


infSet     :: a -> (a -> a) -> Set a
infSet s f =  Set (infList f s)


prefixA   :: String -> String
prefixA x =  'a':x


setSize         :: Eq a => Set a -> Int
setSize (Set s) =  length (makeSet s)


setMem           :: Eq a => a -> Set a -> Bool
setMem e (Set s) =  elem e s


myAll          :: (a -> Bool) -> [a] -> Bool
myAll _ []     =  True
myAll f (x:xs) =  f x && myAll f xs


biggerThanThree   :: Int -> Bool
biggerThanThree x =  x > 3


subset                 :: Eq a => Set a -> Set a -> Bool
subset (Set a) (Set b) =  myAll (flip elem b) a


myNot       :: Bool -> Bool
myNot True  =  False
myNot False =  True


properSubset     :: Eq a => Set a -> Set a -> Bool
properSubset x y =  (subset x y) && myNot (subset y x)


instance (Eq a) => Eq (Set a) where
  (==) x y = (subset x y) && (subset y x)


powerSet         :: Eq a => Set a -> Set (Set a)
powerSet (Set s) =  Set (map Set (ps (makeSet s)))
                    where
                    ps []     = [[]]
                    ps (x:xs) = ps xs ++ map (x:) (ps xs)


union                 :: Eq a => Set a -> Set a -> Set a
union (Set a) (Set b) =  Set (a ++ b)


intersect                 :: Eq a => Set a -> Set a -> Set a
intersect (Set x) (Set y) =  Set (myFilter (flip elem y) x)


difference                 :: Eq a => Set a -> Set a -> Set a
difference (Set x) (Set y) =  Set (myFilter minus x)
                              where
                              minus e = myNot (elem e y)


u :: Set Char
u =  Set ['a'..'z']


complement   :: Set Char -> Set Char
complement s =  difference u s


pair2set       :: (a, a) -> Set (Set a)
pair2set (x,y) =  Set [Set [x],Set [x,y]]


set2pair                     :: Eq b => Set (Set b) -> (b, b)
set2pair (Set [Set x,Set y]) =  (z,w)
  where z = if length x == 1 then x !! 0 else y !! 0
        two = if length x == 2 then x else y
        w = if two !! 0 == z then two !! 1 else two !! 0


cartesian :: (Eq a,Eq b) => Set a -> Set b -> Set (a,b)
cartesian (Set x) (Set y)
          =  Set [(w,z)|w <- (makeSet x),z <- (makeSet y)]


noOthers :: (Eq a, Eq b) => (a, b) -> [(a, b)] -> Bool
noOthers _ []
         =  True
noOthers (x,y) ((z,w):zs)
         =  (x /= z || y == w) && noOthers (x,y) zs

isFunction :: (Eq a, Eq b) => Set (a, b) -> Bool
isFunction (Set [])
           =  True
isFunction (Set ((x,y):zs))
           =  noOthers (x,y) zs && isFunction (Set zs)


upper = ['A'..'Z']
lower = ['a'..'z']
lower2upper = Set (zip lower upper)


lowerUpperU = cartesian (Set lower) (Set upper)


use                       :: Eq t => Set (t, a) -> t -> [a]
use (Set []) x         =  []
use (Set ((y,z):ws)) x =  if y == x
                             then z:use (Set ws) x
                             else use (Set ws) x


inverse          :: Set (b, a) -> Set (a, b)
inverse (Set xs) =  Set [(y,x)|(x,y) <- xs]


