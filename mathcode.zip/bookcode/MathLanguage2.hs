{-# OPTIONS_GHC -Wno-x-partial #-}
module MathLanguage2

where

import Data.List (isPrefixOf,intercalate,nub)


data Node = N String | T String deriving Eq

instance Show Node where
   show (N s) = s
   show (T s) = s

data Rule = Rule [Node] [Node] deriving (Eq,Show)

data Grammar = G Node [Rule]

showrule              :: Rule -> String
showrule (Rule ns []) =  "\t" ++ (intercalate " " (map show ns)) ++
                         " → ε"
showrule (Rule ns ms) =  "\t" ++ (intercalate " " (map show ns)) ++
                         " → " ++ (intercalate " " (map show ms))

showrules    :: [Rule] -> String
showrules rs =  intercalate "\n" (map showrule rs)

instance Show Grammar where
   show (G (N s) rs) = s ++ ":\n" ++ (showrules rs)

makeTerminals   :: String -> [Node]
makeTerminals s =  map T (words s)


cfg                           :: Grammar -> Bool
cfg (G _ [])                  =  True
cfg (G n ((Rule [N _] _):rs)) =  cfg (G n rs)
cfg _                         =  False


g1 = G (N "S") [Rule [N "S"] [],
                Rule [N "S"] [T "a",N "S",T "b"]]

g2 = G (N "S") [Rule [T "S"] [],
                Rule [N "S"] [T "a",N "S",T "b"]]

g3 = G (N "S") [Rule [N "S",N "Q"] [T "a"],
                Rule [N "S"] [T "a",N "S",T "b"]]


domatch :: [Node] -> [Node] -> [Node] -> Int -> [Node]
domatch r rs xs n 
        =  if isPrefixOf rs (drop n xs)
           then (take n xs) ++ r ++ (drop (n + (length rs)) xs)
           else []

getmatches :: [Node] -> [Node] -> [Node] -> [[Node]]
getmatches r rs xs 
           =  filter (/=[]) (map (domatch r rs xs) [0..(length xs)])

dosubs                     :: [Rule] -> [Node] -> [[Node]]
dosubs [] ws               =  []
dosubs ((Rule n ns):rs) ws =  (getmatches n ns ws) ++ (dosubs rs ws)

parseorig :: Grammar -> [Node] -> Bool
parseorig (G n rs)  ws 
          =  if [n] == ws
             then True
             else or (map (parseorig (G n rs)) (dosubs rs ws))


g4 = G (N "S0") [Rule [N "S0"] [N "S"],
                 Rule [N "S0"] [],
                 Rule [N "S"] [T "a",N "S",T "b"],
                 Rule [N "S"] [T "a",T "b"]]


epsilons                            :: Grammar -> [Node]
epsilons (G _ [])                   =  []
epsilons (G n ((Rule [N x] []):rs)) =  (N x):epsilons (G n rs)
epsilons (G n (_:rs))               =  epsilons (G n rs)

rightstart                       :: Grammar -> Bool
rightstart (G _ [])              =  False
rightstart (G s ((Rule n m):rs)) =  elem s m || rightstart (G s rs)

epslegal          :: Grammar -> Bool
epslegal (G n rs) =  eps == [] || (eps == [n] &&
                       not (rightstart (G n rs)))
                     where
                     eps = epsilons (G n rs)


nullable                          :: Grammar -> [Node]
nullable (G n [])                 =  []
nullable (G n ((Rule [m] []):rs)) =  m:nullable (G n rs)
nullable (G n (_:rs))             =  nullable (G n rs)


addstart          :: Grammar -> Grammar
addstart (G n rs) =  G (N "S0") ((Rule [N "S0"] [n]):rs)


addrules                      :: [Node] -> [Rule] -> [Rule]
addrules _ []                 =  []
addrules ns ((Rule as bs):rs) =  if new == bs
                                 then addrules ns rs
                                 else (Rule as new):addrules ns rs
                                 where
                                 new = filter
                                       (\x -> not (elem x ns)) bs

droprules                     :: Node -> [Rule] -> [Rule]
droprules _ []                =  []
droprules s ((Rule as []):rs) =  if as == [s]
                                 then (Rule as []):droprules s rs
                                 else droprules s rs
droprules s (r:rs)            =  r:droprules s rs

convert   :: Grammar -> Grammar
convert g =  G n allrules
             where
             (G n rs) = addstart g
             nulls = nullable (G n rs)
             newrules = addrules nulls rs
             allrules = droprules n (newrules ++ rs)


subparse             :: Grammar -> [Node] -> Bool
subparse (G n rs) [] =  elem (Rule [n] []) rs
subparse (G n rs) ts =  parseorig (G n newrules) ts
                        where
                        newrules = filter (/=(Rule [n] [])) rs

parse      :: Grammar -> [Node] -> Bool
parse g ts =  if cfg g
              then if epslegal g
                   then subparse g ts
                   else subparse (convert g) ts
              else error "Not a CFG"


data State = State String deriving Eq

instance Show State where
   show (State s) = "q" ++ s

type Transition = (State,Char,Char,State,String)

data PDA = PDA [State] [Char] [Char] State [Transition] [State]
   deriving (Eq,Show)


q0 = State "0"
q1 = State "1"
pda1ts = [(q0,'a','E',q0,"c"),
          (q0,'b','c',q1,"E"),
          (q1,'b','c',q1,"E")]
pda1 = PDA [q0,q1] "ab" "c" q0 pda1ts [q0,q1]

pda2ts = [(q0,'a','E',q0,"A"),
          (q0,'b','E',q0,"B"),
          (q0,'a','A',q1,"E"),
          (q0,'b','B',q1,"E"),
          (q1,'a','A',q1,"E"),
          (q1,'b','B',q1,"E")]
pda2 = PDA [q0,q1] "ab" "AB" q0 pda2ts [q0,q1]


makestate                       :: PDA -> State -> String
makestate (PDA _ _ _ st _ fs) s =  res
  where
  start = "\tnode [shape="
  middle = if elem s fs
           then "doublecircle"
           else "circle"
  late = if st == s
         then ",penwidth=2"
         else ",penwidth=1"
  end = ",label=<" ++ (show s) ++ ">] \"" ++
    (show s) ++ "\";\n"
  res = start ++ middle ++ late ++ end

makearc :: Transition -> String
makearc (s1,c1,c2,s2,c3)
        =  "\t\"" ++ (show s1) ++ "\" -> \"" ++ (show s2) ++ label
           where
           sym1 = if c1 == 'E' then "&epsilon;" else [c1]
           sym2 = if c2 == 'E' then "&epsilon;" else [c2]
           sym3 = if c3 == "E" then "&epsilon;" else c3
           label = "\" [label=\"" ++ sym1 ++ ", " ++ sym2 ++
             " &rarr; " ++ sym3 ++ "\"];\n"

makedot      :: PDA -> FilePath -> IO ()
makedot p fn =  writeFile fn res
                where
                start = "digraph A {\n\trankdir = LR;\n"
                states = concat (map (makestate p) (getstates p))
                arcs = concat (map makearc (gettrans p))
                end = "}\n"
                res = start ++ states ++ arcs ++ end


getstates                    :: PDA -> [State]
getstates (PDA ss _ _ _ _ _) =  ss

gettrans                    :: PDA -> [Transition]
gettrans (PDA _ _ _ _ ts _) =  ts

getstart                   :: PDA -> State
getstart (PDA _ _ _ s _ _) =  s

getfinal                    :: PDA -> [State]
getfinal (PDA _ _ _ _ _ fs) =  fs

isfinal                      :: State -> PDA -> Bool
isfinal s (PDA _ _ _ _ _ fs) =  elem s fs


gett      :: (State,Char,String) -> [Transition] -> [(State,String)]
gett _ [] =  []
gett (s1,c1,st) ((s2,c2,c3,s3,c4):ts)
          =  if s1 == s2 && c1 == c2 &&
               (c3 == 'E' || (((length st) > 0) && (head st) == c3))
             then (s3,newstack):gett (s1,c1,st) ts
             else gett (s1,c1,st) ts
             where
             base = if c3 == 'E' then st else tail st
             newstack = if c4 == "E" then base else c4 ++ base


eclosure :: [(State,String)] -> PDA -> 
            (State,String) -> [(State,String)]
eclosure ss p (s,st) 
         =  if elem (s,st) ss
            then ss
            else nub ([(s,st)] ++ ss ++ newnewpairs)
            where
            pairs = gett (s,'E',st) (gettrans p)
            newpairs = filter (\x -> not (elem x ss)) pairs
            newnewpairs =
              concat (map (eclosure (ss ++ [(s,st)]) p) newpairs)


legalfrom :: [Char] -> String -> PDA -> State -> Bool
legalfrom st "" p s
          =  any (\(x,y) -> (isfinal x p) && (length y == 0)) cl
             where
             cl = eclosure [] p (s,st)
legalfrom st (c:cs) p s
          =  any (\(x,y) -> (legalfrom y cs p x)) (concat ss)
             where
             ss = map (eclosure [] p) (gett (s,c,st) (gettrans p))

legal     :: String -> PDA -> Bool
legal s p =  any (\(x,y) -> (legalfrom y s p x))
               (eclosure [] p ((getstart p),""))


isterminal       :: Node -> Bool
isterminal (T _) =  True
isterminal _     =  False

isnonterm   :: Node -> Bool
isnonterm x =  not (isterminal x)

getterminals    :: [Rule] -> [Node]
getterminals [] =  []
getterminals ((Rule _ ys):rs)
  =  nub ((filter isterminal ys) ++ getterminals rs)

getnonterminals    :: [Rule] -> [Node]
getnonterminals [] =  []
getnonterminals ((Rule [x] ys):rs)
  =  nub ((filter isnonterm ys) ++ [x] ++ getnonterminals rs)

makestring       :: Node -> String
makestring (N s) =  s
makestring (T s) =  s


makenontermarcs    :: [Rule] -> [Transition]
makenontermarcs [] =  []
makenontermarcs ((Rule [N [a]] ys):rs)
                   =  (q1,'E',a,q1,right):makenontermarcs rs
                      where
                      right = if ys == []
                              then "E"
                              else concat (map makestring ys)

cfg2pda :: Grammar -> PDA
cfg2pda (G (N [s]) rs)
        =  if cfg (G (N [s]) rs)
           then PDA [q0,q1] terms gamma q0 arcs [q1]
           else error "Grammar must be context-free."
           where
           terms = concat (map makestring (getterminals rs))
           nonterms  = concat (map makestring (getnonterminals rs))
           gamma = terms ++ nonterms
           startarc = [(q0 ,'E','E',q1,[s])]
           termarcs = map (\x -> (q1,x,x,q1,"E")) terms
           nontermarcs = makenontermarcs rs
           arcs = startarc ++ termarcs ++ nontermarcs


g5 = G (N "S") [Rule [N "S"] [T "a",N "S",T "a"],
                Rule [N "S"] [T "b",N "S",T "b"],
                Rule [N "S"] []]


type FSTarc = (State,Char,Char,State)

data FST = FST [State] [Char] [Char] State [State] [FSTarc]
           deriving (Eq,Show)


fstgetstates                    :: FST -> [State]
fstgetstates (FST ss _ _ _ _ _) =  ss

fstgetsigma                     :: FST -> [Char]
fstgetsigma (FST _ sig _ _ _ _) =  sig

fstgetgamma                     :: FST -> [Char]
fstgetgamma (FST _ _ gam _ _ _) =  gam

fstgetstart                   :: FST -> State
fstgetstart (FST _ _ _ s _ _) =  s

fstgetfinal                    :: FST -> [State]
fstgetfinal (FST _ _ _ _ fs _) =  fs

fstgetarcs                    :: FST -> [FSTarc]
fstgetarcs (FST _ _ _ _ _ as) =  as

fstisfinal                      :: State -> FST -> Bool
fstisfinal s (FST _ _ _ _ fs _) =  elem s fs


aa = FST [q0,q1] "a" "a" q0 [q1] [(q0,'a','a',q1)]

bb = FST [q0,q1] "b" "b" q0 [q1] [(q0,'b','b',q1)]


idx            :: Int -> State -> [State] -> Int
idx _ _ []     =  -1
idx n x (y:ys) =  if x == y
                  then n
                  else idx (n+1) x ys

fstnewarcs        :: [State] -> Int -> [FSTarc] -> [FSTarc]
fstnewarcs _ _ [] =  []
fstnewarcs ss n ((s1,c1,c2,s2):as)
   =  (s3,c1,c2,s4):fstnewarcs ss n as
      where
      s3 = State (show (idx n s1 ss))
      s4 = State (show (idx n s2 ss))

rename :: FST -> Int -> FST
rename (FST ss a1 a2 s fs as) n
  =  FST newss a1 a2 news newfs newas
     where
     newss = map (State . show) [n..(n+(length ss)-1)]
     news = State (show ((idx n s ss)))
     newfs = map (\x -> State (show (idx n x ss))) fs
     newas = fstnewarcs ss n as


fstmakestate                       :: FST -> State -> String
fstmakestate (FST _ _ _ st fs _) s =  res
  where
  start = "\tnode [shape="
  middle = if elem s fs
           then "doublecircle"
           else "circle"
  late = if st == s
         then ",penwidth=2"
         else ",penwidth=1"
  end = ",label=<" ++ (show s) ++ ">] \"" ++
    (show s) ++ "\";\n"
  res = start ++ middle ++ late ++ end

fstmakearc :: FSTarc -> String
fstmakearc (s1,c1,c2,s2)
           =  "\t\"" ++ (show s1) ++ "\" -> \"" ++ (show s2) ++ label
              where
              sym1 = if c1 == 'E' then "&epsilon;" else [c1]
              sym2 = if c2 == 'E' then "&epsilon;" else [c2]
              label = "\" [label=\"" ++ sym1 ++ ":" ++ sym2
                 ++ "\"];\n"

fstmakedot      :: FST -> FilePath -> IO ()
fstmakedot p fn =  writeFile fn res
                   where
                   start = "digraph A {\n\trankdir = LR;\n"
                   states = concat (map (fstmakestate p) (fstgetstates p))
                   arcs = concat (map fstmakearc (fstgetarcs p))
                   end = "}\n"
                   res = start ++ states ++ arcs ++ end


conc       :: FST -> FST -> FST
conc f1 f2 =  FST states sigma gamma start finals arcs
              where
              num = length (fstgetstates f1)
              f1x = rename f1 0
              f2x = rename f2 num
              states = (fstgetstates f1x) ++ (fstgetstates f2x)
              sigma = nub ((fstgetsigma f1x) ++ (fstgetsigma f2x))
              gamma = nub ((fstgetgamma f1x) ++ (fstgetgamma f2x))
              start = fstgetstart f1x
              finals = fstgetfinal f2x
              f1finals = fstgetfinal f1x
              f2start = fstgetstart f2x
              newarcs = map (\x -> (x,'E','E',f2start)) f1finals
              arcs = (fstgetarcs f1x) ++ newarcs ++ (fstgetarcs f2x)


union       :: FST -> FST -> FST
union f1 f2 =  FST states sigma gamma start finals arcs
               where
               num1 = length (fstgetstates f1)
               f1x = rename f1 0
               f2x = rename f2 num1
               num2 = num1 + (length (fstgetstates f2x))
               start = State (show num2)
               arc1 = (start,'E','E',(fstgetstart f1x))
               arc2 = (start,'E','E',(fstgetstart f2x))
               states = (fstgetstates f1x) ++ (fstgetstates f2x) ++
                        [start]
               sigma = nub ((fstgetsigma f1x) ++ (fstgetsigma f2x))
               gamma = nub ((fstgetgamma f1x) ++ (fstgetgamma f2x))
               finals = (fstgetfinal f1x) ++ (fstgetfinal f2x)
               arcs = (fstgetarcs f1x) ++ (fstgetarcs f2x) ++
                      [arc1,arc2]


kleene   :: FST -> FST
kleene f =  FST states sigma gamma start finals arcs
            where
            fx = rename f 2
            start = State "0"
            final = State "1"
            startarc = (start,'E','E',(fstgetstart fx))
            finalstartarc = (final,'E','E',start)
            finalarcs = map (\x -> (x,'E','E',final))
                        (fstgetfinal fx)
            sigma = fstgetsigma fx
            gamma = fstgetgamma fx
            states = (fstgetstates fx) ++ [start,final]
            finals = [start,final]
            arcs = [startarc,finalstartarc] ++
                   (fstgetarcs fx) ++ finalarcs


fstgett      :: (State,Char,Char) -> [FSTarc] -> [State]
fstgett _ [] =  []
fstgett (a,b,c) ((d,e,f,g):cs)
             =  if a == d && b == e && c == f
                then g:fstgett (a,b,c) cs
                else fstgett (a,b,c) cs


fsteclosure :: [State] -> FST -> State -> [State]
fsteclosure ss f s 
            = if elem s ss
              then ss
              else nub ([s] ++ ss ++ newnewstates)
                where
                states = fstgett (s,'E','E') (fstgetarcs f)
                newstates = filter (\x -> not (elem x ss)) states
                newnewstates =
                  concat (map (fsteclosure (ss ++ [s]) f) newstates)


fstlegalfrom :: String -> String -> FST -> State -> Bool
fstlegalfrom "" "" f s
             =  any (flip fstisfinal f)
                (fsteclosure [] f s)
fstlegalfrom "" (b:bs) f s
   =  any (fstlegalfrom "" bs f) (concat ss)
      where
      ss = map (fsteclosure [] f) (fstgett (s,'E',b) (fstgetarcs f))
fstlegalfrom (c:cs) "" f s
   =  any (fstlegalfrom cs "" f) (concat ss)
      where
      ss = map (fsteclosure [] f) (fstgett (s,c,'E') (fstgetarcs f))
fstlegalfrom (c:cs) (b:bs) f s
   =  (any (fstlegalfrom cs bs f) (concat ss)) ||
      (any (fstlegalfrom cs (b:bs) f) (concat se)) ||
      (any (fstlegalfrom (c:cs) bs f) (concat es))
      where
      ss = map (fsteclosure [] f) (fstgett (s,c,b) (fstgetarcs f))
      se = map (fsteclosure [] f) (fstgett (s,c,'E') (fstgetarcs f))
      es = map (fsteclosure [] f) (fstgett (s,'E',b) (fstgetarcs f))

fstlegal       :: String -> String -> FST -> Bool
fstlegal c b f =  any (fstlegalfrom c b f)
                  (fsteclosure [] f (fstgetstart f))


fstabc = FST [q0,q1] "a" "bc" q0 [q1]
         [(q0,'a','b',q1),(q1,'E','c',q1)]


