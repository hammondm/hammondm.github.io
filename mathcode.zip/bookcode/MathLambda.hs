module MathLambda

where

import Prelude hiding ((>))


data E = E String deriving (Eq,Show)

type T = Bool


a,b,c :: E
a     =  E "Tom"
b     =  E "Dick"
c     =  E "Harry"

d :: [E]
d  = [a,b,c]


f           :: E -> T
f (E "Tom") =  True
f _         =  False

g             :: E -> T
g (E "Dick")  =  True
g (E "Harry") =  True
g _           =  False

h             :: E -> E -> T
h (E x) (E y) =  elem (x,y) [("Tom","Dick"),
                             ("Tom","Tom"),
                             ("Dick","Tom"),
                             ("Harry","Tom")]

i             :: E -> E -> T
i (E x) (E y) =  elem (x,y) [("Tom","Harry"),("Harry","Tom")]


n   :: T -> T
n x =  not x

(>)   :: T -> T -> T
x > y =  (not x) || y

(!)   :: T -> T -> T
x ! y =  x || y


j     :: (E -> T) -> T
j fnc =  (map fnc d) == (map f d)


mapf         :: (E -> E -> T) -> [E] -> T
mapf f [a,b] =  f a b

k     :: (E -> E -> T) -> T
k fnc =  (map (mapf fnc) dd) == (map (mapf h) dd)
         where dd = sequence [d,d]


true :: a -> b -> a
true =  \x -> (\y -> x)

false :: a -> b -> b
false =  \x -> (\y -> y)


val   :: (Bool -> Bool -> Bool) -> Bool
val f =  f True False


cond :: a -> b -> (a -> b -> c) -> c
cond =  \x -> (\y -> (\f -> f x y))


lcnot   :: ((a -> b -> b) -> (c -> d -> c) -> e) -> e
lcnot x =  cond false true x


lcand     :: (a -> (b -> c -> c) -> d) -> a -> d
lcand x y =  cond y false x

lcor     :: ((a -> b -> a) -> c -> d) -> c -> d
lcor x y =  cond true y x


zero = \f -> (\x -> x)


successor = \n -> (\f -> (\x -> f (n f x)))


mval f = f (+1) 0


add = \m -> (\n -> (\f -> (\x -> (m f) (n f x))))


data Formula = Open1 (E -> T) [E] |
               Open2 (E -> E -> T) [E] |
               Closed T

instance Show Formula where
   show (Open1 _ es) = "open: " ++ (show es)
   show (Open2 _ es) = "open: " ++ (show es)
   show (Closed v)   = "closed: " ++ (show v)


x,y :: E
x   =  E "x"
y   =  E "y"


fa,ga,gb,fx,hxy,hax,hxa,hxx :: Formula
fa                          =  Closed (f a)
ga                          =  Closed (g a)
gb                          =  Closed (g b)
fx                          =  Open1 f [x]
hxy                         =  Open2 h [x,y]
hax                         =  Open1 (h a) [x]
hxa                         =  Open1 (flip h a) [x]
hxx                         =  Open1 (\x -> (h x x)) [x]


fneg                       :: Formula -> Formula
fneg (Closed v)            =  Closed (not v)
fneg (Open1 fx [v])        =  Open1 (\x -> (not (fx x))) [v]
fneg (Open2 fx [v1,v2])    =  Open2 (\x y -> (not (fx x y))) [v1,v2]


fsome :: E -> Formula -> Formula
fsome _ (Closed v)
      =  Closed v
fsome v (Open1 fx [vx])
      =  if v /= vx
         then Open1 fx [vx]
         else Closed (or (map fx d))
fsome v (Open2 fx [v1,v2])
      =  if v /= v1 && v /= v2 --no match
         then Open2 fx [v1,v2]
         else if v == v2       --match second
              then Open1 (\x -> (or (map (fx x) d))) [v1]
              else Open1 (\x -> (or (map (flip fx x) d))) [v2]


fall      :: E -> Formula -> Formula
fall x fx =  fneg (fsome x (fneg fx))


fand :: Formula -> Formula -> Formula
fand (Closed v1) (Closed v2)
     =  Closed (v1 && v2)
fand (Closed v1) (Open1 f2 vs)
     =  Open1 (\x -> (v1 && (f2 x))) vs
fand (Closed v1) (Open2 f2 vs)
     =  Open2 (\x y -> (v1 && (f2 x y))) vs
fand (Open1 f1 vs) (Closed v1)
     =  Open1 (\x -> ((f1 x) && v1)) vs
fand (Open1 f1 [v1]) (Open1 f2 [v2])
     =  if v1 == v2
        then Open1 (\x -> ((f1 x) && (f2 x))) [v1]
        else Open2 (\x y -> ((f1 x) && (f2 y))) [v1,v2]
fand (Open1 f1 [v1]) (Open2 f2 [v21,v22]) 
     =  if v1 == v21
        then Open2 (\x y -> ((f1 x) && (f2 x y))) [v21,v22]
        else Open2 (\x y -> ((f1 y) && (f2 x y))) [v21,v22]
fand (Open2 f1 vs) (Closed v2)
     =  Open2 (\x y -> ((f1 x y) && v2)) vs
fand (Open2 f1 [v11,v12]) (Open1 f2 [v2])
     =  if v11 == v2
        then Open2 (\x y -> ((f1 x y) && (f2 x))) [v11,v12]
        else Open2 (\x y -> ((f1 x y) && (f2 y))) [v11,v12]
fand (Open2 f1 [v11,v12]) (Open2 f2 [v21,v22]) 
     =  if v11 == v21
        then Open2 (\x y -> ((f1 x y) && (f2 x y))) [v11,v12]
        else Open2 (\x y -> ((f1 x y) && (f2 y x))) [v11,v12]


for     :: Formula -> Formula -> Formula
for a b =  fneg (fand (fneg a) (fneg b))

fif     :: Formula -> Formula -> Formula
fif a b =  for (fneg a) b

fiff     :: Formula -> Formula -> Formula
fiff a b =  fand (fif a b) (fif b a)


nil :: p1 -> p2 -> p2
nil =  \c n -> n


cons :: t1 -> ((t1 -> t2 -> t3) -> t4 -> t2) ->
        (t1 -> t2 -> t3) -> t4 -> t3
cons =  (\h t c n -> c h (t c n))


first :: ((t1 -> t2 -> t1) -> t3) -> t3
first =  \l -> l (\h t -> h)


rest :: ((t1 -> (t2 -> t3) -> (t1 -> t3 -> t4) -> t4)
        -> (t5 -> t6) -> (t7 -> t8 -> t8) -> t9)
        -> t2 -> t6 -> t9
rest =  \l c y -> l (\h r x -> x h (r c)) (\x -> y) (\h t -> t)


