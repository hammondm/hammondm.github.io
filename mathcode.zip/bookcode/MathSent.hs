module MathSent

where

import Prelude hiding ((>),(<>))
import Text.Layout.Table (gridString,column,expand,center,def)
import Data.List (transpose)


data Val = T | F deriving (Eq,Show)


land       :: (Val, Val) -> Val
land (T,T) =  T
land (_,_) =  F


makeVars   :: Int -> [[Val]]
makeVars n =  transpose (sequence (take n (repeat [T,F])))


(&)     :: [Val] -> [Val] -> [Val]
xs & ys =  map land (zip xs ys)


makeTable    :: [[Val]] -> IO ()
makeTable xs =  do let zs = transpose xs
                   let ys = map (map show) zs
                   let len = length xs
                   let spec = (column expand center def def)
                   let specs = take len (repeat spec)
                   putStrLn (gridString specs ys)


lor       :: (Val,Val) -> Val
lor (F,F) =  F
lor (_,_) =  T


(!)     :: [Val] -> [Val] -> [Val]
xs ! ys =  map lor (zip xs ys)


lcond       :: (Val,Val) -> Val
lcond (T,F) =  F
lcond (_,_) =  T


(>)     :: [Val] -> [Val] -> [Val]
xs > ys =  map lcond (zip xs ys)


lbicond       :: (Val,Val) -> Val
lbicond (T,T) =  T
lbicond (F,F) =  T
lbicond (_,_) =  F


(<>)     :: [Val] -> [Val] -> [Val]
xs <> ys =  map lbicond (zip xs ys)


lnot   :: Val -> Val
lnot T =  F
lnot F =  T


n    :: [Val] -> [Val]
n xs =  map lnot xs


sheff (T,T) =  F
sheff (_,_) =  T


(#)     :: [Val] -> [Val] -> [Val]
xs # ys =  map sheff (zip xs ys)


