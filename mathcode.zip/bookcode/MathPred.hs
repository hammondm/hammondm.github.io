module MathPred

where


a,b,c :: String
a     =  "Tom"
b     =  "Dick"
c     =  "Harry"


d :: [String]
d =  [a,b,c]


f   :: String -> Bool
f x =  elem x [b,c]


g     :: String -> String -> Bool
g x y =  elem (x,y) [(a,a),(a,c),(b,a),(b,b),(c,c)]


var     :: (String -> b) -> [b]
var fnc =  map fnc d


myAll    :: [Bool] -> Bool
myAll xs =  and xs

mySome    :: [Bool] -> Bool
mySome xs =  or xs


fg     :: String -> String -> Bool
fg x y =  (f x) && (g a y)


