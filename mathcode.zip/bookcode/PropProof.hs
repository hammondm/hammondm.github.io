{- cabal:
build-depends:
  base,
  parsec,
  containers
-}
module Main where

import Prelude hiding (lookup)
import Text.ParserCombinators.Parsec
import Data.Map (lookup,fromList)
import System.Environment (getArgs)
import Data.Char (toLower)

--simple WFFs (no primes!)
data AS = P | Q | R | S | U | V deriving Eq

--displaying simple WFFs
instance Show AS where
   show P = "p"
   show Q = "q"
   show R = "r"
   show S = "s"
   show U = "u"
   show V = "v"

--complex WFFs
data WFF = WFF AS | And WFF WFF    | Or WFF WFF |
     Cond WFF WFF | Bicond WFF WFF | Not WFF |
     T            | F
     deriving Eq

--displaying complex WFFs
instance Show WFF where
   show (And x y) = "(" ++ (show x) ++ " ∧ " ++
      (show y) ++ ")"
   show (Or x y) = "(" ++ (show x) ++ " ∨ " ++
      (show y) ++ ")"
   show (Cond x y) = "(" ++ (show x) ++ " → " ++
      (show y) ++ ")"
   show (Bicond x y) = "(" ++ (show x) ++ " ↔ " ++
      (show y) ++ ")"
   show (Not x) =  "¬" ++ (show x)
   show (WFF x) = show x
   show T = "T"
   show F = "F"

--a rule (justification) in a proof
data Rule = Given                    | Aux                   |
            Rule String Int          | Birule String Int Int |
            Proofrule String Int Int
            deriving Eq

--displaying a rule
instance Show Rule where
   show Given             = "Given"
   show Aux               = "Aux"
   show (Rule s i)        = s ++ " " ++ (show i)
   show (Birule s i j)    = s ++ " " ++ (show i) ++ " " ++ (show j)
   show (Proofrule s i j) = s ++ " " ++ (show i) ++ " " ++ (show j)

--compare two WFFs and feed into deduction rule
doRuleTwo       :: WFF -> WFF -> (WFF -> WFF -> Bool) -> Bool
doRuleTwo x y r =  res where
                         d = mydiff x y
                         res = case d of Nothing -> False
                                         Just (z,w) -> r z w

-- *Domination
dom2             :: WFF -> WFF -> Bool
dom2 (Or _ T) T  =  True
dom2 T (Or _ T)  =  True
dom2 (And _ F) F =  True
dom2 F (And _ F) =  True
dom2 _ _         =  False
dom     :: WFF -> WFF -> Bool
dom x y =  doRuleTwo x y dom2

-- *Complement Laws
comp2                   :: WFF -> WFF -> Bool
comp2 (Or x (Not y)) T  =  x == y
comp2 T (Or x (Not y))  =  x == y
comp2 (And x (Not y)) F =  x == y
comp2 F (And x (Not y)) =  x == y
comp2 _ _               =  False
comp     :: WFF -> WFF -> Bool
comp x y =  doRuleTwo x y comp2

--Double Complement Law
double2                 :: WFF -> WFF -> Bool
double2 (Not (Not x)) y =  x == y
double2 y (Not (Not x)) =  x == y
double2 _ _             = False
double     :: WFF -> WFF -> Bool
double x y =  doRuleTwo x y double2

--DeMorgan's Laws
demorgan2                                      :: WFF -> WFF -> Bool
demorgan2 (Not (Or x y)) (And (Not z) (Not w)) =  x == z && y == w
demorgan2 (And (Not z) (Not w)) (Not (Or x y)) =  x == z && y == w
demorgan2 (Not (And x y)) (Or (Not z) (Not w)) =  x == z && y == w
demorgan2 (Or (Not z) (Not w)) (Not (And x y)) =  x == z && y == w
demorgan2 _ _                                  =  False
demorgan     :: WFF -> WFF -> Bool
demorgan x y =  doRuleTwo x y demorgan2

--Conditional Laws
cond2                                   :: WFF -> WFF -> Bool
cond2 (Cond x y) (Or (Not z) w)         =  x == z && y == w
cond2 (Or (Not z) w) (Cond x y)         =  x == z && y == w
cond2 (Cond x y) (Cond (Not z) (Not w)) =  x == w && y == z
cond2 (Cond (Not z) (Not w)) (Cond x y) =  x == w && y == z
cond2 (Cond x y) (Not (And z (Not w)))  =  x == z && y == w
cond2 (Not (And z (Not w))) (Cond x y)  =  x == z && y == w
cond2 _ _                               =  False
cond     :: WFF -> WFF -> Bool
cond x y =  doRuleTwo x y cond2

--Biconditional Laws
bicond2                                                   :: WFF -> WFF -> Bool
bicond2 (Bicond x y) (And (Cond z w) (Cond p q))          =  x == z && x == q &&
                                                             y == w && y == p
bicond2 (And (Cond z w) (Cond p q)) (Bicond x y)          =  x == z && x == q &&
                                                             y == w && y == p
bicond2 (Bicond x y) (Or (And (Not z) (Not w)) (And p q)) =  x == z && x == p &&
                                                             y == w && y == q
bicond2 (Or (And (Not z) (Not w)) (And p q)) (Bicond x y) =  x == z && x == p &&
                                                             y == w && y == q
bicond2 _ _                                               =  False
bicond     :: WFF -> WFF -> Bool
bicond x y =  doRuleTwo x y bicond2

--Modus Ponens
mp                :: WFF -> WFF -> WFF -> Bool
mp (Cond x y) z w =  x == z && y == w
mp _ _ _          =  False

--Modus Tollens
mt                            :: WFF -> WFF -> WFF -> Bool
mt (Cond x y) (Not z) (Not w) =  y == z && x == w
mt _ _ _                      =  False

--Hypothetical Syllogism
hs                                  :: WFF -> WFF -> WFF -> Bool
hs (Cond x y) (Cond z w) (Cond p q) =  y == z && x == p && w == q
hs _ _ _                            =  False

--Disjunctive Syllogism
ds                    :: WFF -> WFF -> WFF -> Bool
ds (Or x y) (Not z) w =  x == z && y == w
ds _ _ _              =  False

--Conjunction
conj               :: WFF -> WFF -> WFF -> Bool
conj x y (And z w) =  x == z && y == w
conj _ _ _         =  False

--Simplification
simp             :: WFF -> WFF -> Bool
simp (And x _) y =  x == y

-- *Addition
add            :: WFF -> WFF -> Bool
add x (Or y _) =  x == y

--Identity
ident2             :: WFF -> WFF -> Bool
ident2 (Or x F) y  =  x == y
ident2 y (Or x F)  =  x == y
ident2 (And x T) y =  x == y
ident2 y (And x T) =  x == y
ident2 _ _         =  False
ident     :: WFF -> WFF -> Bool
ident x y =  doRuleTwo x y ident2

--Distributivity
distrib2                                           :: WFF -> WFF -> Bool
distrib2 (Or p (And q r)) (And (Or x y) (Or z w))  =  p == x && p == z &&
                                                      q == y && r == w
distrib2 (And (Or x y) (Or z w)) (Or p (And q r))  =  p == x && p == z &&
                                                      q == y && r == w
distrib2 (And p (Or q r)) (Or (And x y) (And z w)) =  p == x && p == z &&
                                                      q == y && r == w
distrib2 (Or (And x y) (And z w)) (And p (Or q r)) =  p == x && p == z &&
                                                      q == y && r == w
distrib2 _ _                                       =  False
distrib     :: WFF -> WFF -> Bool
distrib x y =  doRuleTwo x y distrib2

--Commutativity
commut2                     :: WFF -> WFF -> Bool
commut2 (Or x y) (Or z w)   =  x == w && y == z
commut2 (And x y) (And z w) =  x == w && y == z
commut2 _ _                 =  False
commut     :: WFF -> WFF -> Bool
commut x y =  doRuleTwo x y commut2

--Associativity
assoc2                                     :: WFF -> WFF -> Bool
assoc2 (Or (Or x y) z) (Or w (Or p q))     =  x == w && y == p && z == q
assoc2 (And (And x y) z) (And w (And p q)) =  x == w && y == p && z == q
assoc2 (Or x (Or y z)) (Or (Or w p) q)     =  x == w && y == p && z == q
assoc2 (And x (And y z)) (And (And w p) q) =  x == w && y == p && z == q
assoc2 _ _                                 = False
assoc     :: WFF -> WFF -> Bool
assoc x y =  doRuleTwo x y assoc2

--Repeat rule
rep     :: WFF -> WFF -> Bool
rep x y =  Nothing == (mydiff x y)

--Idempotency rule
idem2             :: WFF -> WFF -> Bool
idem2 (Or x y) z  =  x == y && x == z
idem2 x (Or y z)  =  x == y && x == z
idem2 (And x y) z =  x == y && x == z
idem2 x (And y z) =  x == y && x == z
idem2 _ _         = False
idem     :: WFF -> WFF -> Bool
idem x y =  doRuleTwo x y idem2

--mapping rule names to rules themselves
rulelist = fromList [
             ("rep",rep),
             ("idem",idem),
             ("commut",commut),
             ("distrib",distrib),
             ("ident",ident),
             ("assoc",assoc),
             ("add",add),
             ("simp",simp),
             ("bicond",bicond),
             ("cond",cond),
             ("demorgan",demorgan),
             ("double",double),
             ("comp",comp),
             ("dom",dom)
           ]

--looking up rules
getrule t = r
            where
            x = lookup t rulelist
            r = case x of
              Nothing -> error "illegal rule!"
              Just z -> z

--mapping rule names to rules with two arugments
birulelist = fromList [
               ("conj",conj),
               ("ds",ds),
               ("hs",hs),
               ("mt",mt),
               ("mp",mp)
             ]

--looking up birules
getbirule t = r
              where
              x = lookup t birulelist
              r = case x of
                Nothing -> error "illegal rule!"
                Just z -> z

--file is a sequence of lines
proofFile = endBy line (many1 eol)

--each line is a WFF and a rule
line = do l <- many (char '|')
          many (char '\t')
          f <- wff
          many1 (char '\t')
          r <- rule
          return (f,r,length l)

--parse rules
rule = try givenrule <|>
       try auxrule <|>
       try birulerule <|>
       try proofrulerule <|>
       rulerule
       <?> "error parsing rules"

--parse a rule with one argument
rulerule = do spaces
              rulename <- many1 letter
              oneOf " ,"
              spaces
              i <- many1 digit
              return (Rule (map toLower rulename) (read i::Int))

--parse a rule with two arguments
birulerule = do spaces
                rulename <- many1 letter
                oneOf " ,"
                spaces
                i <- many1 digit
                oneOf " ,"
                spaces
                j <- many1 digit
                return (Birule (map toLower rulename) (read i::Int) (read j::Int))

--parse a proof rule with two arguments
proofrulerule = do spaces
                   rulename <- many1 letter
                   oneOf " ,"
                   spaces
                   i <- many1 digit
                   char '-'
                   j <- many1 digit
                   return (Proofrule (map toLower rulename) (read i::Int) (read j::Int))

--aux rule
auxrule = do spaces
             string "aux"
             return Aux

--given rule
givenrule =  do spaces
                string "given"
                return Given

--all possible WFFs
wff = try simple <|>
      try andwff <|>
      try condwff <|>
      try bicondwff <|>
      try notwff <|>
      try orwff <?> "error parsing WFFs"

--negation
notwff = do spaces
            char 'n'
            spaces
            w <- wff
            return (Not w)

--biconditional
bicondwff = do char '('
               spaces
               w1 <- wff
               spaces
               string "<>"
               spaces
               w2 <- wff
               spaces
               char ')'
               return (Bicond w1 w2)

--disjunction
orwff = do char '('
           spaces
           w1 <- wff
           spaces
           char '!'
           spaces
           w2 <- wff
           spaces
           char ')'
           return (Or w1 w2)

--conjunction
andwff = do char '('
            spaces
            w1 <- wff
            spaces
            char '&'
            spaces
            w2 <- wff
            spaces
            char ')'
            return (And w1 w2)

--conditional
condwff = do char '('
             spaces
             w1 <- wff
             spaces
             char '>'
             spaces
             w2 <- wff
             spaces
             char ')'
             return (Cond w1 w2)

--simple WFFs
pwff = do char 'p'
          return (WFF P)
qwff = do char 'q'
          return (WFF Q)
rwff = do char 'r'
          return (WFF R)
swff = do char 's'
          return (WFF S)
uwff = do char 'u'
          return (WFF U)
vwff = do char 'v'
          return (WFF V)
twff = do char 'T'
          return T
fwff = do char 'F'
          return F

--put simple WFFs together
simple =  try pwff <|>
          try qwff <|>
          try rwff <|>
          try swff <|>
          try uwff <|>
          try vwff <|>
          try twff <|>
          try fwff <?>
          "error parsing simple WFF"

--eol for mac/windows/linux
eol =   try (string "\n\r")
    <|> try (string "\r\n")
    <|> string "\n"
    <|> string "\r"
    <?> "missing end of line"

--parsing command
parseProof       :: String -> Either ParseError [(WFF,Rule,Int)]
parseProof input =  parse proofFile "(unknown)" input

--check an individual rule
checkRule           :: [(WFF,Rule,Int)] -> String -> Int ->
                       WFF -> Int -> IO ()
checkRule p r i w l =  do let rule = getrule r
                          let prevlevel = mythird (p!!i)
                          let res = (prevlevel <= l) &&
                                    (rule (myfst (p!!i)) w)
                          putStrLn ("\t" ++ (show res))

--check a rule with two arguments
checkBirule             :: [(WFF,Rule,Int)] -> String -> Int -> 
                           Int -> WFF -> Int -> IO ()
checkBirule p r i j w l =  do let rule = getbirule r
                              let prevlevone = mythird (p!!i)
                              let prevlevtwo = mythird (p!!j)
                              let res = (prevlevone <= l) &&
                                        (prevlevtwo <= l) &&
                                        (rule (myfst (p!!i)) (myfst (p!!j)) w)
                              putStrLn ("\t" ++ (show res))

--indirect proof
ip                           :: WFF -> WFF -> WFF -> Bool
ip x (And y (Not z)) (Not w) =  x == w && y == z 
ip _ _ _                     =  False

--conditional proof
cp                :: WFF -> WFF -> WFF -> Bool
cp x y (Cond z w) =  x == z && y == w
cp _ _ _          =  False

--indirect and conditional proof
checkProofrule           :: [(WFF,Rule,Int)] -> String -> Int ->
                            Int -> Int -> IO ()
checkProofrule p r j k i =  putStrLn ("\t" ++ (show res))
                            where
                            levelcheck = all (>(mythird (p!!i))) $
                                         map (\x -> mythird (p!!x)) [j..k]
                            wff1 = myfst (p!!j)
                            wff2 = myfst (p!!k)
                            wff3 = myfst (p!!i)
                            tmpres = case r of
                                       "ip" -> ip wff1 wff2 wff3
                                       "cp" -> cp wff1 wff2 wff3
                            res = tmpres && levelcheck

--check a line
doLines       :: [(WFF,Rule,Int)] -> Int -> Int -> IO ()
doLines p m i =  do let rule = mysnd (p!!i)
                    let wff = myfst (p!!i)
                    let level = mythird (p!!i)
                    let wlength = length $ show wff
                    let padding = take (m-wlength) $ repeat ' '
                    putStrLn ((show wff) ++ padding ++ "\t" ++ (show rule))
                    case rule of
                      Given -> putStrLn ("\t" ++ (show (level == 0)))
                      Aux -> putStrLn ("\t" ++ (show (level > 0)))
                      Rule r j -> checkRule p r (j-1) wff level
                      Birule r j k -> checkBirule p r (j-1) (k-1) wff level
                      Proofrule r j k -> checkProofrule p r (j-1) (k-1) i

--add padding to width of WFF
checkpad   :: [(WFF,Rule,Int)] -> Int
checkpad p =  maximum $ map length $ map show $ map myfst p

--check a whole proof
check   :: [(WFF,Rule,Int)] -> IO ()
check p =  do let l = length p
              let m = checkpad p
              let r = [0..(l-1)]
              putStrLn "Checking...."
              mapM_ (doLines p m) r

--find difference between two WFFs
mydiff                           :: WFF -> WFF -> Maybe (WFF,WFF)
mydiff (WFF x) (WFF y)           =  if x == y
   then Nothing
   else Just (WFF x,WFF y)
mydiff (Not x) (Not y)           =  mydiff x y
mydiff (And x y) (And z w)       =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  Just (And x y,And z w)
mydiff (Or x y) (Or z w)         =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  Just (Or x y,Or z w)
mydiff (Cond x y) (Cond z w)     =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  Just (Cond x y,Cond z w)
mydiff (Bicond x y) (Bicond z w) =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  Just (Bicond x y,Bicond z w)
mydiff T T = Nothing
mydiff F F = Nothing
mydiff x y =  Just (x,y)

--extract 1st element of a triple
myfst         :: (a,b,c) -> a
myfst (x,_,_) =  x

--extract 2nd element of a triple
mysnd         :: (a,b,c) -> b
mysnd (_,x,_) =  x

--extract 3rd element of a triple
mythird         :: (a,b,c) -> c
mythird (_,_,x) =  x

--usage: runhaskell MathProof.hs proof.txt
main :: IO ()
main =  do as <- getArgs
           x <- readFile (as!!0)
           let y = parseProof x
           case y of
              Left w -> putStrLn ("error: " ++ (show w))
              Right z -> check z


