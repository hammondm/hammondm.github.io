module MathStrings

where



myPi :: Double
myPi =  3.14159265358979


myName :: String
myName =  "Ishmael"


myFavoriteLetter :: Char
myFavoriteLetter =  'x'


addTwo   :: Double -> Double
addTwo x =  x + 2


meanTwo     :: Double -> Double -> Double
meanTwo x y =  (x + y) / 2


fixLetter   :: Char -> Char
fixLetter a =  if a == 'x' then 'X' else a


myNull    :: (Eq a) => [a] -> Bool
myNull xs =  xs == []


myLength        :: [a] -> Int
myLength []     =  0
myLength (x:xs) =  1 + myLength xs


myListEqual               :: (Eq a) => [a] -> [a] -> Bool
myListEqual [] []         =  True
myListEqual [] _          =  False
myListEqual _ []          =  False
myListEqual (x:xs) (y:ys) =  x == y && myListEqual xs ys


myPrefix               :: (Eq a) => [a] -> [a] -> Bool
myPrefix [] _          =  True
myPrefix _ []          =  False
myPrefix (x:xs) (y:ys) =  x == y && myPrefix xs ys


mySubstring           :: (Eq a) => [a] -> [a] -> Bool
mySubstring [] _      =  True
mySubstring _ []      =  False
mySubstring xs (y:ys) =  myPrefix xs (y:ys) || mySubstring xs ys


mySuffix           :: (Eq a) => [a] -> [a] -> Bool
mySuffix [] _      =  True
mySuffix _ []      =  False
mySuffix xs (y:ys) =  myListEqual xs (y:ys) || mySuffix xs ys 


myId   :: a -> a
myId x =  x


myMap          :: (a -> b) -> [a] -> [b]
myMap _ []     =  []
myMap f (x:xs) =  (f x):myMap f xs


myRev        :: [a] -> [a]
myRev []     =  []
myRev (x:xs) =  (myRev xs) ++ [x]


