{- cabal:
build-depends:
  base,
  containers,
  parsec
-}
module Main where

import Data.List (intercalate)
import Text.ParserCombinators.Parsec
import qualified Data.Map as M
import Data.Char (toUpper,toLower)
import System.Environment (getArgs)

--a variable
data Var = Var Char deriving Eq

instance Show Var where
   show (Var x)   = [toLower x]

--a constant
data Const = Const Char deriving (Ord,Eq)

instance Show Const where
   show (Const x) = [toLower x]

--a term is either a variable or a constant
data Term = Vterm Var | Cterm Const deriving Eq

instance Show Term where
   show (Vterm v) = show v
   show (Cterm c) = show c

--a function
data Func = Func Char deriving (Ord,Eq)

instance Show Func where
   show (Func f) = [toUpper f]

--a quantifier
data Quant = All Var | Some Var deriving (Eq,Show)

--all the WFFs
data WFF = Simple Func [Term] |
           And WFF WFF |
           Or WFF WFF |
           Cond WFF WFF |
           Bicond WFF WFF |
           Not WFF |
           Q Quant WFF deriving Eq

instance Show WFF where
   show (Simple f ts)  = (show f) ++ "(" ++
                         (intercalate "," (map show ts)) ++ ")"
   show (And x y)      = "(" ++ (show x) ++ " ∧ " ++ (show y) ++ ")"
   show (Or x y)       = "(" ++ (show x) ++ " ∨ " ++ (show y) ++ ")"
   show (Cond x y)     = "(" ++ (show x) ++ " → " ++ (show y) ++ ")"
   show (Bicond x y)   = "(" ++ (show x) ++ " ↔ " ++ (show y) ++ ")"
   show (Not x)        = "¬" ++ (show x)
   show (Q (All v) x)  = "(∀" ++ (show v) ++ ")" ++ (show x)
   show (Q (Some v) x) = "(Ǝ" ++ (show v) ++ ")" ++ (show x)

--an individual in a world
data Ind = Ind String deriving (Ord,Eq)

instance Show Ind where
   show (Ind s) = s

--a model is a set of individuals and functions
--over tuples of individuals
data Model = Model (M.Map Const Ind) (M.Map Func [[Ind]]) deriving Show

--extract a constant from a term
getConstant           :: Term -> Const
getConstant (Cterm x) =  x

--check if a WFF with only constants is true wrt/ a model
check                             :: WFF -> Model -> Bool
check (And x y) m                 =  (check x m) && (check y m)
check (Or x y) m                  =  (check x m) || (check y m)
check (Not x) m                   =  not (check x m)
check (Cond x y) m                =  (not (check x m)) || (check y m)
check (Bicond x y) m              =  (check (Cond x y) m) && (check (Cond y x) m)
check (Simple f ts) (Model cs fs) =  elem indlist funclist
                                       where
                                       indlist = map (cs M.!) cons
                                       cons = map getConstant ts
                                       funclist = fs M.! f

--get constants from a model
getModelConstants              :: Model -> [Const]
getModelConstants (Model cs _) =  M.keys cs

--check if a term is a variable
filterVar (Vterm x) =  True
filterVar _         =  False

--convert a term to a variable
term2Var           :: Term -> Var
term2Var (Vterm v) =  v

--substitute one term for another in a WFF
termsub                   :: Term -> WFF -> Term -> WFF
termsub a (Simple f ts) b =  Simple f qs
                             where
                              qs = fix ts
                              fix []                 = []
                              fix (x:xs) | x == a    = b:fix xs
                              fix (x:xs) | otherwise = x:fix xs
termsub a (And x y) b     =  And (termsub a x b) (termsub a y b)
termsub a (Or x y) b      =  Or (termsub a x b) (termsub a y b)
termsub a (Cond x y) b    =  Cond (termsub a x b) (termsub a y b)
termsub a (Bicond x y) b  =  Bicond (termsub a x b) (termsub a y b)
termsub a (Not x) b       =  Not (termsub a x b)

--join a sequence of WFFs as a conjunction, disjunction, etc
join          :: (WFF -> WFF -> WFF) -> [WFF] -> WFF
join c (z:zs) =  foldr (\x y -> c x y) z zs

--get all variables in a WFF
getVars               :: WFF -> [Term]
getVars (Simple _ ts) =  filter filterVar ts
getVars (And x y)     =  (getVars x) ++ (getVars y)
getVars (Or x y)      =  (getVars x) ++ (getVars y)
getVars (Cond x y)    =  (getVars x) ++ (getVars y)
getVars (Bicond x y)  =  (getVars x) ++ (getVars y)
getVars (Not x)       =  (getVars x)

--remove quantifiers by converting all to and, and some to or
remQ                   :: WFF -> [Const] -> WFF
remQ (Simple f ts) _   =  (Simple f ts)
remQ (And x y) cs      =  And (remQ x cs) (remQ y cs)
remQ (Or x y) cs       =  Or (remQ x cs) (remQ y cs)
remQ (Cond x y) cs     =  Cond (remQ x cs) (remQ y cs)
remQ (Bicond x y) cs   =  Bicond (remQ x cs) (remQ y cs)
remQ (Not x) cs        =  Not (remQ x cs)
remQ (Q (All v) x) cs  =  if elem v vars
                            then res
                            else remQ x cs
                            where
                              y = remQ x cs
                              vars = map term2Var $ getVars y
                              vt = Vterm v
                              cts = map (\x -> Cterm x) cs
                              subs = map (termsub vt y) cts
                              res = join And subs
remQ (Q (Some v) x) cs  =  if elem v vars
                             then res
                             else remQ x cs
                             where
                               y = remQ x cs
                               vars = map term2Var $ getVars y
                               vt = Vterm v
                               cts = map (\x -> Cterm x) cs
                               subs = map (termsub vt y) cts
                               res = join Or subs

--end of line
eol =   try (string "\n\r")
    <|> try (string "\r\n")
    <|> string "\n"
    <|> string "\r"
    <?> "missing end of line"

--constants
cline = do many1 (char '\t')
           x <- noneOf "\t"
           many1 (char '\t')
           y <- many (noneOf "\n\r")
           return (Const x,Ind y)

--function arguments
funcargs = do char '['
              x <- sepBy (many (noneOf ",]")) (char ',')
              char ']'
              many (char ',')
              return (map Ind x)

--functions
fline = do many1 (char '\t')
           x <- noneOf "\t"
           many1 (char '\t')
           y <- many1 funcargs
           return (Func x,y)

--variables
vline = do many1 (char '\t')
           x <- noneOf "\n\r"
           return (Var x)

--wffs
wline = do many1 (char '\t')
           x <- many (noneOf "\n\r")
           return x

--parse a model file
modelFile = do string "constants"
               eol
               a <- endBy cline (many1 eol)
               string "functions"
               eol
               b <- endBy fline (many1 eol)
               string "variables"
               eol
               c <- endBy vline (many1 eol)
               string "wffs"
               eol
               d <- endBy wline (many1 eol)
               return ((M.fromList a),(M.fromList b),c,d)

--check if a WFF is true or not
checkwff w m = do putStrLn $ show w
                  putStrLn $ show (check (remQ w (getModelConstants m)) m)

--parse a WFF using model info
doWFF ls m w = do let x = parse wff "wff" w
                  case x of
                     Left a -> putStrLn ("WFF error" ++ (show a))
                     Right b -> checkwff b m
                  where
                     wff = try simplewff <|>
                           try allwff <|>
                           try somewff <|>
                           try andwff <|>
                           try orwff <|>
                           try condwff <|>
                           try bicondwff <|>
                           notwff <?> "specific wff error"
                     simplewff = do f <- oneOf (ls!!1)
                                    let ff = Func (toLower f)
                                    char '('
                                    ts <- sepBy terms (char ',')
                                    char ')'
                                    return (Simple ff ts)
                     terms = try cterm <|> vterm <?> "term error"
                     cterm = do c <- oneOf (ls!!0)
                                return (Cterm (Const c))
                     vterm = do v <- oneOf (ls!!2)
                                return (Vterm (Var v))
                     allwff = do string "(A"
                                 v <- oneOf (ls!!2)
                                 char ')'
                                 w <- wff
                                 return (Q (All (Var v)) w)
                     somewff = do string "(E"
                                  v <- oneOf (ls!!2)
                                  char ')'
                                  w <- wff
                                  return (Q (Some (Var v)) w)
                     andwff = do char '('
                                 x <- wff
                                 string " & "
                                 y <- wff
                                 char ')'
                                 return (And x y)
                     orwff = do char '('
                                x <- wff
                                string " ! "
                                y <- wff
                                char ')'
                                return (Or x y)
                     condwff = do char '('
                                  x <- wff
                                  string " > "
                                  y <- wff
                                  char ')'
                                  return (Cond x y)
                     bicondwff = do char '('
                                    x <- wff
                                    string " <> "
                                    y <- wff
                                    char ')'
                                    return (Bicond x y)
                     notwff = do char 'n'
                                 spaces
                                 x <- wff
                                 return (Not x)

--extract letters from functions and terms
getConstantLetter (Const x) = x
getFunctionLetter (Func x) = x
getVariableLetter (Var x) = x

--do all three
getLetters is fs vs = [cl,fl,vl]
                      where
                        cl = map getConstantLetter (M.keys is)
                        fl = map (toUpper . getFunctionLetter) (M.keys fs)
                        vl = map getVariableLetter vs

--make model, get letters, parse and check WFFs
doModel (is,fs,vs,ws) = do let m = Model is fs
                           putStrLn ("model: " ++ (show m))
                           let ls = getLetters is fs vs
                           putStrLn ""
                           mapM_ (doWFF ls m) ws

--run a test
main :: IO ()
main =  do as <- getArgs
           x <- readFile (as!!0)
           let y = parse modelFile "modelfile" x
           case y of
              Left w -> putStrLn ("error: " ++ (show w))
              Right z -> doModel z

