{- cabal:
build-depends:
  base,
  parsec
-}
module Main where

import Text.ParserCombinators.Parsec
import Data.List (intercalate,nub)
import System.Environment (getArgs)

--redefine for other variables
variables :: [Char]
variables =  "xyz"

--redefine for other constants
constants :: [Char]
constants =  "abcdev"

--redefine for other functions
functions :: [Char]
functions =  "FGHST"

--DATA TYPES FOR WFFS

data Function = Fnc Char deriving Eq

instance Show Function where
   show (Fnc f) = [f]

data Constant = C Char deriving Eq

instance Show Constant where
   show (C c) = [c]

data Variable = V Char deriving Eq

instance Show Variable where
   show (V c) = [c]

data Term = Ct Constant | Vt Variable deriving Eq

instance Show Term where
   show (Ct c) = show c
   show (Vt v) = show v

data Wff = W Function [Term] |
           T |
           F |
           Not Wff |
           And Wff Wff |
           Or Wff Wff |
           If Wff Wff |
           Iff Wff Wff |
           All Variable Wff |
           Some Variable Wff deriving Eq

--join terms with commas as a string
commas    :: [Term] -> String
commas ts =  intercalate "," $ map show ts

instance Show Wff where
   show (W f ts)   = (show f) ++ "(" ++ (commas ts) ++ ")"
   show (Not x)    = "¬" ++ (show x)
   show (And x y)  = "(" ++ (show x) ++ " ∧ " ++ (show y) ++ ")"
   show (Or x y)   = "(" ++ (show x) ++ " ∨ " ++ (show y) ++ ")"
   show (If x y)   = "(" ++ (show x) ++ " → " ++ (show y) ++ ")"
   show (Iff x y)  = "(" ++ (show x) ++ " ↔ " ++ (show y) ++ ")"
   show (All v x)  = "(∀" ++ (show v) ++ ")" ++ (show x)
   show (Some v x) = "(Ǝ" ++ (show v) ++ ")" ++ (show x)
   show T          = "T"
   show F          = "F"

--PARSING

--end of line
eol = try (string "\n\r") <|>
      try (string "\r\n") <|>
      string "\n" <|>
      string "\r" <?>
      "missing end of line"

--convert letter to term
makeTerm                      :: Char -> Term
makeTerm x | elem x constants =  Ct (C x)
           | elem x variables =  Vt (V x)
           | otherwise        =  error "not a variable or a constant"

--parse terms
terms = do ts <- sepBy (noneOf ",)") (char ',')
           return (map makeTerm ts)

--all the wffs

simplewff = do f <- oneOf functions
               char '('
               ts <- terms
               char ')'
               return (W (Fnc f) ts)

andwff = do char '('
            x <- wff
            spaces
            char '&'
            spaces
            y <- wff
            char ')'
            return (And x y)

orwff = do char '('
           x <- wff
           spaces
           char '!'
           spaces
           y <- wff
           char ')'
           return (Or x y)

allwff = do string "(A"
            spaces
            v <- oneOf variables
            char ')'
            w <- wff
            return (All (V v) w)

ifwff = do char '('
           x <- wff
           spaces
           char '>'
           spaces
           y <- wff
           char ')'
           return (If x y)

iffwff = do char '('
            x <- wff
            spaces
            string "<>"
            spaces
            y <- wff
            char ')'
            return (Iff x y)

notwff = do char 'n'
            spaces
            w <- wff
            return (Not w)

somewff = do string "(E"
             spaces
             v <- oneOf variables
             char ')'
             w <- wff
             return (Some (V v) w)

twff = do char 'T'
          return T

fwff = do char 'F'
          return F

--parse a wff
wff = try simplewff <|>
      try andwff <|>
      try orwff <|>
      try allwff <|>
      try somewff <|>
      try ifwff <|>
      try iffwff <|>
      try twff <|>
      try fwff <|>
      notwff

--parse a rule
rule = try givenparserule <|> try auxparserule <|> numrule

auxparserule = do string "aux"
                  return ("aux",[])

givenparserule = do string "given"
                    return ("given",[])

numrule = do r <- many (noneOf " ")
             many1 (oneOf " ,")
             ns <- sepBy (many1 digit) (many1 (oneOf ", "))
             return (r,map (\x -> (read x::Int)) ns)

levels = do ls <- many (char '|')
            return (length ls)

--parse a line
line = do ls <- levels
          many (char '\t')
          w <- wff
          many1 (char '\t')
          r <- rule
          return (w,r,ls) 

--parse a proof file
proofFile = endBy line (many1 eol)

--CHECK PROOF

--first element of a triple
myfst         :: (a,b,c) -> a
myfst (x,_,_) =  x

--second element of a triple
mysnd         :: (a,b,c) -> b
mysnd (_,x,_) =  x

--third element of a triple
mythrd         :: (a,b,c) -> c
mythrd (_,_,x) =  x

--get wff +1 from rule indices
getTwo     :: [(Wff,(String,[Int]),Int)] -> Int -> [Wff]
getTwo p n =  [w1,w2]
                where
                   theline = p!!n
                   [i] = snd (mysnd theline)
                   w1 = myfst (p!!(i-1))
                   w2 = myfst theline

--get wff +2 from rule indices
getThree     :: [(Wff,(String,[Int]),Int)] -> Int -> [Wff]
getThree p n =  [w1,w2,w3]
                where
                   theline = p!!n
                   [i,j] = snd (mysnd theline)
                   w1 = myfst (p!!(i-1))
                   w2 = myfst (p!!(j-1))
                   w3 = myfst theline

checkLevels p n = res
                    where
                      thisline = p!!n
                      thislevel = mythrd thisline
                      previndices = map (+(-1)) (snd (mysnd thisline))
                      prevlevels = map (\x -> mythrd (p!!x)) previndices
                      res = if (length prevlevels) == 0
                               then False
                               else (all (<= thislevel) prevlevels)

--repeat rule (rep)
reprule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
reprule p n =  res
               where
                  [w1,w2] = getTwo p n
                  lres = checkLevels p n
                  res = lres && checkreprule w1 w2
                  checkreprule x y = x == y

--check if something is a constant term
isConstant        :: Term -> Bool
isConstant (Ct _) =  True
isConstant _      =  False

--confirm that a constant corresponds to all instances of a variable
uivar             :: Wff -> Wff -> Bool
uivar (All v x) y =  (length reps == 1) && isConstant (head reps)
                     where
                        reps = nub $ getreps (Vt v) x y

--get constants that correspond to some variable
getreps                             :: Term -> Wff -> Wff -> [Term]
getreps _ (W _ []) (W _ [])         =  []
getreps _ T T                       =  []
getreps _ F F                       =  []
getreps _ (W _ [_]) (W _ [])        =  error "different number of arguments"
getreps _ (W _ []) (W _ [_])        =  error "different number of arguments"
getreps v (W f (t:ts)) (W g (c:cs)) =  if t == v && c /= v
                                       then c:getreps v (W f ts) (W g cs)
                                       else getreps v (W f ts) (W g cs)
getreps v (If x y) (If z w)         =  (getreps v x z) ++ (getreps v y w)
getreps v (Iff x y) (Iff z w)       =  (getreps v x z) ++ (getreps v y w)
getreps v (And x y) (And z w)       =  (getreps v x z) ++ (getreps v y w)
getreps v (Or x y) (Or z w)         =  (getreps v x z) ++ (getreps v y w)
getreps v (Not x) (Not y)           =  getreps v x y
getreps v (Some x y) (Some z w)     =  if v == (Vt x) || v == (Vt z)
                                         then []
                                         else getreps v y w
getreps v (All x y) (All z w)       =  if v == (Vt x) || v == (Vt z)
                                         then []
                                         else getreps v y w

--base rule for universal instantiation (ui)
uirule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
uirule p n =  res
              where
                [w1,w2] = getTwo p n
                lres = checkLevels p n
                res = lres && uivar w1 w2

--modus ponens (mp)
mprule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
mprule p n =  res
              where
               [w1,w2,w3] = getThree p n
               lres = checkLevels p n
               res = lres && checkmprule w1 w2 w3
               checkmprule (If x y) z w = x == z && y == w
               checkmprule _ _ _        = False

--hypothetical syllogism (hs)
hsrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
hsrule p n =  res
              where
               [w1,w2,w3] = getThree p n
               lres = checkLevels p n
               res = lres && checkhsrule w1 w2 w3
               checkhsrule (If x y) (If z w) (If q r) = x == q && y == z && w == r
               checkhsrule _ _ _                      = False

--substitute a variable for v-constant for universal generalization
ugsub             :: Term -> Wff -> Wff
ugsub v (W f ts)  =  W f xs
                     where
                       vc = Ct (C 'v')
                       xs = termsub v ts
                       termsub _ []     = []
                       termsub v (a:as) = if a == vc
                                          then v:termsub v as
                                          else a:termsub v as
ugsub v (Not w)   =  (Not (ugsub v w))
ugsub v (If x y)  =  (If (ugsub v x) (ugsub v y))
ugsub v (And x y) =  (And (ugsub v x) (ugsub v y))
ugsub v (Or x y)  =  (Or (ugsub v x) (ugsub v y))
ugsub v (Iff x y) =  (Iff (ugsub v x) (ugsub v y))
ugsub _ T         =  T
ugsub _ F         =  F

--universal generalization (ug)
ugrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
ugrule p n =  res
              where
               [w1,w2] = getTwo p n
               lres = checkLevels p n
               res = lres && checkugrule w1 w2
               checkugrule x (All v y) = res
                                         where
                                          vt = Vt v
                                          z = ugsub vt x
                                          res = z == y
               checkugrule _ _         = False

--modus tollens (mt)
mtrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
mtrule p n =  res
              where
               [w1,w2,w3] = getThree p n
               lres = checkLevels p n
               res = lres && checkmtrule w1 w2 w3
               checkmtrule (If x y) (Not z) (Not w) = z == y && x == w
               checkmtrule _ _ _                    = False

--get all constants from a wff
getCTerms            :: Wff -> [Term]
getCTerms (W _ ts)   =  filter isConstant ts
getCTerms (And x y)  =  (getCTerms x) ++ (getCTerms y)
getCTerms (Or x y)   =  (getCTerms x) ++ (getCTerms y)
getCTerms (If x y)   =  (getCTerms x) ++ (getCTerms y)
getCTerms (Iff x y)  =  (getCTerms x) ++ (getCTerms y)
getCTerms (All _ x)  =  getCTerms x
getCTerms (Some _ x) =  getCTerms x
getCTerms (Not x)    =  getCTerms x
getCTerms T          =  []
getCTerms F          =  []

--get all constant terms from a proof line
getConstants     :: [(Wff,(String,[Int]),Int)] -> Int -> [Term]
getConstants p n =  res
                    where
                      w = myfst (p!!n)
                      res = getCTerms w

--existential instantiation (ei)
eirule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
eirule p n =  res
              where
               [w1,w2] = getTwo p n
               cs = nub $ concat $ map (getConstants p) [0..(n-1)]
               lres = checkLevels p n
               res = lres && checkeirule w1 w2 cs
               checkeirule (Some v x) y cs = res
                                             where
                                                cons = nub $ getreps (Vt v) x y
                                                res = (length cons) == 1 &&
                                                      not (elem (cons!!0) cs)
               checkeirule _ _ _           = False

--simplification (simp)
simprule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
simprule p n =  res
                where
                  [w1,w2] = getTwo p n
                  lres = checkLevels p n
                  res = lres && checksimprule w1 w2
                  checksimprule (And x _) z = x == z
                  checksimprule _ _         = False

--get variable from quantified wff
getVar            :: Wff -> Variable
getVar (Some v _) =  v
getVar (All v _)  =  v

--get base wff from existential wff
stripSome            :: Wff -> Wff
stripSome (Some _ x) =  x

--existential generalization (eg)
egrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
egrule p n =  res
                where
                  [w1,w2] = getTwo p n
                  v = getVar w2
                  vt = Vt v
                  w2w = stripSome w2
                  lres = checkLevels p n
                  res = lres && length (nub (checkmatch w1 w2w vt)) == 1
                  checkmatch (W _ xs) (W _ ys) vx = getMatches xs ys vx
                  checkmatch (Not x) (Not y) vx = checkmatch x y vx
                  checkmatch (And x y) (And z w) vx = (checkmatch x z vx) ++
                                                      (checkmatch y w vx)
                  checkmatch (Or x y) (Or z w) vx = (checkmatch x z vx) ++
                                                    (checkmatch y w vx)
                  checkmatch (If x y) (If z w) vx = (checkmatch x z vx) ++
                                                    (checkmatch y w vx)
                  checkmatch (Iff x y) (Iff z w) vx = (checkmatch x z vx) ++
                                                      (checkmatch y w vx)
                  checkmatch (Some x y) (Some z w) vx = if (Vt x) == vx
                                                        then []
                                                        else checkmatch y w vx
                  checkmatch _ _ _ = []
                  getMatches [] [] _ = []
                  getMatches [] _ _  = error "number of terms doesn't match"
                  getMatches _ [] _ = error "number of terms doesn't match"
                  getMatches (x:xs) (y:ys) vz = if y == vz
                                                then x:getMatches xs ys vz
                                                else getMatches xs ys vz

--find where two wffs differ
mydiff                           :: Wff -> Wff -> [Wff]
mydiff (W x y) (W z w)           =  if (W x y) == (W z w)
   then error "no difference"
   else [W x y,W z w]
mydiff (Not x) (Not y)           =  mydiff x y
mydiff (And x y) (And z w)       =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  [And x y,And z w]
mydiff (Or x y) (Or z w)         =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  [Or x y,Or z w]
mydiff (If x y) (If z w)         =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  [If x y,If z w]
mydiff (Iff x y) (Iff z w)       =  if x == z
   then mydiff y w
   else if y == w then mydiff x z
                  else  [Iff x y,Iff z w]
mydiff T T                       = error "no difference"
mydiff F F                       = error "no difference"
mydiff x y                       = [x,y]

--commutativity (commut)
commutrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
commutrule p n =  res
                  where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkcommutrule w1d w2d
                     checkcommutrule (And x y) (And z w) = x == w && y == z

--conjunction (conj)
conjrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
conjrule p n =  res
                  where
                     [w1,w2,w3] = getThree p n
                     lres = checkLevels p n
                     res = lres && checkconjrule w1 w2 w3
                     checkconjrule x y (And z w) = x == z && y == w
                     checkconjrule _ _ _         = False

--idempotency (idem)
idemrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
idemrule p n =  res
                  where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkidemrule w1d w2d
                     checkidemrule (And x y) z = x == y && x == z
                     checkidemrule (Or x y) z  = z ==y && x == z
                     checkidemrule x (And y z) = x == y && x == z
                     checkidemrule x (Or y z)  = x == y && x == z
                     checkidemrule _ _         = False

--distributivity (distrib)
distribrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
distribrule p n =  res
                     where
                       [w1,w2] = getTwo p n
                       [w1d,w2d] = mydiff w1 w2
                       lres = checkLevels p n
                       res = lres && checkdistribrule w1d w2d
                       checkdistribrule (Or x (And y z)) (And (Or w p) (Or q r)) =
                          x == w && x == q && y == p && z == r
                       checkdistribrule (And (Or w p) (Or q r)) (Or x (And y z)) =
                          x == w && x == q && y == p && z == r
                       checkdistribrule (And x (Or y z)) (Or (And w p) (And q r)) =
                          x == w && x == q && y == p && z == r
                       checkdistribrule (Or (And w p) (And q r)) (And x (Or y z)) =
                          x == w && x == q && y == p && z == r
                       checkdistribrule _ _ = False

--identity (ident)
identrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
identrule p n =  res
                  where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkidentrule w1d w2d
                     checkidentrule x (And y T) = x == y
                     checkidentrule x (Or y F)  = x == y
                     checkidentrule (And x T) y = x == y
                     checkidentrule (Or x F) y  = x == y
                     checkidentrule _ _         = False

--associativity (assoc)
assocrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
assocrule p n =  res
                  where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkassocrule w1d w2d
                     checkassocrule (Or (Or x y) z) (Or w (Or p q))     = x == w &&
                                                                          y == p &&
                                                                          z == q
                     checkassocrule (And (And x y) z) (And w (And p q)) = x == w &&
                                                                          y == p &&
                                                                          z == q
                     checkassocrule (Or x (Or y z)) (Or (Or w p) q)     = x == w &&
                                                                          y == p &&
                                                                          z == q
                     checkassocrule (And x (And y z)) (And (And w p) q) = x == w &&
                                                                          y == p &&
                                                                          z == q
                     checkassocrule _ _                                 = False

--addition (add)
addrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
addrule p n =  res
                  where
                     [w1,w2] = getTwo p n
                     lres = checkLevels p n
                     res = lres && checkaddrule w1 w2
                     checkaddrule x (Or y _) = x == y
                     checkaddrule _ _        = False

--biconditional (bicond)
bicondrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
bicondrule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkbicondrule w1d w2d
                     checkbicondrule (Iff x y) (And (If a b) (If c d)) = x == a &&
                                                                         x == d &&
                                                                         y == b &&
                                                                         y == c
                     checkbicondrule (And (If a b) (If c d)) (Iff x y) = x == a &&
                                                                         x == d &&
                                                                         y == b &&
                                                                         y == c
                     checkbicondrule (Iff x y)
                                     (Or (And (Not a) (Not b)) (And c d)) = x == a &&
                                                                            x == c &&
                                                                            y == b &&
                                                                            y == d
                     checkbicondrule (Or (And (Not a) (Not b)) (And c d))
                                     (Iff x y) = x == a && x == c && y == b && y == d
                     checkbicondrule _ _ = False

--conditional (cond)
condrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
condrule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkcondrule w1d w2d
                     checkcondrule (If x y) (Or (Not z) w) = x == z && y == w
                     checkcondrule (Or (Not z) w) (If x y) = x == z && y == w
                     checkcondrule (If x y) (If (Not z) (Not w)) = x == w && y == z
                     checkcondrule (If (Not z) (Not w)) (If x y) = x == w && y == z
                     checkcondrule (If x y) (Not (And z (Not w))) = x == z && y == w
                     checkcondrule _ _ = False

--demorgan (demorgan)
demorganrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
demorganrule p n =  res
                      where
                       [w1,w2] = getTwo p n
                       [w1d,w2d] = mydiff w1 w2
                       lres = checkLevels p n
                       res = lres && checkdemorganrule w1d w2d
                       checkdemorganrule (Not (Or x y))
                                         (And (Not z) (Not w)) = x == z && y == w
                       checkdemorganrule (And (Not z) (Not w))
                                         (Not (Or x y))        = x == z && y == w
                       checkdemorganrule (Not (And x y))
                                         (Or (Not z) (Not w))  = x == z && y == w
                       checkdemorganrule (Or (Not z) (Not w))
                                         (Not (And x y))       = x == z && y == w
                       checkdemorganrule _ _ = False

--double complement (double)
doublerule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
doublerule p n =  res
                    where
                       [w1,w2] = getTwo p n
                       [w1d,w2d] = mydiff w1 w2
                       lres = checkLevels p n
                       res = lres && checkdoublerule w1d w2d
                       checkdoublerule x (Not (Not y)) = x == y
                       checkdoublerule (Not (Not x)) y = x == y
                       checkdoublerule _ _ = False

--complement (comp)
comprule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
comprule p n =  res
                  where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkcomprule w1d w2d
                     checkcomprule (Or x (Not y)) T = x == y
                     checkcomprule T (Or x (Not y)) = x == y
                     checkcomprule (And x (Not y)) F = x == y
                     checkcomprule F (And x (Not y)) = x == y
                     checkcomprule _ _ = False

--domination (dom)
domrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
domrule p n =  res
                  where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkdomrule w1d w2d
                     checkdomrule (Or x F) y = x == y
                     checkdomrule y (Or x F) = x == y
                     checkdomrule (And x T) y = x == y
                     checkdomrule y (And x T) = x == y
                     checkdomrule _ _ = False

--disjunctive syllogism (ds)
dsrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
dsrule p n =  res
                  where
                     [w1,w2,w3] = getThree p n
                     lres = checkLevels p n
                     res = lres && checkdsrule w1 w2 w3
                     checkdsrule (Or x y) (Not z) w = x == z && y == w
                     checkdsrule _ _ _ = False

--given (given)
givenrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
givenrule p n =  res
                   where
                     thisLine = p!!n
                     thisLevel = mythrd thisLine
                     res = thisLevel == 0

--aux (aux)
auxrule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
auxrule p n =  res
                   where
                     thisLine = p!!n
                     thisLevel = mythrd thisLine
                     res = if n == 0
                        then thisLevel == 1
                        else subres
                          where
                            prevLine = p!!(n-1)
                            prevLevel = mythrd prevLine
                            subres = prevLevel == thisLevel - 1

--check if subproof levels are good
subproof     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
subproof p n = res
                 where
                    thisLine = p!!n
                    thisLevel = mythrd thisLine
                    previndices = map (+(-1)) (snd (mysnd thisLine))
                    [p1,p2] = map (\x -> mythrd (p!!x)) previndices
                    res = p1 == (thisLevel + 1) && p2 == (thisLevel + 1)

--conditional proof (cp)
cprule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
cprule p n =  res
                where
                  [w1,w2,w3] = getThree p n
                  lres = subproof p n
                  res = lres && checkcprule w1 w2 w3
                  checkcprule x y (If z w) = x == z && y == w
                  checkcprule _ _ _ = False

--indirect proof (ip)
iprule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
iprule p n =  res
                where
                  [w1,w2,w3] = getThree p n
                  lres = subproof p n
                  res = lres && checkiprule w1 w2 w3
                  checkiprule x (And y (Not z)) (Not w) = y == z && x == w
                  checkiprule _ _ _ = False 


--qde1 (qde1)
qde1rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qde1rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkqde1rule w1d w2d
                     checkqde1rule (Not (All v x))
                                   (Some q (Not y)) = x == y && v == q
                     checkqde1rule (Some q (Not y))
                                   (Not (All v x)) = x == y && v == q
                     checkqde1rule _ _ = False

--qde2 (qde2)
qde2rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qde2rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkqde2rule w1d w2d
                     checkqde2rule (All v (And x y))
                                   (And (All z w) (All p q)) = v == z && v == p &&
                                                               x == w && y == q
                     checkqde2rule (And (All z w) (All p q))
                                   (All v (And x y)) = v == z && v == p &&
                                                       x == w && y == q
                     checkqde2rule _ _ = False

--qde3 (qde3)
qde3rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qde3rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkqde3rule w1d w2d
                     checkqde3rule (Some x (Or y z))
                                   (Or (Some w p) (Some q r)) = x == w && w == q &&
                                                                y == p && z == r
                     checkqde3rule (Or (Some w p) (Some q r))
                                   (Some x (Or y z)) = x == w && w == q &&
                                                       y == p && z == r
                     checkqde3rule _ _ = False

--qdc4 (qdc4)
qdc4rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qdc4rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     lres = checkLevels p n
                     res = lres && checkqdc4rule w1 w2
                     checkqdc4rule (Or (All x y) (All z w))
                                   (All p (Or q r)) = x == z && x == p &&
                                                      y == q && w == r
                     checkqdc4 _ _ = False

--qdc5 (qdc5)
qdc5rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qdc5rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     lres = checkLevels p n
                     res = lres && checkqdc5rule w1 w2
                     checkqdc5rule (Some p (And q r))
                                   (And (Some x y) (Some z w)) = x == z && x == p &&
                                                                 y == q && w == r
                     checkqdc5 _ _ = False

--qse6 (qse6)
qse6rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qse6rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkqse6rule w1d w2d
                     checkqse6rule (All x (All y z))
                                   (All w (All p q)) = x == p && y == w && z == q
                     checkqse6rule _ _ = False

--qse7 (qse7)
qse7rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qse7rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     [w1d,w2d] = mydiff w1 w2
                     lres = checkLevels p n
                     res = lres && checkqse7rule w1d w2d
                     checkqse7rule (Some x (Some y z))
                                   (Some w (Some p q)) = x == p && y == w && z == q
                     checkqse7rule _ _ = False

--qsc8 (qsc8)
qsc8rule     :: [(Wff,(String,[Int]),Int)] -> Int -> Bool
qsc8rule p n =  res
                   where
                     [w1,w2] = getTwo p n
                     lres = checkLevels p n
                     res = lres && checkqsc8rule w1 w2
                     checkqsc8rule (Some x (All y z))
                                   (All p (Some q r)) = x == q && y == p && z == r
                     checkqsc8rule _ _ = False

--check a proof line
checkline     :: [(Wff,(String,[Int]),Int)] -> Int -> IO ()
checkline p n =  do putStrLn $ show (p!!n)
                    putStrLn ("\t" ++ (show res))
                    where
                      rule = mysnd (p!!n)
                      res = case (fst rule) of
                              "given" -> givenrule p n
                              "aux" -> auxrule p n
                              "ui" -> uirule p n
                              "mp" -> mprule p n
                              "rep" -> reprule p n
                              "hs" -> hsrule p n
                              "ug" -> ugrule p n
                              "mt" -> mtrule p n
                              "ei" -> eirule p n
                              "simp" -> simprule p n
                              "eg" -> egrule p n
                              "commut" -> commutrule p n
                              "conj" -> conjrule p n
                              "idem" -> idemrule p n
                              "distrib" -> distribrule p n
                              "ident" -> identrule p n
                              "assoc" -> assocrule p n
                              "add" -> addrule p n
                              "bicond" -> bicondrule p n
                              "cond" -> condrule p n
                              "demorgan" -> demorganrule p n
                              "double" -> doublerule p n
                              "comp" -> comprule p n
                              "dom" -> domrule p n
                              "ds" -> dsrule p n
                              "cp" -> cprule p n
                              "ip" -> iprule p n
                              "qde1" -> qde1rule p n
                              "qde2" -> qde2rule p n
                              "qde3" -> qde3rule p n
                              "qdc4" -> qdc4rule p n
                              "qdc5" -> qdc5rule p n
                              "qse6" -> qse6rule p n
                              "qse7" -> qse7rule p n
                              "qsc8" -> qsc8rule p n

main :: IO ()
main =  do as <- getArgs
           p <- readFile (as!!0)
           let y = parse proofFile "proofFile" p
           case y of
              Left w -> putStrLn ("error: " ++ (show w))
              Right z -> do let n = length z
                            mapM_ (checkline z) [0..(n-1)]
