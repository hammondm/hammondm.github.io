/*
average entropy calculations for some languages

runs with swi-prolog

uses wikipron data: https://github.com/CUNY-CL/wikipron
*/

%do counts
docounts(_,[]) :- !.
docounts(H,[C|Cs]) :-
   ht_update(H,C,O,N), !,
	N is O + 1,
   docounts(H,Cs).
docounts(H,[C|Cs]) :-
   ht_put_new(H,C,1),
   docounts(H,Cs).

%get all bigrams in a word
getbigrams([_],[]).
getbigrams([],[]).
getbigrams([A|[B|X]],[(A,B)|R]) :-
	getbigrams([B|X],R).

%line by line
dolines(_,_,[]) :- !.
dolines(U,B,[""|Ls]) :-
	!,
	dolines(U,B,Ls).
dolines(U,B,[L|Ls]) :-
	split_string(L,"\t","\t",[_,T]),
	split_string(T," "," ",Cs),
	%sandwich: #...#
	append(["#"|Cs],["#"],Fs),
	docounts(U,Fs),
	getbigrams(Fs,Bs),
	docounts(B,Bs),
	dolines(U,B,Ls).

getval(_-X,X).

getbigramvals(_,_,[],0) :- !.
getbigramvals(U,B,[(S1,S2)|Bgs],N) :-
	ht_get(U,S1,S1val),
	ht_get(B,(S1,S2),Bval),
	V is (Bval/S1val) * log(Bval/S1val)/log(2),
	getbigramvals(U,B,Bgs,M),
	N is M + V.

getentropy(_,_,[],0) :- !.
getentropy(U,B,[""|Ls],R) :-
	!,
	getentropy(U,B,Ls,R).
getentropy(U,B,[L|Ls],R) :-
	split_string(L,"\t","\t",[_,T]),
	split_string(T," "," ",Cs),
	%sandwich: #...#
	append(["#"|Cs],["#"],Fs),
	getbigrams(Fs,Bs),
	getbigramvals(U,B,Bs,Vs),
	getentropy(U,B,Ls,M),
	R is M + Vs.

%do each language
dolanguage(L) :-
	writeln(L),
	string_concat("iranian/",L,F),
	writeln(F),
	read_file_to_string(F,S,[]),
	split_string(S,"\n","\r ",Ls),
	ht_new(Uni),
	ht_new(Bi),
	dolines(Uni,Bi,Ls),
	getentropy(Uni,Bi,Ls,E),
	%unigram total
	ht_pairs(Uni,Ps),
	maplist(getval,Ps,Vs),
	sumlist(Vs,Sum),
	V is -1 * E/Sum,
	writeln(V).

doit :-
	directory_files(iranian,Fs),
	include([X]>>(re_match("tsv$",X)),Fs,Ts),
	maplist(dolanguage,Ts).

