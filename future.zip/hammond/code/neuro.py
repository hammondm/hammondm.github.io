#neurosymbolic example in python
#
#adapted from: https://github.com/nikhilbarhate99/Char-RNN-PyTorch/
#
#run with or without geminate constraint by commenting out 
#relevant code below. can also be run with constraint against
#initial geminates only

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
import numpy as np
import random

random.seed(1234)
torch.manual_seed(1234)

#welsh wikipron data
fn = 'wikiproncym.txt'
#persian wikipron data
#fn = 'wikipronfas.txt'

#size of network
hidden_size = 128
num_layers = 3
#learning rate
lr = 0.002
#number of training epochs
epochs = 20
#length of test span
op_seq_len = 60
#how much data to use
reduceto = 1000
#number of test words
testlength = 10

#read in data
f = open(fn,'r')
t = f.read()
f.close()
t = t.split('\n')
t = t[:-1]
words = []
for line in t:
	_,word = line.split('\t')
	bits = word.split(' ')
	bits = ['#'] + bits + ['#']
	words.append(bits)

#randomize
random.shuffle(words)

origwords = words.copy()

#reduce data if you want
words = words[:reduceto]
testwords = origwords[reduceto:reduceto+testlength]

#use GPU if possible
if torch.cuda.is_available():
	device = torch.device("cuda")
else:
	device = torch.device("cpu")
print(f'Running on {device}')

#eliminate geminates
def dropgeminates(x):
	ams = x.argmax(dim=1)
	mins = x.argmin(dim=1)
	amlength = len(ams)
	i = 1
	while i < amlength:
		#check for geminate
		if ams[i] == ams[i-1]:
			#reduce current choice to min
			themin = x[i,mins[i]].item()
			curval = x[i,ams[i]].item()
			newval = -curval-themin
			x[i,ams[i]] -= newval
		i += 1
	return(x)

#eliminate initial geminates
def dropinitgeminate(x):
	ams = x.argmax(dim=1)
	mins = x.argmin(dim=1)
	amlength = len(ams)
	#check for geminate
	if len(ams) > 2 and ams[0] == ams[1]:
		#reduce current choice to min
		themin = x[1,mins[1]].item()
		curval = x[1,ams[1]].item()
		newval = -curval-themin
		x[1,ams[1]] -= newval
	return(x)

#multilayer RNN
class RNN(nn.Module):
	def __init__(self,input_size,output_size,hidden_size,num_layers):
		super(RNN,self).__init__()
		self.embedding = nn.Embedding(input_size,input_size)
		self.rnn = nn.LSTM(
			input_size=input_size,
			hidden_size=hidden_size,
			num_layers=num_layers
		)
		self.decoder = nn.Linear(hidden_size,output_size)
	def forward(self,input_seq,hidden_state):
		embedding = self.embedding(input_seq)
		output,hidden_state = self.rnn(embedding,hidden_state)
		output = self.decoder(output)
		#comment this in to block geminates
		#output = dropgeminates(output)
		#comment this in to block initial geminates
		output = dropinitgeminate(output)
		return output,(hidden_state[0].detach(),hidden_state[1].detach())

#get all characters
chars = set()
#for word in words:
for word in origwords[:reduceto+testlength]:
	for c in word:
		chars.add(c)
chars = sorted(list(chars))

print(f'Characters: {len(chars)}')
print(f'Items: {len(words)}')

vocab_size = len(chars)

#char to index and index to char maps
char_to_ix = { ch:i for i,ch in enumerate(chars) }
ix_to_char = { i:ch for i,ch in enumerate(chars) }
for i,w in enumerate(words):
	word = []
	for c in w:
		word.append(char_to_ix[c])
	words[i] = word

#instantiate model
rnn = RNN(vocab_size,vocab_size,hidden_size,num_layers).to(device)

#loss function
loss_fn = nn.CrossEntropyLoss()
#Adam optimizer
optimizer = torch.optim.Adam(rnn.parameters(),lr=lr)

losses = []

#training loop
for i_epoch in range(1,epochs+1):
	n = 0
	running_loss = 0
	hidden_state = None
	for word in words:
		input_seq = torch.tensor(word[:-1]).to(device)
		target_seq = torch.tensor(word[1:]).to(device)
		#forward pass
		output,hidden_state = rnn(input_seq,hidden_state)
		#compute loss
		loss = loss_fn(torch.squeeze(output),torch.squeeze(target_seq))
		running_loss += loss.item()
		#compute gradients and backprop
		optimizer.zero_grad()
		loss.backward()
		optimizer.step()
		n += 1
	#print loss and after every epoch
	print(f"Epoch: {i_epoch} \t Loss: {running_loss/n:.4f}")
	losses.append(running_loss/n)

#################################################
#             test span at each epoch
#################################################

	#generate test sequence after every epoch
	data_ptr = 0
	hidden_state = None
	#random character from data to begin
	rand_index = np.random.randint(vocab_size-2)
	rand_index += 1
	input_seq = [char_to_ix[chars[rand_index]]]
	#print(f'\t{chars[rand_index]}')
	input_seq = torch.tensor(input_seq).to(device)
	print("----------------------------------------")
	while data_ptr < op_seq_len:
		#forward pass
		output,hidden_state = rnn(input_seq,hidden_state)
		output = F.softmax(torch.squeeze(output),dim=0)
		#construct categorical distribution and sample character
		dist = Categorical(output)
		index = dist.sample()
		#print sampled character
		print(ix_to_char[index.item()],end='')
		#next input is current output
		input_seq[0] = index.item()
		data_ptr += 1
	print("\n----------------------------------------")

#print loss by epoch if you want
#print(losses)

