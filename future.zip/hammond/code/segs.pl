/*
relative frequency of two segments and their joint frequency
compared to their expected frequency if they are independent

data from the UPSID subset of phoible: https://github.com/phoible/dev

runs in swi-prolog

example:		swipl -g 'doit("m","s")' -t halt segs.pl
*/

%location of files
loc('/home/hammond/Desktop/phoible/raw-data/UPSID/').

%get code-lang pairs from a line
getcodelangpairs(L,Code-Lang) :-
	split_string(L,"\t","\t ",[_,_,Lang,Code]).

%get code-lang pairs from file
getlanguagecodes(Lc) :-
	loc(L),
	string_concat(L,'UPSID_LanguageCodes.tsv',F),
	read_file_to_string(F,S,[]),
	split_string(S,"\n"," ",[_|Ls]),
	reverse(Ls,[_|Ts]),
	reverse(Ts,Rs),
	maplist(getcodelangpairs,Rs,Lc).

%get code-seg pairs from line
getcodesegpairs(L,Code-Seg) :-
	split_string(L,"\t","\t ",[Code|[Seg|_]]).

%get code-seg pairs from file
getsegmentcodes(Lc) :-
	loc(L),
	string_concat(L,'UPSID_CharCodes.tsv',F),
	read_file_to_string(F,S,[]),
	split_string(S,"\n"," ",[_|Ls]),
	reverse(Ls,[_|Ts]),
	reverse(Ts,Rs),
	maplist(getcodesegpairs,Rs,Lc).

%get lang-seg pairs from line
getlangcharpairs(L,Lang-Char) :-
	split_string(L,"\t","\t ",[Lang|[Char|_]]).

%get lang-seg pairs from file
getlangsegpairs(Lc) :-
	loc(L),
	string_concat(L,'UPSID_Segments.tsv',F),
	read_file_to_string(F,S,[]),
	split_string(S,"\n"," ",[_|Ls]),
	reverse(Ls,[_|Ts]),
	reverse(Ts,Rs),
	maplist(getlangcharpairs,Rs,Lc).

%do inventories
add_pairs(_,[]) :- !.
add_pairs(H,[L-S|Ps]) :-
	ht_update(H,L,O,[S|O]), !,
	add_pairs(H,Ps).
add_pairs(H,[L-S|Ps]) :-
	ht_put_new(H,L,[S]),
	add_pairs(H,Ps).

getlangsegs(_,_,[]).
getlangsegs(H,S,[L-Ss|Ps]) :-
	%look up language name
	ht_get(H,L,N),
	%look up segments
	maplist([I,O]>>(ht_get(S,I,O)),Ss,Segs),
	format("~w: ~w~n",[N,Segs]),
	getlangsegs(H,S,Ps).

getpair(S,[X,Y]) :-
	member(X,S),
	member(Y,S),
	X @< Y.

segcounts(_,[]) :- !.
segcounts(H,[P|Ps]) :-
	ht_update(H,P,O,N), !,
	N is O + 1,
	segcounts(H,Ps).
segcounts(H,[P|Ps]) :-
	ht_put_new(H,P,1),
	segcounts(H,Ps).

getpaircounts(_,_,_,[]).
getpaircounts(S,P,Ones,[_-Ss|Ps]) :-
	maplist([I,O]>>(ht_get(S,I,O)),Ss,Segs),
	findall([A,B],getpair(Segs,[A,B]),Rs),
	segcounts(P,Rs),
	segcounts(Ones,Segs),
	getpaircounts(S,P,Ones,Ps).

doit(S1,S2) :-
	%get lang-code pairs
	getlanguagecodes(LC),
	%get seg-code pairs
	getsegmentcodes(SCP),
	%make hash from seg-code pairs
	ht_pairs(S,SCP),
	%get lang-seg pairs
	getlangsegpairs(LS),
	length(LC,Langcount),
	%make inventories langcode-[segcodes]
	ht_new(I),
	add_pairs(I,LS),
	%convert inventories to pairs
	ht_pairs(I,Ps),
	%hash from langcode-lang pairs
	%ht_pairs(L,LC),
	%print lang-seg combos
	%getlangsegs(L,S,Ps),
	%do segment singleton and paircounts
	ht_new(Paircounts),
	ht_new(Singlecounts),
	getpaircounts(S,Paircounts,Singlecounts,Ps),

	ht_get(Singlecounts,S1,S1count),
	S1freq is S1count/Langcount,
	format("~w: ~w/~w = ~w~n",[S1,S1count,Langcount,S1freq]),

	ht_get(Singlecounts,S2,S2count),
	S2freq is S2count/Langcount,
	format("~w: ~w/~w = ~w~n",[S2,S2count,Langcount,S2freq]),

	sort([S1,S2],Sorted),
	ht_get(Paircounts,Sorted,Sscount),
	Ssfreq is Sscount/Langcount,
	format("~w: ~w/~w = ~w~n",[Sorted,Sscount,Langcount,Ssfreq]),

	Expected is S1freq * S2freq,
	format("Expected: ~w~n",[Expected]).

