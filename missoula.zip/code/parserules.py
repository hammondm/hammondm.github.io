#code for parsing rule files

import re

def parsePositions(s):
	s = re.sub('\t','',s)
	s = re.split('\\W',s)
	s = list(map(int,s))
	return s

def parseChange(s):
	s = re.sub('\t','',s)
	return int(s)

def parseConstraints(s):
	s = re.sub('\t','',s)
	s = re.sub(' +','',s)
	cs = re.split(',',s)
	ps = []
	for c in cs:
		l,r = c.split('=')
		try:
			i = int(r)
		except ValueError:
			i = r
		c = (int(l),i)
		ps.append(c)
	return ps

def parseRules(fn):
	f = open(fn,'r')
	t = f.read()
	f.close()
	lines = t.split('\n')
	rules = []
	i = 0
	while i < len(lines):
		if len(lines[i]) == 0:
			i += 1
		elif re.match('^[^\t]',lines[i]):
			name = lines[i]
			positions = parsePositions(lines[i+1])
			constraints = parseConstraints(lines[i+2])
			change = parseChange(lines[i+3])
			i += 4
			rules.append((name,positions,constraints,change))
	return rules

if __name__ == '__main__':
	rs = parseRules('rules.txt')
	for rule in rs:
		print(rule)

