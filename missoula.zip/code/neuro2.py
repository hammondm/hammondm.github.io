#neurosymbolic example in python
#
#adapted from: https://github.com/nikhilbarhate99/Char-RNN-PyTorch/
#
#run with various constraints by setting relevant flags below

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
import numpy as np
import random

random.seed(1234)
torch.manual_seed(1234)

#any wikipron language will work
#welsh wikipron data
fn = 'data/wikiproncym.txt'
#persian wikipron data
#fn = 'data/wikipronfas.txt'
#english wikipron data
#fn = 'data/wikiproneng.txt'

#size of network
hidden_size = 128
num_layers = 3
#learning rate
lr = 0.002
#number of training epochs
epochs = 20
#length of test span
op_seq_len = 40
#how much data to use
reduceto = 2000
#number of test words
testlength = 100
#possible settings for drop:
#	0 = allow gems
#	1 = disallow initial gems
#	2 = disallow all gems
drop = 1
#drop specific segment
seg = "k"
#possible settings for dropsegflag
#	0 = allow the segment
#	1 = disallow the segment
dropsegflag = 0

#read in data
f = open(fn,'r')
t = f.read()
f.close()
t = t.split('\n')
t = t[:-1]
words = []
for line in t:
	_,word = line.split('\t')
	bits = word.split(' ')
	bits = ['#'] + bits + ['#']
	words.append(bits)

#randomize
random.shuffle(words)

origwords = words.copy()

#reduce data
words = words[:reduceto]
testwords = origwords[reduceto:reduceto+testlength]

#use GPU if possible (this shouldn't work)
if torch.cuda.is_available():
	device = torch.device("cuda")
else:
	device = torch.device("cpu")
print(f'Running on {device}')

#eliminate geminates
def dropgeminates(x):
	ams = x.argmax(dim=1)
	mins = x.argmin(dim=1)
	amlength = len(ams)
	i = 1
	while i < amlength:
		#check for geminate
		if ams[i] == ams[i-1]:
			#reduce current choice to min
			themin = x[i,mins[i]].item()
			x[i,ams[i]] -= abs(x[i,ams[i]].item()+abs(themin))
			#x[i,ams[i]] -= abs(x[i,ams[i]].item())
			ams = x.argmax(dim=1)
			mins = x.argmin(dim=1)
		i += 1
	return x

#eliminate some specific segment
def dropseg(x):
	segidx = char_to_ix[seg]
	#print(x.shape)
	ams = x.argmax(dim=1)
	mins = x.argmin(dim=1)
	amlength = len(ams)
	i = 0
	while i < amlength:
		#check for segment
		if ams[i] == segidx:
			#reduce current choice to min
			themin = x[i,mins[i]].item()
			curval = x[i,ams[i]].item()
			x[i,ams[i]] -= abs(x[i,ams[i]].item()+abs(themin))
			#x[i,ams[i]] -= abs(x[i,ams[i]].item())
		i += 1
	return x

#eliminate initial geminates
def dropinitgeminate(x):
	ams = x.argmax(dim=1)
	mins = x.argmin(dim=1)
	amlength = len(ams)
	#check for geminate
	if len(ams) > 3 and ams[1] == ams[2]:
		#reduce current choice to min
		themin = x[1,mins[1]].item()
		x[1,ams[1]] -= abs(x[1,ams[1]].item()+abs(themin))
		#x[1,ams[1]] -= abs(x[1,ams[1]].item())
	return x

#multilayer RNN, using LSTM nodes
class RNN(nn.Module):
	def __init__(self,input_size,output_size,hidden_size,num_layers):
		super(RNN,self).__init__()
		self.embedding = nn.Embedding(input_size,input_size)
		self.rnn = nn.LSTM(
			input_size=input_size,
			hidden_size=hidden_size,
			num_layers=num_layers
		)
		self.decoder = nn.Linear(hidden_size,output_size)
	def forward(self,input_seq,hidden_state):
		embedding = self.embedding(input_seq)
		output,hidden_state = self.rnn(embedding,hidden_state)
		output = self.decoder(output)
		if drop == 1:
			output = dropinitgeminate(output)
		elif drop == 2:
			output = dropgeminates(output)
		if dropsegflag == 1:
			output = dropseg(output)
		return output,(hidden_state[0].detach(),hidden_state[1].detach())

#get all characters
chars = set()
for word in origwords[:reduceto+testlength]:
	for c in word:
		chars.add(c)
chars = sorted(list(chars))

print(f'Characters: {len(chars)}')
print(f'Items: {len(words)}')

vocab_size = len(chars)

#char to index and index to char maps
char_to_ix = { ch:i for i,ch in enumerate(chars) }
ix_to_char = { i:ch for i,ch in enumerate(chars) }

#convert characters to indices for training items
for i,w in enumerate(words):
	word = []
	for c in w:
		word.append(char_to_ix[c])
	words[i] = word

#convert characters to indices for test items
testwordsidx = []
for w in testwords:
	word = []
	for c in w:
		word.append(char_to_ix[c])
	testwordsidx.append(word)

#instantiate model
rnn = RNN(vocab_size,vocab_size,hidden_size,num_layers).to(device)

#count parameters
#trainable = sum(p.numel() for p in rnn.parameters() if p.requires_grad)
#print('trainable:',trainable)
#exit()

#loss function
loss_fn = nn.CrossEntropyLoss()
#Adam optimizer
optimizer = torch.optim.Adam(rnn.parameters(),lr=lr)

#loss by epoch
losses = []
#avg test prob by epoch
allreses = []

#training loop
for i_epoch in range(1,epochs+1):
	n = 0
	running_loss = 0
	hidden_state = None
	for word in words:
		input_seq = torch.tensor(word[:-1]).to(device)
		target_seq = torch.tensor(word[1:]).to(device)
		#forward pass
		output,hidden_state = rnn(input_seq,hidden_state)
		#compute loss
		loss = loss_fn(torch.squeeze(output),torch.squeeze(target_seq))
		running_loss += loss.item()
		#compute gradients and backprop
		optimizer.zero_grad()
		loss.backward()
		optimizer.step()
		n += 1
	#print loss and after every epoch
	print(f"Epoch: {i_epoch} \t Loss: {running_loss/n:.4f}")
	losses.append(running_loss/n)

#################################################
#             test span at each epoch
#################################################

	#generate test sequence after every epoch
	data_ptr = 0
	hidden_state = None
	#random character from data to begin
	rand_index = np.random.randint(vocab_size-2)
	rand_index += 1
	input_seq = [char_to_ix[chars[rand_index]]]
	input_seq = torch.tensor(input_seq).to(device)
	print("----------------------------------------")
	while data_ptr < op_seq_len:
		#forward pass
		output,hidden_state = rnn(input_seq,hidden_state)
		output = F.softmax(torch.squeeze(output),dim=0)
		#construct categorical distribution and sample character
		dist = Categorical(output)
		index = dist.sample()
		#print sampled character
		print(ix_to_char[index.item()],end='')
		#next input is current output
		input_seq[0] = index.item()
		data_ptr += 1
	print("\n----------------------------------------")

#################################################
#             run test items at each epoch
#################################################

	allres = 0
	for i,word in enumerate(testwords):
		#create input from all but last symbol
		input_seq = torch.tensor(testwordsidx[i][:-1]).to(device)
		#create target from all but first symbol
		target_seq = testwordsidx[i][1:]
		#get predictions
		output,_ = rnn(input_seq,None)
		#convert to probabilities
		output = F.softmax(torch.squeeze(output),dim=1)
		res = 1
		#get probabilities predicted for target symbols
		for idx,x in enumerate(target_seq):
			res *= output[idx,x].item()
		allres += res
	allres /= len(testwords)
	allreses.append(allres)
	print('avg prob for test items:',allres)
	print("----------------------------------------")

#print loss by epoch if you want
print('Loss by epoch:')
print(losses)

#print avg prob by epoch if you want
print('Avg prob by epoch:')
print(allreses)

