#neurosymbolic example in python
#
#adapted from: https://github.com/nikhilbarhate99/Char-RNN-PyTorch/
#
#run with various constraints by adding to rules.txt file

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
import numpy as np
import random
from parserules import parseRules

random.seed(1234)
torch.manual_seed(1234)

#any wikipron language will work or language data in wikipron format

#welsh
fn = 'data/wikiproncym.txt'
#persian
#fn = 'data/wikipronfas.txt'
#english
#fn = 'data/wikiproneng.txt'

#get rules from rules file
rules = parseRules('rules.txt')
#can use this for no rules
#rules = []

#size of network
hidden_size = 128
num_layers = 3
#learning rate
lr = 0.002
#number of training epochs
epochs = 40
#length of test span
op_seq_len = 60
#how much data to use
reduceto = 2000
#number of test words
testlength = 100

#read in data
f = open(fn,'r')
t = f.read()
f.close()
t = t.split('\n')
t = t[:-1]
words = []
for line in t:
	_,word = line.split('\t')
	bits = word.split(' ')
	bits = ['#'] + bits + ['#']
	words.append(bits)

#randomize
random.shuffle(words)

#reduce data if you want
origwords = words.copy()
words = words[:reduceto]
testwords = origwords[reduceto:reduceto+testlength]

#use GPU if possible (this should not work)
if torch.cuda.is_available():
	device = torch.device("cuda")
else:
	device = torch.device("cpu")
print(f'Running on {device}')

#apply constraints
def dorules(x):
	#go through each rule
	for rule in rules:
		pos = len(rule[1])
		cs = rule[2]
		change = rule[3]
		ams = x.argmax(dim=1)
		mins = x.argmin(dim=1)
		amlength = len(ams)
		#go through input segment by segment
		i = 0
		while (i+pos)-1 < amlength:
			#check each constraint
			cres = []
			for c in cs:
				a = (i+c[0])-1
				#matching segment positions
				if isinstance(c[1],int):
					b = (i+c[1])-1
					cres.append(ams[a] == ams[b])
				#segmental identity for a position
				else:
					if c[1] in char_to_ix:
						segidx = char_to_ix[c[1]]
						cres.append(ams[a] == segidx)
					else:
						cres.append(False)
			#if all constraints satisfied, apply change
			if all(cres):
				cpos = (i+change)-1
				#reduce current choice to min
				themin = x[cpos,mins[cpos]].item()
				x[cpos,ams[cpos]] -= abs(x[cpos,ams[cpos]].item()+abs(themin))
				ams = x.argmax(dim=1)
				mins = x.argmin(dim=1)
			i += 1
	return x

#multilayer RNN, using LSTM nodes
class RNN(nn.Module):
	def __init__(self,input_size,output_size,hidden_size,num_layers):
		super(RNN,self).__init__()
		self.embedding = nn.Embedding(input_size,input_size)
		self.rnn = nn.LSTM(
			input_size=input_size,
			hidden_size=hidden_size,
			num_layers=num_layers
		)
		self.decoder = nn.Linear(hidden_size,output_size)
	#you can generate output with or without rules
	def forward(self,input_seq,hidden_state,flag=True):
		embedding = self.embedding(input_seq)
		output,hidden_state = self.rnn(embedding,hidden_state)
		output = self.decoder(output)
		if flag:
			output = dorules(output)
		return output,(hidden_state[0].detach(),hidden_state[1].detach())

#get all characters
chars = set()
for word in origwords[:reduceto+testlength]:
	for c in word:
		chars.add(c)
chars = sorted(list(chars))

print(f'Characters: {len(chars)}')
print(f'Items: {len(words)}')

vocab_size = len(chars)

#char to index and index to char maps
char_to_ix = { ch:i for i,ch in enumerate(chars) }
ix_to_char = { i:ch for i,ch in enumerate(chars) }

#convert characters to indices for training items
for i,w in enumerate(words):
	word = []
	for c in w:
		word.append(char_to_ix[c])
	words[i] = word

#convert characters to indices for test items
testwordsidx = []
for w in testwords:
	word = []
	for c in w:
		word.append(char_to_ix[c])
	testwordsidx.append(word)

#instantiate model
rnn = RNN(vocab_size,vocab_size,hidden_size,num_layers).to(device)

#loss function
loss_fn = nn.CrossEntropyLoss()
#Adam optimizer
optimizer = torch.optim.Adam(rnn.parameters(),lr=lr)

#loss by epoch
losses = []
#avg test prob by epoch
allreses = []

#training loop
for i_epoch in range(1,epochs+1):
	n = 0
	running_loss = 0
	hidden_state = None
	for word in words:
		input_seq = torch.tensor(word[:-1]).to(device)
		target_seq = torch.tensor(word[1:]).to(device)
		#forward pass
		output,hidden_state = rnn(input_seq,hidden_state)
		#compute loss
		loss = loss_fn(torch.squeeze(output),torch.squeeze(target_seq))
		running_loss += loss.item()
		#compute gradients and backprop
		optimizer.zero_grad()
		loss.backward()
		optimizer.step()
		n += 1
	#print loss and after every epoch
	print(f"Epoch: {i_epoch} \t Loss: {running_loss/n:.4f}")
	losses.append(running_loss/n)

#################################################
#             test span at each epoch
#################################################

	#generate test sequence after every epoch
	data_ptr = 0
	hidden_state = None
	#random character from data to begin
	rand_index = np.random.randint(vocab_size-2)
	rand_index += 1
	input_seq = [char_to_ix[chars[rand_index]]]
	input_seq = torch.tensor(input_seq).to(device)
	print("----------------------------------------")
	while data_ptr < op_seq_len:
		#forward pass
		output,hidden_state = rnn(input_seq,hidden_state)
		output = F.softmax(torch.squeeze(output),dim=0)
		#construct categorical distribution and sample character
		dist = Categorical(output)
		index = dist.sample()
		#print sampled character
		print(ix_to_char[index.item()],end='')
		#next input is current output
		input_seq[0] = index.item()
		data_ptr += 1
	print("\n----------------------------------------")

#################################################
#             run test items at each epoch
#################################################

	allres = 0
	for i,word in enumerate(testwords):
		#create input from all but last symbol
		input_seq = torch.tensor(testwordsidx[i][:-1]).to(device)
		#create target from all but first symbol
		target_seq = testwordsidx[i][1:]
		#get predictions
		output,_ = rnn(input_seq,None)
		#convert to probabilities
		output = F.softmax(torch.squeeze(output),dim=1)
		res = 1
		#get probabilities predicted for target symbols
		for idx,x in enumerate(target_seq):
			res *= output[idx,x].item()
		allres += res
	allres /= len(testwords)
	allreses.append(allres)
	print('avg prob for test items:',allres)
	print("----------------------------------------")

#print loss by epoch
print('Loss by epoch:')
print(losses)

#print avg prob by epoch
print('Avg prob by epoch:')
print(allreses)

