#!/bin/bash

rm -rf verybigdigits
rm -rf data
rm -rf utils
rm -rf steps
rm -rf conf
rm -rf exp
rm -rf mfcc
rm -rf local

