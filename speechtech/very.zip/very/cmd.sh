
export train_cmd=run.pl
export decode_cmd=run.pl
export cuda_cmd="run.pl --gpu 1"

