#!/bin/bash

rm -rf __pycache__
rm test.txt
rm train.txt
rm valid.txt
rm ~/Desktop/model.pt
rm ~/Desktop/generated.txt

