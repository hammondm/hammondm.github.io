#!/bin/bash

rm -rf utils/
rm -rf local/
rm -rf steps/
rm -rf conf/
rm -rf data/
rm -rf exp/
rm -rf mfcc/
#rm -rf corpus/

