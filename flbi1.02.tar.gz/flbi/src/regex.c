
#include "regex.h"

/*
This module includes the methods for constructing a regular expression
object.

Mike Hammond
*/

//creates a simple RE
struct regexp *makeSimple(char c) {
	struct regexp *re = (struct regexp *)malloc(sizeof(struct regexp));
	re->type = SIMPLE;
	re->c = c;
	re->re1 = NULL;
	re->re2 = NULL;
	return re;
}

//creates a Kleene star RE
struct regexp *makeKleene(struct regexp *r) {
	struct regexp *re = (struct regexp *)malloc(sizeof(struct regexp));
	re->type = KLEENE;
	re->re1 = r;
	re->re2 = NULL;
	return re;
}

//creates a union RE
struct regexp *makeUnion(struct regexp *r1, struct regexp *r2) {
	struct regexp *re = (struct regexp *)malloc(sizeof(struct regexp));
	re->type = UNION;
	re->re1 = r1;
	re->re2 = r2;
	return re;
}

//creates a concatenation RE
struct regexp *makeConcat(struct regexp *r1, struct regexp *r2) {
	struct regexp *re = (struct regexp *)malloc(sizeof(struct regexp));
	re->type = CONCAT;
	re->re1 = r1;
	re->re2 = r2;
	return re;
}

//extracts a string representation of a RE
char *printableRE(struct regexp *r) {
	char *s, *p1, *p2;
	switch (r->type) {
		case SIMPLE:
			s = (char *)malloc(2);
			s[0] = r->c;
			s[1] = '\0';
			break;
		case KLEENE:
			p1 = printableRE(r->re1);
			asprintf(&s, "[%s*]", p1);
			free(p1);
			break;
		case UNION:
			p1 = printableRE(r->re1);
			p2 = printableRE(r->re2);
			asprintf(&s, "[%s|%s]", p1, p2);
			free(p1);
			free(p2);
			break;
		case CONCAT:
			p1 = printableRE(r->re1);
			p2 = printableRE(r->re2);
			asprintf(&s, "[%s %s]", p1, p2);
			free(p1);
			free(p2);
			break;
	}
	return s;
}

//deallocate memory for a regular expression
void deallocRE(struct regexp *r) {
	switch (r->type) {
		case SIMPLE:
			break;
		case KLEENE:
			deallocRE(r->re1);
			break;
		default:
			deallocRE(r->re1);
			deallocRE(r->re2);
	}
	free(r);
}

