
#include "xmlfsaparser.h"
#include "minFSA.h"
#include "distinct.h"

/*
This program creates the concatenation of two other FSAs. They are given as
XML specifications.

Mike Hammond
*/

int main(int argc, char *argv[]) {
	char *newName;
	struct node *n1, *n2;
	struct arc *a;
	//check that command-line arguments are present
	if (argc != 3) {
		fprintf(stderr, "usage: concatenate xml-file1 xml-file2\n");
		return 1;
	}
	//parse the FSAs from the XML files
	struct fsa *f1 = parseXML(argv[1]);
	struct fsa *f2 = parseXML(argv[2]);
	//check that FSAs are determinized
	if (!(f1->determinized && f2->determinized)) {
		deallocFSA(f1);
		deallocFSA(f2);
		fprintf(stderr, "FSAs must be already determinized\n");
		return 1;
	}
	//make sure node names are unique
	distinguish(f1, f2);
	//make arcs from f1 end states to f2 start states
	n1 = f1->nodes;
	while (n1 != NULL) {
		if (n1->final) {
			n2 = f2->nodes;
			while (n2 != NULL) {
				if (n2->start) {
					a = makeArc(EPSILON, n1, n2);
					addArc(n1, a);
				}
				n2 = n2->nextNode;
			}
			//make f1 end states non-final
			n1->final = false;
		}
		n1 = n1->nextNode;
	}
	//make f2 start states non-start
	n1 = f2->nodes;
	while (n1 != NULL) {
		n1->start = false;
		n1 = n1->nextNode;
	}
	//add all nodes from f2 to f1
	addNode(f1, f2->nodes);
	f2->nodes = NULL;
	//remove epsilons in new FSA (1)
	removeEpsilons(f1);
	//determinize new FSA (1)
	determinize(f1);
	//minimize new FSA (1)
	minimize(f1);
	//output new FSA (1) as XML
	printXML(f1);
	//free memory
	deallocFSA(f1);
	deallocFSA(f2);
	return 0;
}

