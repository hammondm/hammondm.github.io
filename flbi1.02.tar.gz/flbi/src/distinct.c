
#include "distinct.h"

/*
This module checks that the names of nodes in two FSAs are distinct. If
they are not, the names of the latter are updated.

It also returns the new node count maximum. This is NOT the number of nodes
in the FSA, but the value of the highest-numbered node.

Mike Hammond
*/

//make sure node names are distinct; rename nodes in f2
int distinguish(struct fsa *f1, struct fsa *f2) {
	//make sure node names are unique
	bool overlap = false;
	//names and max from first FSA
	sortedSet *names = newSortedSet();
	char *name, *newName;
	char prefix;
	int num1, num2, num3;
	num1 = 0;
	struct node *n = f1->nodes;
	while (n != NULL) {
		name = n->name;
		num2 = atoi(name+1);
		if (num2 > num1)
			num1 = num2;
		addToSortedSet(names, name);
		n = n->nextNode;
	}
	//names and max from second FSA
	n = f2->nodes;
	while (n != NULL) {
		name = n->name;
		num2 = atoi(name+1);
		if (num2 > num1)
			num1 = num2;
		if (isInSet(names, name))
			overlap = true;
		n = n->nextNode;
	}
	num1++;
	freeSortedSet(names);
	num3 = 0;
	//if there's overlap, make new names for nodes in second fsa.
	if (overlap) {
		n = f2->nodes;
		name = n->name;
		prefix = name[0];
		while (n != NULL) {
			name = n->name;
			num2 = atoi(name+1);
			num2 += num1;
			if (num3 < num2)
				num3 = num2;
			asprintf(&newName, "%c%i", prefix, num2);
			n->name = newName;
			free(name);
			n = n->nextNode;
		}
	}
	return num3;
}

