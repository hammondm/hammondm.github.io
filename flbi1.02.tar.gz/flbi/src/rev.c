
#include "rev.h"

/*
This module includes the code to reverse an automaton

Mike Hammond
*/

//creates the reverse language for an FSA
void reverse(struct fsa *f) {
	fprintf(stderr, "Reversing FSA...\n");
	//get all the arcs and switch start and final states
	struct arc *a, *firstArc, *aList, *lastArc;
	bool makeFinal, makeStart;
	struct node *n = f->nodes;
	int count = 0;
	aList = NULL;
	//go through the nodes one by one
	while (n != NULL) {
		//get all the arcs
		a = n->arcs;
		firstArc = n->arcs;
		lastArc = NULL;
		while (a != NULL) {
			count++;
			lastArc = a;
			a = a->nextArc;
		}
		//add the arcs to the list
		if (lastArc != NULL) {
			lastArc->nextArc = aList;
			aList = firstArc;
			n->arcs = NULL;
		}
		//switch start and final states
		//first figure out if it SHOULD be switched
		if (n->final)
			makeStart = true;
		else
			makeStart = false;
		if (n->start)
			makeFinal = true;
		else
			makeFinal = false;
		//reset everything
		n->start = false;
		n->final = false;
		//make the switches
		if (makeStart)
			n->start = true;
		if (makeFinal)
			n->final = true;
		n = n->nextNode;
	}
	//switch from and to
	a = aList;
	count = 0;
	while (a != NULL) {
		count++;
		n = a->from;
		a->from = a->to;
		a->to = n;
		a = a->nextArc;
	}
	//put them with the right nodes
	while (aList != NULL) {
		a = aList;
		aList = a->nextArc;
		a->nextArc = NULL;
		addArc(a->from, a);
	}
	f->determinized = false;
}

