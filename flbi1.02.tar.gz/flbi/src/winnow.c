
#include <stdio.h>
#include <string.h>

/*
This file prunes away arcs where the weight is less than a value specified
on the command-line.

Mike Hammond
*/

#define SIZE 100
#define LEFT "ght=\""
#define RIGHT "\"/>"

int main(int argc, char *argv[]) {
	float level;
	FILE *myFile;
	char line[SIZE], value[SIZE];
	int n;
	char *loc1, *loc2;
	//check that command-line arguments are present
	if (argc != 3) {
		fprintf(stderr, "usage: prune xmlfile level\n");
		return 1;
	}
	level = (float) atoi(argv[2]);
	printf("level = %f\n", level);
	myFile = fopen(argv[1], "r");
	if (myFile == NULL) {
		fprintf(stderr, "Problem opening file: %s\n", argv[1]);
		return 1;
	}
	while (fgets(line, SIZE, myFile) != NULL) {
		if (strstr(line, "arc")) {
			loc1 = strstr(line, LEFT);
			loc1 = loc1 + 5;
			loc2 = strstr(loc1, RIGHT);
			n = strlen(loc1) - strlen(loc2);
			strncpy(value, loc1, n);
			value[n] = '\0';
			if (atoi(value) > level)
				printf(line);
		} else {
			printf(line);
		}
	}
	fclose(myFile);
	return 0;
}

