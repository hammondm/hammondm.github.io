#!/usr/bin/perl -w
use strict;

my(@files, @lines, $version);

#check command-line argument
if (@ARGV != 1) {
	print STDERR "usage: ./version.pl number\n";
	exit 0;
}

#where the documentation is
my $mandir = '../man/';
#get the file names
@files = `ls $mandir*.1`;
#version number comes from the command-line
$version = $ARGV[0];

#loop through all the file names
foreach my $filename (@files) {
	#get rid of the return
	chomp $filename;
	#read in all the lines
	open F, "$mandir$filename" or die "Can't read $filename\n";
	@lines = <F>;
	#change the version number
	foreach my $line (@lines) {
		$line =~ s/(Version ).*\"/$1$version\"/;
	}
	close F;
	#write the new file to the SAME file name
	open F, ">$mandir$filename" or die "Can't write to $filename\n";
	print F @lines;
	close F;
}

=head1 version.pl

This program updates the version number in all the documentation in the man
directory.

=head1 author

Mike Hammond, I<hammond@u.arizona.edu>

=cut

