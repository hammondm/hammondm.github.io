
#include "xmlfsaparser.h"
#include "minFSA.h"

/*
This program creates the Kleene closure of an FSA, given as an XML
specification.

Mike Hammond
*/

int main(int argc, char *argv[]) {
	int max = 0;
	int curNum;
	char prefix;
	char *newName;
	struct node *n1, *n2, *newNode;
	struct arc *a;
	//check that command-line argument is present
	if (argc != 2) {
		fprintf(stderr, "usage: kleene xml-file\n");
		return 1;
	}
	//parse the FSA from the XML file
	struct fsa *f = parseXML(argv[1]);
	//check that FSA is determinized
	if (!f->determinized) {
		deallocFSA(f);
		fprintf(stderr, "FSA must be already determinized\n");
		return 1;
	}
	//go through nodes one by one get max value
	n1 = f->nodes;
	prefix = n1->name[0];
	while (n1 != NULL) {
		curNum = atoi(n1->name+1);
		if (curNum > max)
			max = curNum;
		n1 = n1->nextNode;
	}
	max++;
	//add epsilons from final states to initial states
	n1 = f->nodes;
	while (n1 != NULL) {
		if (n1->start) {
			n2 = f->nodes;
			while (n2 != NULL) {
				if (n2->final) {
					a = makeArc(EPSILON, n2, n1);
					addArc(n2, a);
				}
				n2 = n2->nextNode;
			}
		}
		n1 = n1->nextNode;
	}
	//add new diamond state
	asprintf(&newName, "%c%i", prefix, max);
	newNode = makeNodeWithName(newName, true, true);
	addNode(f, newNode);
	//remove epsilons
	removeEpsilons(f);
	//determinize
	determinize(f);
	//minimize
	minimize(f);
	//output new FSA as XML
	printXML(f);
	//free memory
	deallocFSA(f);
	return 0;
}

