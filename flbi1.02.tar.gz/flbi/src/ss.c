#include "ss.h"

/*
This module implements a set. The set is sorted and implemented as a linked
list.

Mike Hammond
*/

//gets the lenth of a sorted set
int sortedSetSize(sortedSet *s) {
	sslink *l;
	int res = 0;
	l = s->firstOne;
	while (l != NULL) {
		res++;
		l = l->next;
	}
	return res;
}

//pops the top element off a sorted set
char *pop(sortedSet *s) {
	if (s->firstOne == NULL)
		return NULL;
	char *it = s->firstOne->s;
	sslink *l = s->firstOne;
	s->firstOne = s->firstOne->next;
	free(l);
	return it;
}

//puts two sets together; adds elements of the second to the first
void setUnion(sortedSet *ss1, sortedSet *ss2) {
	sslink *l = ss2->firstOne;
	while (l != NULL) {
		addToSortedSet(ss1, l->s);
		l = l->next;
	}
}

//set equality
bool setEquals(sortedSet *ss1, sortedSet *ss2) {
	sslink *l = ss1->firstOne;
	while (l != NULL) {
		if (!isInSet(ss2, l->s))
			return false;
		l = l->next;
	}
	l = ss2->firstOne;
	while (l != NULL) {
		if (!isInSet(ss1, l->s))
			return false;
		l = l->next;
	}
	return true;
}

//deallocates memory for a sorted set
void freeSortedSet(sortedSet *ss) {
	sslink *l = ss->firstOne;
	sslink *lastOne = NULL;
	free(ss);
	while (l != NULL) {
		lastOne = l;
		l = l->next;
		free(lastOne->s);
		free(lastOne);
	}
}

//creates a sorted set
sortedSet *newSortedSet(void) {
	sortedSet *ss = (sortedSet *)malloc(sizeof(sortedSet));
	ss->firstOne = NULL;
	return ss;
}

//checks if a string is in the sorted set
bool isInSet(sortedSet *ss, char *str) {
	sslink *l = ss->firstOne;
	while (l != NULL) {
		if (strcmp(l->s, str) == 0)
			return true;
		l = l->next;
	}
	return false;
}

//adds an element to a sorted set
void addToSortedSet(sortedSet *ss, char *str) {
	sslink *lastOne, *thisOne, *newOne;
	int res;
	//starts with the first link
	thisOne = ss->firstOne;
	lastOne = NULL;
	//loops until the last link
	while (thisOne != NULL) {
		//does a string comparison
		res = strcmp(thisOne->s, str);
		//exits entirely if the string is already in the set
		if (res == 0) return;
		//exits loop if string to be added precedes current string
		if (res > 0) break;
		lastOne = thisOne;
		thisOne = thisOne->next;
	}
	//creates a new link...
	newOne = (sslink *)malloc(sizeof(sslink));
	newOne->s = strdup(str);
	newOne->next = thisOne;
	//...and inserts it in the right place
	if (lastOne == NULL) {
		ss->firstOne = newOne;
	} else {
		lastOne->next = newOne;
	}
}

//prints a sorted set
void printSortedSet(sortedSet *s) {
	sslink *l;
	int i = 1;
	l = s->firstOne;
	printf("{ ");
	while (l != NULL) {
		printf("%s ", l->s);
		l = l->next;
	}
	printf("}\n");
}

