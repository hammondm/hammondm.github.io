
#ifndef XMLFSAPARSER_H
#define XMLFSAPARSER_H

#include <stdio.h>
#include <expat.h>
#include <string.h>

#include "automata.h"

#define BUFFSIZE	8192

//list of arcs as text
struct _textArc {
	char *from;
	char *to;
	char symbol;
	struct _textArc *next;
	float weight;
};
typedef struct _textArc textArc;

//parse an XML file
struct fsa *parseXML(char *s);

#endif

