
#include "minFSA.h"

/*
This module implements the classic minimization routine of Hopcroft &
Ullman.

This involves a lot of looping over inefficient data structures and can be
pretty slow.

Mike Hammond
*/

//represents the block membership for a state
struct _part {
	char *state;
	int p;
};
typedef struct _part part;

//states that a cell can be in or that a cell can change to
enum _states { NONE, EMPTY, CHECK, CROSS };
typedef enum _states states;

//cell in the table for determining distinct states
struct _cell {
	char *n1;
	char *n2;
	states state;
	states toChange;
};
typedef struct _cell cell;

//print the chart: for debugging
void printChart(cell **chart, int size) {
	int count;
	for (count = 0; count < size; count++) {
		printf("%d: (%s, %s): ", count, chart[count]->n1, chart[count]->n2);
		switch (chart[count]->state) {
			case EMPTY:
				printf("empty\n");
				break;
			case CROSS:
				printf("cross\n");
				break;
			case CHECK:
				printf("check\n");
		}
	}
}

//print the table: for debugging
void printTable(part **table, int size) {
	int count;
	for (count = 0; count < size; count++) {
		printf("%s: %2d\n", table[count]->state, table[count]->p);
	}
}

//free the table
void freeTable(part **table, int size) {
	int count;
	for (count = 0; count < size; count++) {
		free(table[count]);
	}
}

//free the chart
void freeChart(cell **chart, int size) {
	int count;
	for (count = 0; count < size; count++) {
		free(chart[count]);
	}
}

//minimizes an FSA
void minimize(struct fsa *f) {
	fprintf(stderr, "Minimizing FSA...\n");
	char *s, *left, *right;
	struct arc *a;
	bool bothDiagonal, hasCross, notCheck, goAgain, alreadyExists;
	int combos, count, c2, p, nc, p1, p2;
	sortedSet *initial, *final;
	//number of nodes in the automaton
	nc = nodeCount(f);
	count = nc;
	//number of cells in the table
	combos = (((count * count) - count)/2) + count;
	//chart of distinct states
	cell *chart[combos];
	//partitions in the set of states
	part *table[nc];
	//the alphabet to construct the table
	sortedSet *alphabet;
	struct node *n = f->nodes;
	struct node *n2, *n3, *newNodes;
	//gets every combination of nodes and puts them in the chart
	count = 0;
	while (n != NULL) {
		n2 = n;
		while (n2 != NULL) {
			//initializes cell
			chart[count] = (cell *)malloc(sizeof(cell));
			chart[count]->n1 = n->name;
			chart[count]->n2 = n2->name;
			chart[count]->state = EMPTY;
			chart[count]->toChange = NONE;
			//marks cell with a check if it's on the diagonal
			if (strcmp(n->name, n2->name) == 0) {
				chart[count]->state = CHECK;
			//marks cell with cross if one is final and the other not
			} else if (n->final && !n2->final) {
				chart[count]->state = CROSS;
			} else if (!n->final && n2->final) {
				chart[count]->state = CROSS;
			}
			count++;
			n2 = n2->nextNode;
		}
		n = n->nextNode;
	}
	//loops until no changes are made
	goAgain = true;
	while (goAgain) {
		goAgain = false;
		//check every cell in the table
		for (count = 0; count < combos; count++) {
			//if a cell is not yet checked or crossed
			if (chart[count]->state == EMPTY) {
				hasCross = false;
				notCheck = false;
				alphabet = getAlphabet(f->nodes);
				//check arcs for each symbol in the alphabet
				while (sortedSetSize(alphabet) > 0) {
					s = pop(alphabet);
					//check for the left member
					n = getStateByName(f->nodes, chart[count]->n1);
					a = n->arcs;
					while (a != NULL) {
						if (a->symbol == s[0]) {
							left = a->to->name;
							break;
						}
						a = a->nextArc;
					}
					//check for the right member
					n = getStateByName(f->nodes, chart[count]->n2);
					a = n->arcs;
					while (a != NULL) {
						if (a->symbol == s[0]) {
							right = a->to->name;
							break;
						}
						a = a->nextArc;
					}
					bothDiagonal = true;
					//now go through and get the status of the output pair
					for (c2 = 0; c2 < combos; c2++) {
						if (strcmp(chart[c2]->n1, chart[c2]->n2) != 0)
							bothDiagonal = false;
						//check for a match in either order
						if (((strcmp(chart[c2]->n1, left) == 0) &&
									(strcmp(chart[c2]->n2, right) == 0)) ||
								(((strcmp(chart[c2]->n2, left) == 0) &&
										(strcmp(chart[c2]->n1, right) == 0)))) {
							//updates the status
							switch (chart[c2]->state) {
								case EMPTY:
									notCheck = true;
									break;
								case CROSS:
									hasCross = true;
									notCheck = true;
							}
							break;
						}
					}
					free(s);
				}
				if (hasCross) {
					chart[count]->toChange = CROSS;
				} else if (!notCheck) {
					chart[count]->toChange = CHECK;
				}
				freeSortedSet(alphabet);
			}
		}
		//change cells here.
		for (count = 0; count < combos; count++) {
			if ((chart[count]->state == EMPTY) &&
					(chart[count]->toChange != NONE)) {
				chart[count]->state = chart[count]->toChange;
				chart[count]->toChange = NONE;
				goAgain = true;
			}
		}
	}
	//recursive routine is done; do the finishing up here.
	for (count = 0; count < combos; count++) {
		if (chart[count]->state == EMPTY)
			chart[count]->state = CHECK;
			//chart[count]->state = CROSS;
	}
	//set up initial partitions
	n = f->nodes;
	for (count = 0; count < nc; count++) {
		table[count] = (part *)malloc(sizeof(part));
		table[count]->state = n->name;
		table[count]->p = count;
		n = n->nextNode;
	}
	//go through the list looking for mergeable states
	for (count = 0; count < combos; count++) {
		//states are mergeable
		if (chart[count]->state == CHECK) {
			//state names are distinct
			if (strcmp(chart[count]->n1, chart[count]->n2) != 0) {
				//get the current partitions from the table
				for (p = 0; p < nc; p++) {
					if (strcmp(table[p]->state, chart[count]->n1) == 0)
						p1 = table[p]->p;
					else if (strcmp(table[p]->state, chart[count]->n2) == 0)
						p2 = table[p]->p;
				}
				//if the current partitions are different
				if (p1 != p2) {
					//go through the table again
					for (p = 0; p < nc; p++) {
						if (table[p]->p == p2)
							table[p]->p = p1;
					}
				}
			}
		}
	}
	//make new states
	newNodes = NULL;
	//go through the table line by line
	for (p = 0; p < nc; p++) {
		//make candidate node name
		s = (char *)malloc(10);
		sprintf(s, "%d", table[p]->p);
		for (count = strlen(s); count >= 0; count--)
			s[count+1] = s[count];
		s[0] = 'q';
		//does node already exist?
		n = newNodes;
		alreadyExists = false;
		while (n != NULL) {
			//if the node already exists
			if (strcmp(s, n->name) == 0) {
				//add the current old node name to parts list
				addToSortedSet(n->parts, table[p]->state);
				alreadyExists = true;
				break;
			}
			n = n->nextNode;
		}
		//if the node does not already exist
		if (!alreadyExists) {
			//create a new node
			n = (struct node *)malloc(sizeof(struct node));
			n->name = s;
			n->final = false;
			n->start = false;
			n->nextNode = newNodes;
			n->arcs = NULL;
			n->parts = newSortedSet();
			addToSortedSet(n->parts, table[p]->state);
			newNodes = n;
		} else {
			free(s);
		}
	}
	//collect initial/final state info
	initial = newSortedSet();
	final = newSortedSet();
	n = f->nodes;
	while (n != NULL) {
		if (n->final)
			addToSortedSet(final, n->name);
		if (n->start)
			addToSortedSet(initial, n->name);
		n = n->nextNode;
	}
	//make initial and final states
	n = newNodes;
	while (n != NULL) {
		if (isInSet(n->parts, initial->firstOne->s))
			n->start = true;
		if (isInSet(final, n->parts->firstOne->s))
			n->final = true;
		n = n->nextNode;
	}
	freeSortedSet(initial);
	freeSortedSet(final);
	//make new arcs
	//go through all the new nodes one by one
	n = newNodes;
	while (n != NULL) {
		//get first state name
		s = n->parts->firstOne->s;
		//get the actual first state from the old nodes
		n2 = getStateByName(f->nodes, s);
		//go through the alphabet letter by letter
		alphabet = getAlphabet(f->nodes);
		while (sortedSetSize(alphabet) > 0) {
			//get the current letter
			s = pop(alphabet);
			//go through all the old node arcs
			a = n2->arcs;
			while (a != NULL) {
				//get the old destination node
				if (a->symbol == s[0])
					break;
				a = a->nextArc;
			}
			//find the new state that 'contains' the old destination state
			n3 = newNodes;
			while (n3 != NULL) {
				if (isInSet(n3->parts, a->to->name)) {
					break;
				}
				n3 = n3->nextNode;
			}
			//add a new arc
			a = makeArc(s[0], n, n3);
			addArc(n, a);
		}
		freeSortedSet(alphabet);
		n = n->nextNode;
	}
	//get rid of old states and arcs
	deallocFSA(f);
	f = (struct fsa *)malloc(sizeof(struct fsa));
	f->nodes = newNodes;
	f->determinized = true;
	//free table and chart
	freeTable(table, nc);
	freeChart(chart, combos);
}

