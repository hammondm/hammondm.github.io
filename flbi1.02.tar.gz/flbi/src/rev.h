
#ifndef REV_H
#define REV_H

#include "automata.h"

//creates the reverse language for an FSA
void reverse(struct fsa *f);

#endif

