
#ifndef STRINGTESTER_H
#define STRINGTESTER_H

#include "automata.h"

//tests if an FSA accepts a particular string
bool testTheString(struct fsa *f, char *s, bool w);

#endif

