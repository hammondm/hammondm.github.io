
#include "xmlfsaparser.h"
#include "complement.h"
#include "minFSA.h"
#include "distinct.h"

/*
This program creates the intersection of two automata, the specification of
which is given in XML-files.

Mike Hammond
*/

int main(int argc, char *argv[]) {
	int num3;
	char prefix;
	char *newName;
	struct node *n, *newNode;
	struct arc *a;
	sortedSet *alpha1, *alpha2;
	//check that command-line arguments are present
	if (argc != 3) {
		fprintf(stderr, "usage: intersect xml-file1 xml-file2\n");
		return 1;
	}
	//parse the FSAs from the XML files
	struct fsa *f1 = parseXML(argv[1]);
	struct fsa *f2 = parseXML(argv[2]);
	//check that fsas are actually created
	if (f1 == NULL || f2 == NULL) {
		fprintf(stderr, "Problem reading xml files\n");
		return 1;
	}
	//check that FSAs are determinized
	if (!(f1->determinized && f2->determinized)) {
		deallocFSA(f1);
		deallocFSA(f2);
		fprintf(stderr, "FSAs must be already determinized\n");
		return 1;
	}
	//get the prefix of the first node of f1
	prefix = f1->nodes->name[0];
	//get alphabets
	alpha1 = getAlphabet(f1->nodes);
	alpha2 = getAlphabet(f2->nodes);
	//make the union
	setUnion(alpha1, alpha2);
	//determinize each FSA wrt/ the union of the alphabets
	determWithAlpha(f1, alpha1);
	determWithAlpha(f2, alpha1);
	//free memory
	freeSortedSet(alpha1);
	freeSortedSet(alpha2);
	//take complements
	complement(f1);
	complement(f2);
	//make sure node names are unique
	num3 = distinguish(f1, f2);
	//make a union of FSAs
	//make a new start state add to F1
	num3++;
	asprintf(&newName, "%c%i", prefix, num3);
	newNode = makeNodeWithName(newName, false, true);
	//add arcs to old start states and make them non-start
	n = f1->nodes;
	while (n != NULL) {
		if (n->start) {
			a = makeArc(EPSILON, newNode, n);
			addArc(newNode, a);
			n->start = false;
		}
		n = n->nextNode;
	}
	n = f2->nodes;
	while (n != NULL) {
		if (n->start) {
			a = makeArc(EPSILON, newNode, n);
			addArc(newNode, a);
			n->start = false;
		}
		n = n->nextNode;
	}
	//add new start state to FSA 1
	addNode(f1, newNode);
	//add all nodes from F2 to F1
	addNode(f1, f2->nodes);
	f2->nodes = NULL;
	//remove epsilons in new FSA (1)
	removeEpsilons(f1);
	//determinize new FSA (1)
	determinize(f1);
	//take complement of new FSA (1)
	complement(f1);
	//minimize new FSA (1)
	minimize(f1);
	//output new FSA (1) as XML
	printXML(f1);
	//free memory
	deallocFSA(f1);
	deallocFSA(f2);
	return 0;
}

