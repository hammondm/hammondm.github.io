
#include <stdio.h>
#include "xmlfsaparser.h"

/*
This trains an FSA based on a list of items. This does NOT check if the
string is well-formed with respect to the FSA.

Mike Hammond
*/

#define SIZE 100

int main(int argc, char *argv[]) {
	struct fsa *f;
	struct node *n, *start;
	struct arc *a;
	FILE *myFile;
	char line[SIZE];
	int len, count;
	bool matches;
	//check command-line arguments
	if (argc != 3) {
		fprintf(stderr, "usage: train xml-file word-file\n");
		return 1;
	}
	//read FSA
	f = parseXML(argv[1]);
	//check that FSA got read
	if (f == NULL) {
		fprintf(stderr, "Problem reading xml-file: %s\n", argv[1]);
		return 1;
	}
	//open training data
	myFile = fopen(argv[2], "r");
	//check that training data got read
	if (myFile == NULL) {
		fprintf(stderr, "Problem reading training data: %s\n", argv[1]);
		deallocFSA(f);
		return 1;
	}
	//find the start node
	n = f->nodes;
	while (n != NULL) {
		if (n->start) {
			start = n;
			break;
		}
		n = n->nextNode;
	}
	//loop line by line
	while (fgets(line, SIZE, myFile) != NULL) {
		//check that there's a word on the line
		len = strlen(line);
		line[len-1] = '\0';
		if (strlen(line) > 0) {
			//always start in the start node
			n = start;
			//go letter by letter
			for (count = 0; count < len; count++) {
				//check all the arcs
				a = n->arcs;
				matches = false;
				while (a != NULL) {
					//if current letter matches, move to next node/letter
					if (a->symbol == line[count]) {
						n = a->to;
						a->weight++;
						matches = true;
						break;
					}
					a = a->nextArc;
				}
				if (!matches)
					break;
			}
		}
	}
	fclose(myFile);
	printXML(f);
	deallocFSA(f);
	return 0;
}

