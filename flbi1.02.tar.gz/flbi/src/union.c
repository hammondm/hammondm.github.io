
#include "xmlfsaparser.h"
#include "minFSA.h"
#include "distinct.h"
#include "rev.h"

/*
This program creates the union of two other FSA. They are given as XML
specifications.

Mike Hammond
*/

int main(int argc, char *argv[]) {
	int num3;
	char prefix;
	char *newName;
	struct node *n, *newNode;
	struct arc *a;
	//check that command-line arguments are present
	if (argc != 3) {
		fprintf(stderr, "usage: union xml-file1 xml-file2\n");
		return 1;
	}
	//parse the FSAs from the XML files
	struct fsa *f1 = parseXML(argv[1]);
	struct fsa *f2 = parseXML(argv[2]);
	//check that FSAs are determinized
	if (!(f1->determinized && f2->determinized)) {
		deallocFSA(f1);
		deallocFSA(f2);
		fprintf(stderr, "FSAs must be already determinized\n");
		return 1;
	}
	//make sure node names are unique
	num3 = distinguish(f1, f2);
	//make a union of FSAs
	//make a new start state add to F1
	num3++;
	asprintf(&newName, "%c%i", prefix, num3);
	newNode = makeNodeWithName(newName, false, true);
	//add arcs to old start states and make them non-start
	n = f1->nodes;
	while (n != NULL) {
		if (n->start) {
			a = makeArc(EPSILON, newNode, n);
			addArc(newNode, a);
			n->start = false;
		}
		n = n->nextNode;
	}
	n = f2->nodes;
	while (n != NULL) {
		if (n->start) {
			a = makeArc(EPSILON, newNode, n);
			addArc(newNode, a);
			n->start = false;
		}
		n = n->nextNode;
	}
	//add new start state to FSA 1
	addNode(f1, newNode);
	//make a new final state
	newNode = makeNode(true, false);
	//add all nodes from F2 to F1
	addNode(f1, f2->nodes);
	//add arcs from old final states and make them non-final
	n = f1->nodes;
	while (n != NULL) {
		if (n->final) {
			a = makeArc(EPSILON, n, newNode);
			addArc(n, a);
			n->final = false;
		}
		n = n->nextNode;
	}
	//add new final state to F1
	addNode(f1, newNode);
	f2->nodes = NULL;
	//remove epsilons in new FSA (1)
	removeEpsilons(f1);
	//determinize new FSA (1)
	determinize(f1);
	//minimize new FSA (1)
	//minimize(f1);
	reverse(f1);
	determinize(f1);
	reverse(f1);
	determinize(f1);
	//output new FSA (1) as XML
	printXML(f1);
	//free memory
	deallocFSA(f1);
	deallocFSA(f2);
	return 0;
}

