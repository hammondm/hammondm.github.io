
#include "complement.h"

/*
This module handles making the complement of an automaton

Mike Hammond
*/

//creates the complement language for an FSA
void complement(struct fsa *f) {
	fprintf(stderr, "Creating the complement...\n");
	struct node *n = f->nodes;
	while (n != NULL) {
		if (n->final)
			n->final = false;
		else
			n->final = true;
		n = n->nextNode;
	}
}

