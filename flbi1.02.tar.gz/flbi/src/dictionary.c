
#include "automata.h"

/*
This program reads in a column of words and creates a (non-determinized!)
FSA that accepts the language defined by those words.

It's basically the union of a separate FSA for each word. The resulting FSA
also contains epsilons.

Mike Hammond
*/

int main(int argc, char *argv[]) {
	FILE *file;
	char c;
	struct node *start, *final, *new, *last;
	struct fsa *f;
	struct arc *a;
	//check that command-line argument is present
	if (argc != 2) {
		fprintf(stderr, "usage: dictionary filename\n");
		return 1;
	}
	//open file and check that it opens
	file = fopen(argv[1], "r");
	if (file == NULL) {
		fprintf(stderr, "Can't read file: %s\n", argv[1]);
		return 1;
	}
	//make FSA
	f = (struct fsa *)malloc(sizeof(struct fsa));
	f->determinized = false;
	f->nodes = NULL;
	//make start node and add to FSA
	start = makeNode(false, true);
	addNode(f, start);
	//make final node and add to FSA
	final = makeNode(true, false);
	addNode(f, final);
	//make node/arc sequences for each word and add to FSA
	last = start;
	while ((c = getc(file)) != EOF) {
		if (c == '\n') {
			a = makeArc(EPSILON, last, final);
			addArc(last, a);
			last = start;
		} else {
			new = makeNode(false, false);
			a = makeArc(c, last, new);
			addArc(last, a);
			addNode(f, new);
			last = new;
		}
	}
	fclose(file);
	//print fsa as XML
	printXML(f);
	//deallocate FSA
	deallocFSA(f);
	return 0;
}

