
#ifndef MINFSA_H
#define MINFSA_H

#include "automata.h"

//minimizes an FSA
void minimize(struct fsa *f);

#endif

