#ifndef REGEX_H
#define REGEX_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

//struct for a regular expression
struct regexp {
	enum { UNION, CONCAT, KLEENE, SIMPLE } type;
	char c;
	struct regexp *re1;
	struct regexp *re2;
};

//routines for making regular expressions
struct regexp *makeSimple(char c);
struct regexp *makeKleene(struct regexp *r);
struct regexp *makeUnion(struct regexp *r1, struct regexp *r2);
struct regexp *makeConcat(struct regexp *r1, struct regexp *r2);

//routine for getting a string representation of a RE
char *printableRE(struct regexp *r);

//routine for freeing RE memory
void deallocRE(struct regexp *r);

#endif

