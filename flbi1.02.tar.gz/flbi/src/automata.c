
#include "automata.h"

/*
This file contains most of the basic routines associated with
automata.

Mike Hammond
*/

//returns the number of nodes in an FSA
int nodeCount(struct fsa *f) {
	int count = 0;
	struct node *n = f->nodes;
	while (n != NULL) {
		count++;
		n = n->nextNode;
	}
	return count;
}

//variables for node names
int i = 0;
static char prefix = 'q';

//adds a diamond state if necessary
void addDiamond(struct fsa *f) {
	bool diamond = false;
	sortedSet *ss;
	char *name;
	//find all the start states
	struct node *n, *n2;
	n = f->nodes;
	while (n != NULL) {
		if (n->start) {
			ss = newSortedSet();
			//get the eclosure of each start state
			eclosure(ss, n);
			//go through each state in the eclosure
			while (sortedSetSize(ss) > 0) {
				name = pop(ss);
				n2 = getStateByName(f->nodes, name);
				free(name);
				//if there is a final state, we need to add a diamond
				if (n2->final) {
					diamond = true;
					break;
				}
			}
			freeSortedSet(ss);
		}
		n = n->nextNode;
	}
	if (diamond) {
		n = makeNode(true, true);
		addNode(f, n);
	}
}

//print an xml representation of an FSA
void printXML(struct fsa *f) {
	struct arc *a;
	struct node *n = f->nodes;
	printf("<?xml version=\"1.0\"?>\n\n");

	printf("<!DOCTYPE net PUBLIC \"-//Mike Hammond//net//EN\"\n");
	printf("\"http://www.u.arizona.edu/~hammond/fsanet.dtd\">\n\n");
	//printf("\"http://dingo.sbs.arizona.edu/~hammond/fsanet.dtd\">\n\n");
	//printf("<!DOCTYPE net SYSTEM \"fsanet.dtd\">\n\n");

	printf("<net determinized=\"");
	if (f->determinized)
		printf("true\">\n\n");
	else
		printf("false\">\n\n");

	while (n != NULL) {
		printf("\t<fsanode label=\"%s\" final=\"", n->name);
		if (n->final == true)
			printf("true\" start=\"");
		else
			printf("false\" start=\"");
		if (n->start == true)
			printf("true\"");
		else
			printf("false\"");
		a = n->arcs;
		if (a == NULL)
			printf("/>\n");
		else {
			printf(">\n");
			while (a != NULL) {
				printf("\t\t<arc symbol=\"%c\" endnode=\"%s\" weight=\"%f\"/>\n",
					a->symbol, a->to->name, a->weight);
				a = a->nextArc;
			}
			printf("\t</fsanode>\n");
		}
		n = n->nextNode;
	}

	printf("\n</net>\n");
}

//determinize an fsa (epsilons must be already removed)
void determinize(struct fsa *f) {
	determWithAlpha(f, NULL);
}

//determinize an fsa (epsilons must be already removed)
void determWithAlpha(struct fsa *f, sortedSet *alpha) {
	fprintf(stderr, "Determinizing FSA...\n");
	struct arc *a;
	char *curStateName, *letter;
	struct node *newNodes, *curState, *oldNodes, *alreadyExists, *n2;
	sortedSet *alphabet, *outSet, *startStates, *statesToDo;
	sslink *link;
	statesToDo = newSortedSet();
	oldNodes = f->nodes;
	f->nodes = NULL;
	if (alpha == NULL) {
		alphabet = getAlphabet(oldNodes);
	} else {
		alphabet = alpha;
	}
	//create start state
	startStates = newSortedSet();
	struct node *n = oldNodes;
	while (n != NULL) {
		if (n->start == true)
			addToSortedSet(startStates, n->name);
		n = n->nextNode;
	}
	newNodes = makeNode(false, true);
	newNodes->parts = startStates;
	addNode(f, newNodes);
	//add start state to list of states
	addToSortedSet(statesToDo, newNodes->name);
	//iterate through list of states
	while (sortedSetSize(statesToDo) > 0) {
		//get the current state to add arcs to
		curStateName = pop(statesToDo);
		curState = getStateByName(newNodes, curStateName);
		//go through the whole alphabet for each state
		link = alphabet->firstOne;
		while (link != NULL) {
			letter = link->s;
			//create a set of states that can be reached with the letter
			outSet = newSortedSet();
			//go through all the states in the initial automaton
			n = oldNodes;
			while (n != NULL) {
				//if this node is one of the source nodes
				if (isInSet(curState->parts, n->name)) {
					//go through all the arcs looking for the letter
					a = n->arcs;
					while (a != NULL) {
						if (a->symbol == letter[0]) {
							addToSortedSet(outSet, a->to->name);
						}
						a = a->nextArc;
					}
				}
				n = n->nextNode;
			}
			//check if node already exists
			alreadyExists = NULL;
			n = newNodes;
			while (n != NULL) {
				if (setEquals(n->parts, outSet)) {
					alreadyExists = n;
				}
				n = n->nextNode;
			}
			//if it doesn't exist create it and add it to statesToDo
			if (alreadyExists == NULL) {
				alreadyExists = makeNode(false, false);
				alreadyExists->parts = outSet;
				addNode(f, alreadyExists);
				addToSortedSet(statesToDo, alreadyExists->name);
			} else {
				freeSortedSet(outSet);
			}
			//add arc going to this state
			if (!arcExists(letter[0], curState, alreadyExists)) {
				a = makeArc(letter[0], curState, alreadyExists);
				addArc(curState, a);
			}
			link = link->next;
		}
	}
	freeSortedSet(statesToDo);
	if (alpha == NULL)
		freeSortedSet(alphabet);
	//set the final states
	n = f->nodes;
	while (n != NULL) {
		n2 = oldNodes;
		while (n2 != NULL) {
			if (n2->final == true && isInSet(n->parts, n2->name))
				n->final = true;
			n2 = n2->nextNode;
		}
		n = n->nextNode;
	}
	deallocNode(oldNodes);
	f->determinized = true;
}

//checks if an arc already exists
bool arcExists(char c, struct node *f, struct node *t) {
	struct arc *a = f->arcs;
	while (a != NULL) {
		if ((c == a->symbol) && (strcmp(t->name, a->to->name) == 0))
			return true;
		a = a->nextArc;
	}
	return false;
}

//gets a state struct from a linked list of states
struct node *getStateByName(struct node *n, char *name) {
	struct node *temp;
	temp = n;
	while (temp != NULL) {
		if (strcmp(temp->name, name) == 0)
			return temp;
		temp = temp->nextNode;
	}
	return NULL;
}

//removes all epsilon arcs from an FSA
void removeAllEpsilonArcs(struct fsa *f) {
	struct arc *a, *nextA;
	//go through all the nodes
	struct node *n = f->nodes;
	while (n != NULL) {
		//go through all the arcs
		a = n->arcs;
		n->arcs = NULL;
		while (a != NULL) {
			nextA = a->nextArc;
			//if the current arc is not an epsilon-arc
			if (a->symbol != EPSILON) {
				//remove it
				addArc(n, a);
			} else {
				free(a);
			}
			a = nextA;
		}
		n = n->nextNode;
	}
}

//ec(n) -c-> ec(?)
sortedSet *ecDeltaEc(struct node *n, char c, struct fsa *f) {
	struct node *tn = f->nodes;
	sortedSet *ec, *ec2, *res;
	struct arc *a;
	ec = newSortedSet();
	res = newSortedSet();
	eclosure(ec, n);
	while (tn != NULL) {
		if (isInSet(ec,tn->name)) {
			a = tn->arcs;
			while (a != NULL) {
				if (a->symbol == c) {
					ec2 = newSortedSet();
					eclosure(ec2, a->to);
					setUnion(res, ec2);
					freeSortedSet(ec2);
				}
				a = a->nextArc;
			}
		}
		tn = tn->nextNode;
	}
	freeSortedSet(ec);
	return res;
}

//gets the alphabet of an FSA
sortedSet *getAlphabet(struct node *nd) {
	sortedSet *alphabet = newSortedSet();
	char *s;
	struct arc *a;
	//goes through the nodes one by one
	struct node *n = nd;
	while (n != NULL) {
		//goes through the arcs of that node one by one
		a = n->arcs;
		while (a != NULL) {
			if (a->symbol != EPSILON) {
				//converts chars to strings
				asprintf(&s, "%c", a->symbol);
				//adds all symbols to the set
				addToSortedSet(alphabet, s);
				//removes original string
				free(s);
			}
			a = a->nextArc;
		}
		n = n->nextNode;
	}
	return alphabet;
}

//computes the epsilon-closure for a node
void eclosure(sortedSet *ss, struct node *n) {
	struct arc *a;
	//add the node itself to the set
	if (!isInSet(ss, n->name)) {
		//add it to the set
		addToSortedSet(ss, n->name);
		//go through all the arcs
		a = n->arcs;
		while (a != NULL) {
			//if arc is an epsilon arc and node isn't already in set
			if (a->symbol == EPSILON && !isInSet(ss, a->to->name))
				//recursively add other nodes
				eclosure(ss, a->to);
			a = a->nextArc;
		}
	}
}

//adds arcs for a symbol from a node to a set of nodes
void replaceEpsilonArcs(struct node *n, char c,
		sortedSet *toNodes, struct fsa *f) {
	struct node *allNodes;
	//get to-nodes from current node on the relevant symbol
	sortedSet *curToNodes = newSortedSet();
	struct arc *a = n->arcs;
	while (a != NULL) {
		if (a->symbol == c)
			addToSortedSet(curToNodes, a->to->name);
		a = a->nextArc;
	}
	//go through nodes in fsa one by one
	allNodes = f->nodes;
	while (allNodes != NULL) {
		//check if node is in toNodes and NOT in curToNodes
		if (isInSet(toNodes, allNodes->name) &&
				!isInSet(curToNodes, allNodes->name)) {
			//if so, add an arc to n
			a = makeArc(c, n, allNodes);
			addArc(n,a);
		}
		allNodes = allNodes->nextNode;
	}
	freeSortedSet(curToNodes);
}

//removes epsilon arcs
void removeEpsilons(struct fsa *f) {
	fprintf(stderr, "Removing epsilon arcs...\n");
	char *letter;
	struct node *n;
	sortedSet *ec, *alphabet;
	//gets the alphabet of the FSA
	alphabet = getAlphabet(f->nodes);
	letter = pop(alphabet);
	while (letter != NULL) {
		//go through all the nodes
		n = f->nodes;
		while (n != NULL) {
			//calculate the e-closure of the node
			ec = ecDeltaEc(n, letter[0], f);
			//ADD NEW ARCS
			replaceEpsilonArcs(n, letter[0], ec, f);
			//free memory
			freeSortedSet(ec);
			//go on to the next node
			n = n->nextNode;
		}
		letter = pop(alphabet);
	}
	//free memory
	freeSortedSet(alphabet);
	//add diamond state
	addDiamond(f);
	//remove all epsilon arcs
	removeAllEpsilonArcs(f);
}

//makes an FSA
struct fsa *makeFsa(struct regexp *r) {
	struct fsa *f = (struct fsa *)malloc(sizeof(struct fsa));
	struct fsa *tempFSA1, *tempFSA2;
	struct node *startNode, *endNode, *tempNode1, *tempNode2;
	struct arc *oneArc;
	f->determinized = false;
	f->nodes = NULL;
	switch (r->type) {
		case SIMPLE:
			//make a start node
			startNode = makeNode(false, true);
			//add start node to FSA
			f->nodes = startNode;
			//make a final node
			endNode = makeNode(true, false);
			//add final node to FSA
			startNode->nextNode = endNode;
			//create an arc
			if (r->c == '@')
				oneArc = makeArc(EPSILON, startNode, endNode);
			else
				oneArc = makeArc(r->c, startNode, endNode);
			//add arc to list of arcs
			oneArc->nextArc = NULL;
			startNode->arcs = oneArc;
			break;
		case UNION:
			//construct new start state
			startNode = makeNode(false, true);
			//add start node to FSA
			f->nodes = startNode;
			//make new final state
			endNode = makeNode(true, false);
			//add final node to FSA
			startNode->nextNode = endNode;
			//create FSA for first disjunct
			tempFSA1 = makeFsa(r->re1);
			//get first FSA start state
			tempNode1 = tempFSA1->nodes;
			//move all states to new FSA
			addNode(f,tempNode1);
			//epsilon-arc from new start state to old start states
			while (tempNode1 != NULL) {
				if (tempNode1->start == true) {
					oneArc = makeArc(EPSILON, startNode, tempNode1);
					tempNode1->start = false;
					addArc(startNode, oneArc);
				}
				tempNode1 = tempNode1->nextNode;
			}
			//get all states
			//get first FSA state
			tempNode1 = tempFSA1->nodes;
			while (tempNode1 != NULL) {
				//adding arcs for final states to new final state
				if (tempNode1->final == true) {
					oneArc = makeArc(EPSILON, tempNode1, endNode);
					addArc(tempNode1, oneArc);
					//make old final states non-final
					tempNode1->final = false;
				}
				tempNode1 = tempNode1->nextNode;
			}
			//do it all AGAIN
			//create FSA for second disjunct
			tempFSA2 = makeFsa(r->re2);
			//get second FSA start state
			tempNode1 = tempFSA2->nodes;
			//move all states to new FSA
			addNode(f,tempNode1);
			//epsilon-arc from new start state to old start states
			while (tempNode1 != NULL) {
				if (tempNode1->start == true) {
					oneArc = makeArc(EPSILON, startNode, tempNode1);
					tempNode1->start = false;
					addArc(startNode, oneArc);
				}
				tempNode1 = tempNode1->nextNode;
			}
			//get all states
			//get second FSA states
			tempNode1 = tempFSA2->nodes;
			while (tempNode1 != NULL) {
				//adding arcs for final states to new final state
				if (tempNode1->final == true) {
					oneArc = makeArc(EPSILON, tempNode1, endNode);
					addArc(tempNode1, oneArc);
					//make old final states non-final
					tempNode1->final = false;
				}
				tempNode1 = tempNode1->nextNode;
			}
			//remove old FSAs, LEAVING THEIR NODES
			free(tempFSA1);
			free(tempFSA2);
			break;
		case CONCAT:
			//construct new start state
			startNode = makeNode(false, true);
			//add start node to FSA
			f->nodes = startNode;
			//make new final state
			endNode = makeNode(true, false);
			//add final node to FSA
			startNode->nextNode = endNode;
			//create FSA for first conjunct
			tempFSA1 = makeFsa(r->re1);
			//create FSA for second conjunct
			tempFSA2 = makeFsa(r->re2);
			//epsilon arc from new start state to first fsa start state
			tempNode1 = tempFSA1->nodes;
			//move all states from first FSA to new FSA
			addNode(f,tempNode1);
			//epsilon-arc from new start state to old start states
			while (tempNode1 != NULL) {
				if (tempNode1->start == true) {
					oneArc = makeArc(EPSILON, startNode, tempNode1);
					tempNode1->start = false;
					addArc(startNode, oneArc);
				}
				tempNode1 = tempNode1->nextNode;
			}
			tempNode1 = tempFSA1->nodes;
			//go through states of first fsa
			while (tempNode1 != NULL) {
				//if final
				if (tempNode1->final == true) {
					//get start node of second FSA
					tempNode2 = tempFSA2->nodes;
					while (tempNode2 != NULL) {
						if (tempNode2->start == true) {
							//add arc to second fsa start states
							oneArc = makeArc(EPSILON, tempNode1, tempNode2);
							addArc(tempNode1, oneArc);
						}
						tempNode2 = tempNode2->nextNode;
					}
					//make nonfinal
					tempNode1->final = false;
				}
				tempNode1 = tempNode1->nextNode;
			}
			tempNode2 = tempFSA2->nodes;
			//make all states in second fsa non start states
			while (tempNode2 != NULL) {
				tempNode2->start = false;
				tempNode2 = tempNode2->nextNode;
			}
			//move all states from second FSA to new FSA
			tempNode2 = tempFSA2->nodes;
			addNode(f,tempNode2);
			while (tempNode2 != NULL) {
			//go through states of second fsa
				//if final
				if (tempNode2->final == true) {
					//add arc to new final state
					oneArc = makeArc(EPSILON, tempNode2, endNode);
					addArc(tempNode2, oneArc);
					//make nonfinal
					tempNode2->final = false;
				}
				tempNode2 = tempNode2->nextNode;
			}
			//remove old FSAs, LEAVING THEIR NODES
			free(tempFSA1);
			free(tempFSA2);
			break;
		//KLEENE:
		default:
			//construct new start state
			startNode = makeNode(true, true);
			//add start node to FSA
			f->nodes = startNode;
			//make new final state
			endNode = makeNode(false, false);
			//add final node to FSA
			startNode->nextNode = endNode;
			//create FSA for the RE
			tempFSA1 = makeFsa(r->re1);
			//get RE start state
			tempNode1 = tempFSA1->nodes;
			while (tempNode1 != NULL) {
				if (tempNode1->start == true) {
					//add arc from new start state to old start state
					oneArc = makeArc(EPSILON, startNode, tempNode1);
					tempNode1->start = false;
					addArc(startNode, oneArc);
				}
				tempNode1 = tempNode1->nextNode;
			}
			tempNode1 = tempFSA1->nodes;
			//add epsilon arc from new end node to new start node
			oneArc = makeArc(EPSILON, endNode, startNode);
			addArc(endNode, oneArc);
			//add all states to f
			addNode(f,tempNode1);
			//loops
			while (tempNode1 != NULL) {
				//if state is final
				if (tempNode1->final == true) {
					//add epsilon arcs from final states to new final state
					oneArc = makeArc(EPSILON, tempNode1, endNode);
					addArc(tempNode1, oneArc);
					//make states nonfinal
					tempNode1->final = false;
				}
				tempNode1 = tempNode1->nextNode;
			}
			//remove old FSA, LEAVING ITS NODES
			free(tempFSA1);
	}
	return f;
}


//routine to make arcs with a specific weight
struct arc *makeArcWithWeight(char s, struct node *f,
		struct node *t, float w) {
	struct arc *a = makeArc(s, f, t);
	a->weight = w;
	return a;
}

//routine to make arcs
struct arc *makeArc(char s, struct node *f, struct node *t) {
	struct arc *a;
	a = (struct arc *)malloc(sizeof(struct arc));
	a->symbol = s;
	a->from = f;
	a->to = t;
	a->weight = 0.0;
	return a;
}

//routine to make nodes
struct node *makeNode(bool f, bool s) {
	struct node *n;
	n = (struct node *)malloc(sizeof(struct node));
	n->name = makeName();
	n->final = f;
	n->start = s;
	n->nextNode = NULL;
	n->arcs = NULL;
	n->parts = NULL;
	return n;
}

//routine to make nodes with the name specified
struct node *makeNodeWithName(char *name, bool f, bool s) {
	struct node *n;
	int num;
	n = (struct node *)malloc(sizeof(struct node));
	n->name = name;
	num = atoi(name+1);
	if (i <= num)
		i = num + 1;
	n->final = f;
	n->start = s;
	n->nextNode = NULL;
	n->arcs = NULL;
	n->parts = NULL;
	return n;
}

//routine for adding nodes to an FSA
void addNode(struct fsa *f, struct node *n) {
	//adds the node in LAST position; not a start node
	struct node *temp;
	temp = f->nodes;
	if (temp == NULL) {
		f->nodes = n;
		return;
	}
	while (temp->nextNode != NULL) {
		temp = temp->nextNode;
	}
	temp->nextNode = n;
}

//routine for adding arcs to a node
void addArc(struct node *n, struct arc *a) {
	a->nextArc = n->arcs;
	n->arcs = a;
}

//makes a node name
char *makeName(void) {
	char *res;
	asprintf(&res, "%c%d", prefix, i);
	i++;
	return res;
}

//routine for freeing FSA memory
void deallocFSA(struct fsa *f) {
	if (f->nodes != NULL)
		deallocNode(f->nodes);
	free(f);
}

//routine for freeing node memory
void deallocNode(struct node *n) {
	free(n->name);
	if (n->nextNode != NULL)
		deallocNode(n->nextNode);
	if (n->arcs != NULL)
		deallocArc(n->arcs);
	if (n->parts != NULL)
		freeSortedSet(n->parts);
	free(n);
}

//routine for freeing arc memory
void deallocArc(struct arc *a) {
	if (a->nextArc != NULL)
		deallocArc(a->nextArc);
	free(a);
}

//print an FSA
void printFSA(struct fsa *f, bool w) {
	struct node *n;
	struct arc *a;
	int k = 0;
/*
	if (!f->determinized)
		w = false;
*/
	printf("\ndigraph FSA {\n");
	n = f->nodes;
	while (n != NULL) {
		if (n->final == true)
			printf("\tnode [shape = doublecircle] %s;\n", n->name);
		else
			printf("\tnode [shape = circle] %s;\n", n->name);
		n = n->nextNode;
	}
	n = f->nodes;
	while (n != NULL) {
		a = n->arcs;
		while (a != NULL) {
			printf("\t%s -> %s", a->from->name, a->to->name);
			if (w) {
				printf(" [label = \"%c/%f\"]", a->symbol, a->weight);
			} else if (a->symbol != EPSILON) {
				printf(" [label = \"%c\"]", a->symbol);
			}
			printf(";\n");
			a = a->nextArc;
		}
		n = n->nextNode;
	}
	//loop through all the states to mark start states
	n = f->nodes;
	while (n != NULL) {
		if (n->start == true) {
			//set up invisible pre-start states
			k++;
			printf("\tnode [style = invis]; k%d;\n", k);
			printf("\tk%d -> %s;\n", k, n->name);
		}
		n = n->nextNode;
	}
	printf("}\n");
}

