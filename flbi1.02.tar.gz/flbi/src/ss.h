#ifndef SS_H
#define SS_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

//represents a sorted set
struct _sortedSet {
	struct _link *firstOne;
};
typedef struct _sortedSet sortedSet;

//represents an element in a sorted set
struct _link {
	char *s;
	struct _link *next;
};
typedef struct _link sslink;

//creates a new sorted set
sortedSet *newSortedSet(void);
//adds an element to a sorted set
void addToSortedSet(sortedSet *ss, char *str);
//prints a sorted set
void printSortedSet(sortedSet *s);
//checks if a string is in the sorted set
bool isInSet(sortedSet *ss, char *str);
//deallocates memory for a sorted set
void freeSortedSet(sortedSet *ss);
//puts two sets together; adds elements of the second to the first
void setUnion(sortedSet *ss1, sortedSet *ss2);
//set equality
bool setEquals(sortedSet *ss1, sortedSet *ss2);
//pops the top element off a sorted set
char *pop(sortedSet *s);
//gets the lenth of a sorted set
int sortedSetSize(sortedSet *s);

#endif

