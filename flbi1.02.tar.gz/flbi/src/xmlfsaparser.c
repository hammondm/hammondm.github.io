
#include "xmlfsaparser.h"

/*
This module includes the code that allows the program to read and write XML
representations of FSAs.

Mike Hammond
*/

//the input butter
char buff[BUFFSIZE];

//the fsa that's output by parseXML()
struct fsa *f;

//the current node name
char *name;

//list of arcs
textArc *arcList;

//remove the arcList structure
void deallocArcList(void) {
	textArc *current, *last;
	last = NULL;
	current = arcList;
	while (current != NULL) {
		last = current;
		current = current->next;
		free(last);
	}
}

//adding arcs to FSA
void addArcs(void) {
	struct node *n, *n2;
	textArc *a;
	struct arc *theArc;
	//go through all the nodes
	n = f->nodes;
	while (n != NULL) {
		//check each arc
		a = arcList;
		while (a != NULL) {
			//if the from-node matches, add the arc
			if (strcmp(a->from, n->name) == 0) {
				//go through the nodes again to match to-node
				n2 = f->nodes;
				while (n2 != NULL) {
					//the to-node matches, so create/add new arc
					if (strcmp(a->to, n2->name) == 0) {
						theArc = makeArcWithWeight(a->symbol, n, n2, a->weight);
						addArc(n, theArc);
					}
					n2 = n2->nextNode;
				}
			}
			a = a->next;
		}
		n = n->nextNode;
	}
}

//add arc to textArc list
void addToArcList(textArc *a) {
	textArc *tempArc, *lastArc;
	if (arcList == NULL) {
		arcList = a;
	} else {
		tempArc = arcList->next;
		lastArc = arcList;
		while (tempArc != NULL) {
			lastArc = tempArc;
			tempArc = tempArc->next;
		}
		lastArc->next = a;
	}
}

//create a new textArc
textArc *newTextArc(char *from,char c, char *to, float w) {
	textArc *a = (textArc *)malloc(sizeof(textArc));
	a->from = from;
	a->symbol = c;
	a->to = to;
	a->next = NULL;
	a->weight = w;
	return a;
}

//start handler
void start(void *data, const char *el, const char **attr) {
	int i, w;
	char c;
	bool start, final;
	char *to, *from;
	struct node *n;
	textArc *a;
	//marks automaton as deterministic or not
	if (strcmp(el, "net") == 0) {
		if (strcmp(attr[1], "true") == 0)
			f->determinized = true;
	//creates nodes
	} else if (strcmp(el, "fsanode") == 0) {
		//goes through all the node attributes
		for (i = 0; attr[i]; i += 2) {
			//node name
			if (strcmp(attr[i], "label") == 0) {
				name = strdup(attr[i+1]);
			//is it a final state?
			} else if (strcmp(attr[i], "final") == 0) {
				if (strcmp(attr[i+1], "true") == 0)
					final = true;
				else
					final = false;
			//is it an initial state?
			} else {
				if (strcmp(attr[i+1], "true") == 0)
					start = true;
				else
					start = false;
			}
		}
		n = makeNodeWithName(name, final, start);
		addNode(f, n);
	//creates a list of arcs
	} else if (strcmp(el, "arc") == 0) {
		from = strdup(name);
		w = 0;
		for (i = 0; attr[i]; i += 2) {
			if (strcmp(attr[i], "symbol") == 0) {
				c = attr[i+1][0];
			} else if (strcmp(attr[i], "endnode") == 0) {
				to = strdup(attr[i+1]);
			} else if (strcmp(attr[i], "weight") == 0) {
				w = (float) atoi(attr[i+1]);
			}
		}
		a = newTextArc(from,c,to,w);
		addToArcList(a);
	}
}

//parses an XML representation of an FSA from a file
struct fsa *parseXML(char *s) {
	//creates a parser
	XML_Parser p = XML_ParserCreate(NULL);
	//checks that the parser was created
	if (!p) {
		fprintf(stderr, "Couldn't allocate memory for parser\n");
		return NULL;
	}
	//sets the handlers
	XML_SetElementHandler(p, start, NULL);
	f = (struct fsa *)malloc(sizeof(struct fsa));
	f->nodes = NULL;
	f->determinized = false;
	arcList = NULL;
	//opens the file
	FILE *theFile = fopen(s, "r");
	if (theFile == NULL) {
		deallocFSA(f);
		fprintf(stderr, "Failed to read file %s\n", s);
		return NULL;
	}
	//loops through the input
	while (1) {
		int done;
		int len;
		//reads a chunk of input
		len = fread(buff, 1, BUFFSIZE, theFile);
		//exit if there's an error
		if (ferror(theFile)) {
			fprintf(stderr, "Read error\n");
			return NULL;
		}
		//check if we're done
		done = feof(theFile);
		//parses the XML
		if (!XML_Parse(p, buff, len, done)) {
			//what happens if there's an error
			fprintf(stderr, "Parse error at line %d:\n%s\n",
				XML_GetCurrentLineNumber(p),
				XML_ErrorString(XML_GetErrorCode(p)));
			return NULL;
		}
		//exit loop if we're done reading input
		if (done)
			break;
	}
	fclose(theFile);
	//move arcs to FSA HERE
	addArcs();
	//deallocate arclist
	deallocArcList();
	return f;
}

