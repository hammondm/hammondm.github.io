
#ifndef COMPLEMENT_H
#define COMPLEMENT_H

#include "automata.h"

//creates the complement language for an FSA
void complement(struct fsa *f);

#endif

