
#include "stringtester.h"

/*
This module imlements testing a string against a determinized automaton.

Mike Hammond
*/

//tests if an FSA accepts a particular string
bool testTheString(struct fsa *f, char *s, bool w) {
	struct node *n;
	struct arc *a;
	int length, i;
	bool matches = true;
	float total, matchValue;
	//get start state
	n = f->nodes;
	while (n != NULL) {
		if (n->start)
			break;
		n = n->nextNode;
	}
	length = strlen(s);
	//go through the string letter by letter
	for (i = 0; i < length; i++) {
		//check if there's an arc for the current letter
		a = n->arcs;
		matches = false;
		total = 0.0;
		while (a != NULL) {
			total += a->weight;
			if (a->symbol == s[i]) {
				n = a->to;
				matches = true;
				if (w) {
					matchValue = a->weight;
				}
				//stop going through arcs and go to the next letter
				if (!w)
					break;
			}
			a = a->nextArc;
		}
		//if you get all the way through the arcs, illegal letter: false
		if (!matches) {
			return false;
		} else {
			printf("\t%c: %.0f (%f)\n", s[i], matchValue, matchValue/total);
		}
	}
	if (matches && n->final)
		return true;
	else
		return false;
}

