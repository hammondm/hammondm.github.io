
#ifndef AUTOMATA_H
#define AUTOMATA_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "ss.h"
#include "regex.h"

#define EPSILON '-'

//a finite state automaton
struct fsa {
	struct node *nodes;
	bool determinized;
};

//a node in an FSA along with its name and arcs
struct node {
	char *name;
	bool final;
	bool start;
	struct arc *arcs;
	struct node *nextNode;
	sortedSet *parts;
};

//an arc/transition
struct arc {
	char symbol;
	struct node *from;
	struct node *to;
	struct arc *nextArc;
	float weight;
};

//makes a node name
char *makeName(void);
//makes an FSA
struct fsa *makeFsa(struct regexp *r);
//print an FSA
void printFSA(struct fsa *f, bool w);
//routine for freeing FSA memory
void deallocFSA(struct fsa *f);
//routine for freeing node memory
void deallocNode(struct node *n);
//routine for freeing FSA memory
void deallocArc(struct arc *a);
//routine for adding arcs to a node
void addArc(struct node *n, struct arc *a);
//routine for adding nodes to an FSA
void addNode(struct fsa *f, struct node *n);
//routine to make nodes
struct node *makeNode(bool f, bool s);
//routine to make nodes with the name specified
struct node *makeNodeWithName(char *name, bool f, bool s);
//routine to make arcs
struct arc *makeArc(char s, struct node *f, struct node *t);
//removes epsilon arcs
void removeEpsilons(struct fsa *f);
//computes the epsilon-closure for a node
void eclosure(sortedSet *ss, struct node *n);
//gets the alphabet of an FSA
sortedSet *getAlphabet(struct node *nd);
//ec(n) -c-> ec(?)
sortedSet *ecDeltaEc(struct node *n, char c, struct fsa *f);
//adds a set of arcs to an fsa
void replaceEpsilonArcs(struct node *n, char c, sortedSet *toNodes, struct
fsa *f);
//removes all epsilon arcs from an FSA
void removeAllEpsilonArcs(struct fsa *f);
//determinize an fsa (epsilons must be already removed)
void determinize(struct fsa *f);
//gets a state struct from a linked list of states
struct node *getStateByName(struct node *n, char *name);
//checks if an arc already exists
bool arcExists(char c, struct node *f, struct node *t);
//print an xml representation of an FSA
void printXML(struct fsa *f);
//returns the number of nodes in an FSA
int nodeCount(struct fsa *f);
//determinize wrt/ a specific alphabet
void determWithAlpha(struct fsa *f, sortedSet *alpha);
//routine to make arcs with a specific weight
struct arc *makeArcWithWeight(char s, struct node *f, struct node *t, float w);

#endif

