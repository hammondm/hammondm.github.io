#ifndef DISTINCT_H
#define DISTINCT_H

#include "automata.h"

//make sure node names are distinct; rename nodes in f2
int distinguish(struct fsa *f1, struct fsa *f2);

#endif

